# Open Notifications Composer for Organizers

## What & Why
Replace the template-driven, rate-limited notifications page with a fully open free-form composer. Promoters should be able to write any message they want, send it whenever they want, and target either all riders registered across any of their events or riders from a specific event only.

## Done looks like
- Organizer opens Notifications and sees a simple composer: an audience picker, a title field, and a body textarea with a character counter
- Audience picker has two options: "All my riders" (every rider registered for any event under their club) and "Specific event" (dropdown of all their events, not just those in a time window)
- Character limit of 500 on the body (shown as a live counter below the textarea); title limited to 100 characters
- No rate limit, no timing window, no template types — send button is enabled whenever title + body are non-empty and an audience is chosen
- Policy callout, countdown timer, and notification-type selector are removed entirely
- Backend `/api/admin/notifications/broadcast` removes the timing window and rate limit checks; accepts `eventId: null` (or omitted) to mean "all riders across my club's events" — it queries registrations across all events belonging to the organizer's club and fans out from there
- Sending still scopes to the organizer's own club — a promoter cannot reach riders from another club's events

## Out of scope
- Notification history log (separate task #238)
- Gate conditions template type (separate task #237)
- Super-admin broadcast-all route (unchanged)

## Steps
1. **Update the broadcast API route** — Remove the timing-window and rate-limit checks for organizers. Add a new code path: when `eventId` is absent or `null`, query the organizer's `clubId` from `usersTable`, fetch all event IDs under that club from `eventsTable`, then gather registrations across those events to build the recipient list. When `eventId` is provided, keep the existing single-event lookup. Remove the `lastPushSentAt` write — no longer needed for rate tracking.

2. **Rewrite the Notifications page UI** — Replace the entire page with the open composer. Audience picker is a two-option selector: "All my riders" and "Specific event". When "Specific event" is chosen show a dropdown of all the club's events (no time-window filter). Title input (100-char limit) and body textarea (500-char limit) with live character counters. Remove rate-limit state, countdown timer, template type selector, and policy callout. Keep the automatic race-day notifications info blurb at the bottom. Keep the push-stats line showing how many riders have the app installed.

## Relevant files
- `artifacts/api-server/src/routes/notifications.ts`
- `artifacts/race-platform/src/pages/organizer/Notifications.tsx`
