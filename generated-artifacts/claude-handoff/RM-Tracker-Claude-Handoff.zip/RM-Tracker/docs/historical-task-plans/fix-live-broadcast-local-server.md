# Fix Live Broadcast in Desktop / Local Server Mode

## What & Why
When an organizer clicks "Go Live" while running the desktop app (local server at `localhost:9090`), they immediately get "Connection to the server was lost." The local server has no WebSocket relay — video relay only lives on the cloud API server. Both the broadcaster (`BroadcastContext.tsx`) and viewer (`WatchLive.tsx`) build their WebSocket URLs using `window.location.host`, so in local mode they try to connect to `localhost:9090` which has no `/api/video/broadcast` or `/api/video/watch` WebSocket endpoints. The fix is to route broadcast/watch WebSocket connections to the cloud server when running locally, using the same `getPublicOrigin()` pattern already established for shareable links.

There are also two secondary bugs discovered in the same area:

1. `BroadcastContext.tsx` has no `ws.onclose` handler — if the WebSocket drops cleanly mid-stream (network hiccup, server restart) the recorder keeps running silently and the UI stays stuck in "live" state forever with no error shown.
2. The `LiveBroadcast` UI shows the "Go Live" button even when no cloud URL is configured in the desktop app, which will always fail. It should detect this and warn the organizer.

## Done looks like
- Clicking "Go Live" in the desktop app successfully connects to the cloud WebSocket relay and starts streaming.
- Viewers watching via the desktop app can also connect to the cloud relay.
- If the WebSocket closes mid-broadcast (clean close, not an error), the organizer sees an error message and the UI resets — same behaviour as `ws.onerror`.
- If no cloud URL is configured (desktop app without sync credentials set up), the Go Live button is disabled and a short explanatory note is shown below it.

## Out of scope
- Adding a video relay to the local server itself (cloud relay is the correct architecture).
- Changes to viewer reconnect logic (covered separately in Task #32).

## Steps

1. **Fix `getWsUrl` in `BroadcastContext.tsx`** — Replace `window.location.host` with the cloud origin. Extract the host from `getPublicOrigin()` (from `lib/publicOrigin.ts`) and convert it to a WebSocket URL (`wss:` for `https:` origins, `ws:` for `http:`). Import `getPublicOrigin` at the top of the file.

2. **Add `ws.onclose` handler in `BroadcastContext.tsx`** — After `ws.onerror`, add a `ws.onclose` handler that checks whether the broadcast is still in "live" state and, if so, sets the error message ("Stream connection closed unexpectedly. Please try again.") and calls `stopBroadcast()`. This prevents silent stuck-live state on clean connection drops.

3. **Fix `getWsUrl` in `WatchLive.tsx`** — Same fix as step 1: replace `window.location.host` with a host derived from `getPublicOrigin()` so desktop-app viewers also connect to the cloud relay.

4. **Guard the Go Live button in `LiveBroadcast.tsx`** — Detect local mode (hostname is `localhost` or `127.0.0.1`) and check whether a cloud URL is configured by calling `getPublicOrigin()`. If the result is still `localhost` (i.e. no cloud URL set), disable the Go Live button and show a small note: "Live streaming requires cloud sync to be configured. Go to Settings → Cloud Sync to set it up." This gives the organizer a clear next step instead of a cryptic error.

## Relevant files
- `artifacts/race-platform/src/contexts/BroadcastContext.tsx`
- `artifacts/race-platform/src/pages/public/WatchLive.tsx:11-15`
- `artifacts/race-platform/src/pages/organizer/LiveBroadcast.tsx`
- `artifacts/race-platform/src/lib/publicOrigin.ts`
- `artifacts/local-server/src/index.ts`
- `artifacts/api-server/src/lib/videoRelay.ts`
