# Event Draft Save & Drafts Section

## What & Why
Organizers sometimes start building an event but can't finish in one sitting. Today the form is a single dialog — closing it loses all progress. This adds a "Save as Draft" path so organizers can save a partially-filled event (name is the only required field), then find it in a dedicated Drafts section and continue later.

## Done looks like
- The event creation dialog has a **Save as Draft** button alongside the existing Save button. Clicking it only requires a name and immediately creates/saves the event with `status: draft`.
- A **Drafts** section appears on the Events list page (above or alongside the main event list), showing all `draft` status events with their name, date (if set), and a "Continue editing" action.
- Clicking "Continue editing" on a draft opens the full event edit form pre-populated with whatever fields were saved.
- When the organizer finishes and saves the full form, the event exits draft state normally (the existing status logic based on registration window applies).
- Draft events are clearly distinguished from published/active events and do not appear in the main active events list.

## Out of scope
- Auto-save / periodic background saves while the organizer is typing
- Draft versioning or history
- Notifying organizers about stale drafts
- Any change to how events transition out of `draft` status (the existing logic is unchanged)

## Steps
1. **Relax server-side validation for draft saves** — Add a `draft: true` flag (or a separate `POST /api/events/draft` route) that only requires `name` and `clubId`, setting `status: draft` unconditionally and leaving all other fields nullable/defaulted. The existing `POST /api/events` route (which auto-computes status from the registration window) is unchanged for full saves.

2. **Update OpenAPI spec and regenerate** — Add the new draft-create endpoint (or optional `draft` body param) to `lib/api-spec/openapi.yaml` so the typed hook is available in the frontend. Run codegen.

3. **Add "Save as Draft" button to the event creation dialog** — In `EventsList.tsx`, add a secondary "Save as Draft" button that validates only the name field, calls the draft endpoint, shows a success toast, and closes the dialog. The primary "Save" button continues to use the existing full-validation path.

4. **Add Drafts section to the Events list page** — In `EventsList.tsx`, query for events with `status: draft` and render them in a collapsible "Drafts" card above the main event list (or as a tab). Each row shows event name, date (or "No date set"), and a "Continue editing" button. Draft events must be excluded from the main active events list query.

5. **Wire "Continue editing" to the existing edit form** — Clicking "Continue editing" on a draft opens the existing event edit dialog (`EditEventDialog` or equivalent) pre-populated with the draft's saved fields. Saving from this form uses the existing `PATCH /api/events/:eventId` flow; status will advance out of `draft` once the registration window is set, per existing logic.

6. **Polish and empty state** — If there are no drafts, the Drafts section is hidden (or shows a subtle "No drafts" empty state). Add a small "Draft" badge to the draft rows so organizers understand what they are looking at.

## Relevant files
- `lib/db/src/schema/index.ts`
- `lib/api-spec/openapi.yaml`
- `artifacts/api-server/src/routes/events.ts`
- `artifacts/race-platform/src/pages/organizer/EventsList.tsx`
