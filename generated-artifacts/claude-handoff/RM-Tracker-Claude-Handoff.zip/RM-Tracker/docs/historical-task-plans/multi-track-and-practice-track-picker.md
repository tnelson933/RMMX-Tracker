# Multi-Track Management & Practice Track Picker

## What & Why
Organizers currently save one track name in club settings, and the local server's save endpoint is missing, causing a "not found" error. This task fixes that bug, lets clubs maintain a list of named tracks, wires a track picker into event creation and practice session creation, and gives riders per-track history views in the rider login portal and mobile app.

## Done looks like
- **Bug fix**: Saving the track/venue name in the local server Admin tab no longer returns "not found"
- **Track library**: Organizers can add, rename, and remove multiple track names from the Admin tab (e.g. "Thunder Valley MX", "Desert Ridge MX")
- **Event creation**: A dropdown shows the club's saved tracks; organizer can also type a new name not in the list
- **Practice session creation**: A dropdown shows the club's saved tracks; organizer can also type a new name. The session's `venueName` is stored from whichever was selected/entered
- **Rider history — web portal**: Rider can filter their practice session history by track to see sessions, total laps, and best lap at that specific track
- **Rider history — mobile app**: Same per-track breakdown available in the mobile app practice/history section

## Out of scope
- Track-level statistics for race events (only practice sessions)
- GPS coordinates or track maps
- Public track directory visible outside the club

## Steps

1. **Add `club_tracks` table to the DB schema** — New table with `id`, `club_id`, `name`, `created_at`. Add a Drizzle migration and run `db push`. Also update `drizzle-zod` exports so the new table is included in the shared validation layer.

2. **Cloud API: tracks CRUD endpoints** — Add routes under `/clubs/:clubId/tracks`: `GET` (list all tracks for the club), `POST` (create a track), `PATCH /:trackId` (rename), `DELETE /:trackId` (remove). Add to OpenAPI spec and run codegen to generate hooks and Zod schemas.

3. **Fix local server settings save ("not found")** — Add the missing `PUT /api/clubs/:clubId/settings` route to `artifacts/local-server/src/routes/clubs.ts` so the `usePutClubSettings` call from the UI resolves correctly.

4. **Local server: tracks CRUD routes** — Mirror the tracks routes in `artifacts/local-server/src/routes/` backed by the local SQLite schema. Add the `club_tracks` table to the local DB init script and auto-sync pull/push. Update `routes/index.ts` to register the new router.

5. **Admin tab — track library UI** — Replace the single track-name input on `TeamPage.tsx` with a list UI: display saved tracks, an "Add track" input, rename inline, delete with confirm. Use the new generated hooks.

6. **Event creation — track picker** — On the create/edit event form, replace the free-text track name field with a combobox: shows saved club tracks as options, allows free-text entry of a new name (does not auto-save it to the library unless the organizer adds it via Admin).

7. **Practice session creation — track picker** — On the "New Session" dialog in `StandalonePractice.tsx`, replace the auto-snapshot of the single club track with the same combobox (saved tracks + free-text). Store the chosen name in `venueName`.

8. **Rider web portal — per-track history** — On the rider's practice history page (rider login portal), add a track filter/tab. When a track is selected, show: sessions at that track, total laps, and personal best lap time. Derive this from the existing `venueName` field on practice sessions and crossings.

9. **Rider mobile app — per-track history** — Add a "By Track" view to the practice history section in the Expo app. Same data: sessions, total laps, best lap, grouped by `venueName`.

10. **Update AI assistant system prompt** — Add the tracks feature to the coverage list and body of `SYSTEM_PROMPT.md` so the organizer AI knows about it.

## Relevant files
- `lib/db/src/schema/index.ts`
- `lib/api-spec/openapi.yaml`
- `artifacts/api-server/src/routes/practice.ts`
- `artifacts/api-server/src/routes/clubs.ts`
- `artifacts/local-server/src/routes/clubs.ts`
- `artifacts/local-server/src/routes/index.ts`
- `artifacts/local-server/src/db-init.ts`
- `artifacts/race-platform/src/pages/organizer/TeamPage.tsx`
- `artifacts/race-platform/src/pages/organizer/StandalonePractice.tsx`
- `artifacts/api-server/src/routes/anthropic/SYSTEM_PROMPT.md`
