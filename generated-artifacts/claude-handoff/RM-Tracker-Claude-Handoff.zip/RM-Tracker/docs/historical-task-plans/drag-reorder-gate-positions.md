# Drag to reorder gate positions within a moto

## What & Why
Organizers need to reposition riders within a moto (e.g. move gate 2 to gate 4) by dragging a rider row and dropping it between other riders. Today, dropping a rider back onto the same moto does nothing — the drag handler short-circuits when source and target moto are the same.

## Done looks like
- Within any non-completed moto lineup, you can grab a rider's drag handle and drag it up or down the list
- A visible drop indicator (a highlighted gap line) appears between rows as you drag, showing exactly where the rider will land
- Dropping the rider between two others inserts them at that position; all gate numbers (`position`) update immediately in the UI (optimistic) and persist to the database
- Dragging from gate 2 to between gates 4 and 5 results in: former gate-3 rider moves to gate 2, ..., dragged rider lands at gate 4
- Works in both the full-page Motos view and the compact supercross-format view
- Completed motos remain locked (no reordering)

## Out of scope
- Reordering riders across different motos (already works)
- Changing gate positions on the public-facing results pages

## Steps

1. **Add between-row droppable slots inside each moto table** — Replace or augment the single whole-moto `DroppableZone` with individual slot targets rendered between each rider row (e.g. `gate-slot-{motoId}-{index}` for index 0…n). These slots should be slim, visually invisible at rest, and show a colored insertion bar when a same-moto rider is hovering over them.

2. **Handle same-moto reorder in `handleRiderDragEnd`** — Remove the early-return guard for `sourceMotoId === targetMotoId`. When the drop target is a `gate-slot-{motoId}-{index}`, compute the new ordered array (remove dragged rider, splice at the slot index), renumber `position` fields 1…n, apply optimistic update via `setLineupDrafts`, and persist with the existing `updateMutation`.

3. **Preserve cross-moto and trash drops** — Ensure no regressions: cross-moto moves still append to the target moto, trash still removes, moto card reorder still works.

## Relevant files
- `artifacts/race-platform/src/pages/organizer/Motos.tsx:509-576`
- `artifacts/race-platform/src/pages/organizer/Motos.tsx:908-1010`
- `artifacts/race-platform/src/pages/organizer/Motos.tsx:1677`
