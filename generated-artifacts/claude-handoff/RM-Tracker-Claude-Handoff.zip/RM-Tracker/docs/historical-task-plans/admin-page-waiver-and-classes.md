# Admin Page: Waiver Builder & Default Classes

## What & Why
Rename the "Team" nav item and page to "Admin", then add two new sections to that page:

1. **Rider Acknowledgement Form** — a rich text area where the organizer types out their custom rules/waiver. Saved per club and will later be displayed to riders at registration.
2. **Default Race Classes** — a list builder where the organizer defines reusable class templates (e.g. "125cc Class A", "250cc Class B"). Each entry has a name and optionally a displacement/category label. Saved per club for future reference (user will specify where they're pulled from in a follow-up task).

## Done looks like
- The sidebar nav item reads "Admin" instead of "Team" everywhere it appears (desktop nav, mobile drawer).
- The page heading reads "Admin" with a subtitle describing its purpose.
- The existing Team Members section is still present and fully functional, just below the page header.
- A new "Rider Acknowledgement Form" card section appears above Team Members with a multi-line text area. The organizer can type or paste their rules/waiver text. A "Save" button persists it. On page load, previously saved text is restored.
- A new "Default Race Classes" card section appears between the waiver and team members sections. The organizer can add a class by typing a name and clicking "Add Class". Each saved class appears as a row with a delete button. The list is persisted per club.
- Both new sections save to the database and survive a page refresh.

## Out of scope
- Rich text / markdown formatting for the waiver (plain text only for now).
- Pulling default classes into the event creation or registration flow (user will follow up).
- Any changes to the Team Members invite/permissions behavior.

## Steps

1. **DB schema** — Add a `club_settings` table with columns: `club_id` (FK → clubs, primary key), `rider_acknowledgement` (text, nullable), `default_classes` (jsonb, nullable, stores an array of `{ id, name }`). Run migration with `pnpm --filter @workspace/db run push`.

2. **API endpoints** — Add `GET /clubs/:clubId/settings` and `PUT /clubs/:clubId/settings` routes to the API server. Both are organizer-scoped (club_organizer role only, scoped to their own club). `PUT` accepts `{ riderAcknowledgement?: string, defaultClasses?: { id: string, name: string }[] }` and upserts the settings row.

3. **OpenAPI spec & codegen** — Add the two new endpoints to `lib/api-spec/openapi.yaml`, then run `pnpm --filter @workspace/api-spec run codegen` to regenerate typed hooks.

4. **Rename nav + page** — In `OrganizerLayout.tsx`, change the "Team" link label to "Admin". In `TeamPage.tsx`, update the page heading and subtitle to reflect the broader "Admin" purpose.

5. **Rider Acknowledgement Form UI** — Add a new card section at the top of the Admin page (above team members). Uses a `<Textarea>` bound to local state, loaded from the `useGetClubSettings` hook on mount, and saved via `usePutClubSettings` when the organizer clicks "Save".

6. **Default Race Classes UI** — Add a card section below the waiver. Shows a list of saved classes, each with a delete button. An inline "Add a class" row with a text input and "Add" button appends a new entry (with a generated UUID) and immediately saves the full updated list via `usePutClubSettings`.

## Relevant files
- `artifacts/race-platform/src/components/layout/OrganizerLayout.tsx`
- `artifacts/race-platform/src/pages/organizer/TeamPage.tsx`
- `lib/db/src/schema/index.ts`
- `lib/api-spec/openapi.yaml`
- `artifacts/api-server/src/routes/`
- `lib/api-client-react/src/generated/`
