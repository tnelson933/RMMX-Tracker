# Fix Profile Tab Sign Out Button Hidden by Tab Bar

## What & Why
On the Profile tab in the Rider App, the Sign Out button at the bottom of the page is obscured by the bottom tab bar and cannot be scrolled into view. The scroll container's `paddingBottom` uses `(tabBarHeight || insets.bottom) + 16` — when `tabBarHeight` from `BottomTabBarHeightContext` returns `0`, the fallback only adds `insets.bottom + 16`, which is not enough to clear the tab bar overlay.

## Done looks like
- Scrolling to the bottom of the Profile tab reveals the Sign Out button fully above the tab bar with clear breathing room.
- No other content is clipped or hidden on the Profile tab.

## Out of scope
- Changes to any other tab's scroll behavior.
- Redesigning the Profile tab layout.

## Steps
1. **Fix the `paddingBottom` calculation** — In `ProfileList` in `profile.tsx`, change the `container` style's `paddingBottom` from `(tabBarHeight || insets.bottom) + 16` to `tabBarHeight + insets.bottom + 24`. This ensures both values are always combined, matching the pattern used in other tabs (e.g. `train.tsx`), so the sign out button is always scrollable above the tab bar regardless of what `BottomTabBarHeightContext` returns.

## Relevant files
- `artifacts/rider-app/app/(tabs)/profile.tsx:217`
