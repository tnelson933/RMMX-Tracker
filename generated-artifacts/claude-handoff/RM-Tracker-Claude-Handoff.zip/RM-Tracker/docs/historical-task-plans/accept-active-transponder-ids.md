# Accept Active Transponder IDs

## What & Why
Update active-transponder validation on the organizer check-in workflow so PowerTag identifiers containing hexadecimal letters, such as `1a420074`, are accepted instead of being rejected by the legacy numeric-only MyLaps rule.

## Done looks like
- Organizers can assign `1a420074` from the check-in page and complete the rider's check-in without an invalid-ID warning
- PowerTag active IDs are accepted consistently for both rider-owned and rental transponder assignment paths
- Uppercase and lowercase hexadecimal IDs are handled consistently with timing identity matching
- Existing numeric transponder identifiers remain valid for historical compatibility
- Empty or malformed identifiers still produce a clear validation error

## Out of scope
- Changes to active timing reader communication, crossing ingestion, or loop configuration
- Renaming legacy database columns
- Changes to passive RFID tag validation

## Steps
1. **Define active-ID validation** — Replace the numeric-only MyLaps assumption with a shared PowerTag-compatible active-transponder rule that accepts hexadecimal IDs while retaining valid historical numeric identifiers and consistent casing behavior.
2. **Apply it across check-in assignment paths** — Use the same rule for check-in display/blocking, direct active-ID assignment, and rental transponder assignment so an accepted ID is never subsequently marked invalid.
3. **Verify compatibility** — Add focused regression coverage for the sample PowerTag ID, uppercase/lowercase variants, legacy numeric identifiers, and malformed values, then run the relevant type and build checks.

## Relevant files
- `artifacts/race-platform/src/pages/organizer/Checkin.tsx`
- `artifacts/api-server/src/routes/registrations.ts`
- `artifacts/api-server/src/routes/rfid.ts`
- `artifacts/api-server/src/lib/riderTimingIdentity.ts`