# Completed Race Standings on Public Event Page

## What & Why
When a moto finishes, spectators on the public event page should immediately see the final standings and be able to drill into a rider's individual lap times — all without leaving the page. This applies to both the Live Standings tab (during race day) and the Race Schedule tab (both live and results modes).

## Done looks like
- Completed motos in the **Live Standings tab** show a "Race Complete" badge next to the moto name header, followed by the final finishing order (position, bib, rider name, total time, points)
- Completed motos in the **Race Schedule tab** (both live mode and results mode) show the final standings when expanded instead of the pre-race lineup grid
- Clicking any rider row in a completed moto's standings opens a modal showing that rider's individual lap times for that moto (lap number, split time, best lap highlighted)
- Motos that are still scheduled or in progress are unaffected — they keep their current behavior

## Out of scope
- Live/in-progress lap updates (SSE) — lap times shown are from the stored results only
- Exporting or sharing individual lap time data
- Changes to the organizer portal

## Steps

1. **`LapTimesModal` component** — Build a Dialog/Sheet that accepts a `RaceResult` object and renders a numbered lap list. Format each lap from milliseconds to `m:ss.000`. Highlight the fastest lap row. Show rider name and moto name in the header.

2. **Update `ResultTable` to support click-through** — Add an optional `onRiderClick?: (result: RaceResult) => void` prop. When provided, make each row clickable (cursor-pointer, hover highlight). Clicking fires the callback with that result. Wire the modal state and `LapTimesModal` into `EventResults` at the top level so it is shared across both tabs.

3. **"Race Complete" badge on Live Standings tab** — In the live-mode standings section, for each moto group, look up the matching `Moto` object by `motoName` to check its status. If `status === "completed"`, render a green "Race Complete" badge (CheckCircle icon) alongside the moto name header. Pass `onRiderClick` down to `ResultTable`.

4. **Completed-moto standings in the Race Schedule tab** — Pass the full `results` array down to `MotoScheduleRow` as a new optional `results` prop. Inside `MotoScheduleRow`, when the moto `status === "completed"` and matching results exist (filter by `motoId`), replace the pre-race lineup grid with a compact standings table (position, bib, rider name, total time) sorted by position. Keep the existing lineup grid for non-completed motos. Make each standings row clickable with an `onRiderClick` callback prop also threaded down into `MotoScheduleRow`.

5. **Wire lap-times modal through the Race Schedule tab** — Lift a single `selectedResult` state into `EventResults`. Both the standings tab and schedule tab share it. Render `LapTimesModal` once at the bottom of the component, driven by `selectedResult`.

## Relevant files
- `artifacts/race-platform/src/pages/public/EventResults.tsx`
- `lib/api-client-react/src/generated/api.schemas.ts`
