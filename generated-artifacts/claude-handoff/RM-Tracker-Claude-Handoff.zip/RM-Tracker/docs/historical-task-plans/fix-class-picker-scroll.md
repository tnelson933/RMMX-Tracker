# Fix Race Class List Scroll Jump

## What & Why
When adding classes to an event (either by clicking a "Club Classes" badge or the "Add Class" button), the page jumps to the bottom after each addition because the class row list has no scroll boundary — it just grows the page and the browser scrolls to bring the new input into view.

## Done looks like
- The class rows area has a fixed max height with its own scrollbar
- Clicking a Club Classes badge or "Add Class" does not move the page scroll position
- When a new row is appended, the rows container scrolls to show the new row (not the whole page)
- The Club Classes badge strip stays visible above the scrollable rows area at all times

## Out of scope
- Changing how classes are saved or validated
- Reordering class rows (drag and drop)

## Steps
1. **Wrap the class rows in a scroll container** — In `EventDetail.tsx`, wrap the `fields.map(...)` block (the grid of Name / Series / Max Riders / Remove rows) in a `div` with `max-h-[280px] overflow-y-auto` (or similar) and a `ref` so the container can be scrolled programmatically.

2. **Scroll to bottom on append** — After each `append()` call (both from the Club Classes badge `onClick` and the "Add Class" button `onClick`), use a `useEffect` or direct ref scroll to scroll the rows container to its bottom, so the newly added row is visible without moving the page.

## Relevant files
- `artifacts/race-platform/src/pages/organizer/EventDetail.tsx:843-999`
