# Restore Live Broadcast Reliability

## What & Why
Fix the failure mode where a live video broadcast works briefly and then stops, with announcer audio stopping at the same time. The Watch Live experience should survive transient relay, proxy, and media playback interruptions without ending the organizer’s broadcast or silently abandoning commentary.

## Done looks like
- A continuous broadcast remains playable beyond the point where it currently dies, including under sustained streaming and normal viewer joins.
- A transient broadcaster or viewer connection drop reconnects automatically without an obsolete socket marking the replacement broadcast as ended.
- Slow or stalled viewers cannot build an unbounded relay/client queue or destabilize the broadcast for everyone else.
- Viewers recover from media decode or playback stalls at a valid live video boundary instead of freezing permanently.
- The shared announcer continues with current race calls after connection recovery and does not replay stale or duplicate commentary.
- Organizer and viewer screens show a clear reconnecting or failed state when recovery is underway or truly exhausted.
- Automated coverage exercises broadcaster replacement, prolonged streaming, slow viewers, viewer stall recovery, and announcer continuity through reconnects.

## Out of scope
- Changing announcer voice, writing style, or race commentary content.
- Redesigning Watch Live or adding new video controls.
- Changing timing and scoring calculations.
- Recording, archiving, or replaying live video.

## Steps
1. **Reproduce and instrument the cutoff** — Add focused diagnostics and a sustained-stream test that distinguishes broadcaster socket loss, relay shutdown, viewer backpressure, media decode stalls, timing-feed loss, and announcer delivery failure without logging media payloads or sensitive data.
2. **Harden broadcaster replacement and recovery** — Ensure close/error events from superseded sockets cannot end a newer broadcast, and make transient reconnect handling preserve capture while exposing an accurate recovery state rather than stopping after a small fixed retry window.
3. **Bound relay and viewer buffering** — Apply backpressure limits and stale-viewer eviction on the relay, cap client media queues, and recover at a valid initialization/keyframe/GOP boundary when a viewer falls behind or an append fails.
4. **Keep Watch Live services synchronized** — Coordinate video, live timing, and the shared announcer lifecycle so each channel reconnects independently while the page resumes the current moto state without stale intros, duplicate calls, or silent announcer abandonment.
5. **Validate long-running behavior** — Cover sustained playback, broadcaster reconnect races, delayed consumers, missing periodic keyframes, viewer decode stalls, timing-feed reconnects, and announcer continuation with automated tests plus a browser-level soak check.

## Relevant files
- `artifacts/race-platform/src/contexts/BroadcastContext.tsx`
- `artifacts/race-platform/src/pages/public/WatchLive.tsx`
- `artifacts/api-server/src/lib/videoRelay.ts`
- `artifacts/api-server/src/routes/timing.ts`
- `artifacts/api-server/src/routes/motos.ts`
