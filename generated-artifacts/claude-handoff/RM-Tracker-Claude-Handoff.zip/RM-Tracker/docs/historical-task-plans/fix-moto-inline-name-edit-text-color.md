# Fix Invisible Text When Editing Moto Name

## What & Why
When an organizer clicks to rename a staggered or combined moto inline, the text they type becomes invisible (or very hard to read) because the `Input` field inside `InlineName` uses `bg-background` but has no explicit text color class. The typed text inherits the surrounding card header's color context and blends into the background.

## Done looks like
- Typing in the moto name inline-edit field shows clearly visible, readable text in all themes (light and dark).
- The input appearance is consistent with the rest of the organizer UI (uses `text-foreground` so it respects the active theme).
- No change to any other functionality — only the input styling is affected.

## Out of scope
- Redesigning the inline edit interaction
- Changing any other input fields elsewhere in the app

## Steps
1. **Fix the Input className in `InlineName`** — Add `text-foreground` to the `className` on the `Input` element inside the `InlineName` component so the typed text is always readable regardless of surrounding context.

## Relevant files
- `artifacts/race-platform/src/pages/organizer/EventSchedule.tsx:337-358`
