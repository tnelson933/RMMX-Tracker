# Enter Results: Class/Moto Nav + Lap Time Editor

## What & Why
Two UX improvements to the Enter Results page:

1. **Navigation redesign** — The current single moto dropdown is confusing. Organizers think in terms of classes, not moto IDs. Replace it with a class filter at the top, then display all motos for that class as a list below so the organizer can see and act on everything at once.

2. **Lap time visibility and editing** — The table currently shows only position, total time, and DNF/DNS. Organizers need to see lap counts and be able to view/edit/add individual lap splits before publishing, especially when a scan was missed or needs correction.

## Done looks like

### Navigation
- A **class selector** replaces (or sits above) the current moto dropdown. Options are each race class present in the event, plus an **"All Classes"** option.
- When a class is selected, all motos for that class are shown below as stacked sections (one section per moto), in moto run order.
- When "All Classes" is selected, all motos across all classes appear in the same order they were scheduled to run (i.e. sorted by `motoNumber` / scheduled sequence), with a class label on each section header.
- Each moto section is independently editable — its own position/time/lap inputs and its own "Save" action (or a single "Save All" at the bottom).

### Lap Times
- Each rider row in a moto section shows a **Laps** column with the count of entries in their `lapTimes` array (or "—" if none).
- Clicking a rider row expands an inline panel listing all lap times numbered lap 1, lap 2, etc., each in `M:SS.mmm` format.
- Within that panel, organizers can:
  - **Edit** any lap time in place.
  - **Delete** a lap.
  - **Add** a lap (append a blank row).
- Total time auto-recalculates as the sum of laps when laps are edited. If the organizer manually overrides total time, their value is preserved (tracked per-rider).
- Lap times are included in the save payload as a milliseconds array.
- Invalid lap time format shows an inline error and blocks save.

## Out of scope
- Live lap streaming / RFID updates on this page (Race Day / WatchLive flow).
- Changes to the public-facing results display.
- Reordering motos or changing the scheduled run order.

## Steps
1. **Build the class selector** — Add a class dropdown at the top of the page. Derive the class list from the loaded motos. Include an "All Classes" option as the default.

2. **Replace the moto dropdown with a moto list** — Remove the single moto dropdown. Instead, render one collapsible/stacked section per moto, filtered by the selected class. Sort sections by scheduled run order (`motoNumber`). Each section header shows moto number, class, and status badge.

3. **Add Laps column to the results table** — Insert a read-only "Laps" column in each moto section's rider table, derived from the rider's `lapTimes` array length.

4. **Wire lap times into local state** — When `useListResults` loads, populate a per-rider `lapTimes` array alongside position/time/dnf in the existing `resultsData` state.

5. **Build the inline lap-time editor panel** — Make each rider row expandable via a chevron or row click. The expanded area renders numbered lap time inputs with delete buttons and an "Add lap" button.

6. **Auto-recalculate total time from laps** — On any lap add/edit/delete, recompute total time as the sum of laps. Track a `totalTimeOverridden` flag per rider to preserve manual overrides.

7. **Include lapTimes in the save payload** — Convert each rider's lap time strings to milliseconds and include them in the POST body alongside position, totalTime, dnf, dns.

8. **Validation** — Block save and show inline errors for any unparseable lap time strings.

## Relevant files
- `artifacts/race-platform/src/pages/organizer/EnterResults.tsx`
- `artifacts/api-server/src/routes/results.ts`
- `lib/api-spec/openapi.yaml`
- `lib/db/src/schema/index.ts`
