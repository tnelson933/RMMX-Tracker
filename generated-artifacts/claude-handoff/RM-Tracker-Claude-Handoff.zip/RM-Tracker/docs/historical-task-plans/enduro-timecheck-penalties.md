# Enduro Time-Check Penalties

## What & Why
Enduro time checks already let organizers set a per-class expected arrival time at each checkpoint, but nothing currently happens when a rider arrives early or late. This adds an organizer-configurable penalty system on the Generate Tests screen: extra time added for being early or late, and disqualification thresholds for being too early or too late. Penalties roll into each rider's overall time so the leaderboard reflects timekeeping accuracy.

## Decisions baked in (confirm or adjust on review)
- **Penalty config lives per event** — one scheme applies to every checkpoint in that race.
- **Counted per whole minute** — e.g. 2 min 40 sec late counts as 2 minutes (matches "for every 1 minute" wording). Less than a full minute early/late = no penalty.
- **Multiple checkpoints add up** — penalty is summed across every checkpoint a rider passes.
- Four configurable values: seconds added per minute early, seconds added per minute late, disqualify-if-more-than-N-minutes-early, disqualify-if-more-than-N-minutes-late. The two DQ thresholds are optional (blank = never DQ on that side).

## Done looks like
- On the Generate Tests screen, when Time Checks are enabled, organizers see a "Penalties" section with four inputs: seconds per minute early, seconds per minute late, DQ if more than X minutes early, DQ if more than X minutes late.
- These settings save with the event and reload when the screen is reopened.
- As riders' arrivals are recorded at each checkpoint (via RFID time-check readers, plus a manual arrival entry), the system compares actual arrival to that class's expected arrival.
- Each rider's overall time gains the correct penalty seconds; riders past a DQ threshold are marked disqualified and drop to the bottom of the standings.
- Organizer results/report and public results show the penalty seconds applied and a clear DQ indicator.

## Out of scope
- Per-checkpoint (rather than per-event) penalty schemes.
- Prorated-by-the-second penalty counting (using whole-minute counting instead).
- Editing/overriding an individual rider's recorded arrival history beyond a basic manual arrival entry.

## Steps
1. **Storage** — Add a per-event enduro penalty configuration (early sec/min, late sec/min, optional early-DQ and late-DQ minute thresholds). Reintroduce a checkpoint-arrivals table that records each rider's actual arrival time at each time check (event, time check, rider, arrival time).
2. **Record arrivals** — Update the reader ingest time-check handling to persist an arrival row instead of only acknowledging it, and add a simple endpoint + organizer control to record/correct a rider's checkpoint arrival manually when there is no RFID at that checkpoint.
3. **Penalty config in API contract** — Extend the event (or time-checks) API so the four penalty values can be saved and read back; regenerate the typed client.
4. **Scoring** — When computing enduro standings, for each rider and each checkpoint with a target for their class, compute minutes early/late vs the expected arrival, add the configured penalty seconds to the rider's overall time (whole-minute counting, summed across checkpoints), and mark the rider disqualified if they exceed either DQ threshold. Disqualified riders sort last.
5. **Generate Tests UI** — Add the Penalties section (four inputs, only shown when Time Checks are enabled) to the Generate Tests flow; wire save/load alongside the existing time-check settings.
6. **Results display** — Surface penalty seconds and a DQ badge in the organizer report/results view and the public enduro results.
7. **AI assistant prompt** — Update the organizer assistant knowledge base (SYSTEM_PROMPT.md) to document the new penalty configuration and how it affects scoring.

## Relevant files
- `artifacts/race-platform/src/pages/organizer/EventSchedule.tsx:1002-1320,2000-2017,3100-3140`
- `lib/db/src/schema/enduro_time_checks.ts`
- `lib/db/src/schema/events.ts`
- `lib/db/src/schema/index.ts`
- `artifacts/api-server/src/routes/reader-ingest.ts:101-160`
- `artifacts/api-server/src/routes/timing.ts:349-475`
- `artifacts/api-server/src/routes/results.ts:39-210`
- `lib/api-spec/openapi.yaml`
- `artifacts/race-platform/src/pages/public/EventResults.tsx`
- `artifacts/api-server/src/routes/anthropic/SYSTEM_PROMPT.md`
