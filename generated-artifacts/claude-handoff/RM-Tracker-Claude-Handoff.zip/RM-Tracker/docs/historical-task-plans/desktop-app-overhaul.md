# Fix All Broken Functionality in Desktop App

## What & Why

A thorough audit of the desktop app's local server reveals that several API routes called by the organizer portal either don't exist in the local server at all, or have mismatched path names compared to the OpenAPI spec. These gaps cause 404 errors throughout the app — most critically, the entire Event Detail page fails to load after creating an event, the Dashboard stats never populate, and the Series leaderboard is always blank. Additionally, some pages still call Stripe and other cloud-only endpoints even when running as a desktop app, producing visible error toasts.

This task fixes every identified gap so the desktop app works identically to the online portal for all offline-capable operations.

## Done looks like

- Creating an event and clicking into it loads the full Event Detail page without errors
- Dashboard stats (upcoming events, total riders, registrations, check-ins) display correctly
- Series leaderboard loads on the Series page
- Organizer can delete an event from the Events list
- Organizer can add rider registrations from within the Event Detail page
- No Stripe-related error toasts appear anywhere in the desktop app
- All other organizer pages (Report, Registrations, RiderDetail, PointsTables, ReaderSetup) load without console errors or 404s
- Desktop version bumped and released as v1.0.49

## Out of scope

- Stripe payments on desktop (intentionally disabled — desktop is offline-only)
- Rider portal on desktop
- Public-facing pages on desktop
- Admin/super-admin routes

## Steps

1. **Add `GET /events/:eventId` to local server** — This is the most critical missing route. It must query the local SQLite DB for a single event by ID and return the same shape as the cloud server. Without it, every event detail page 404s immediately after creation.

2. **Fix the `raceday-summary` route name mismatch** — The local server serves this route as `/events/:eventId/race-day-summary` but the OpenAPI spec (and generated frontend hooks) call `/events/:eventId/raceday-summary`. Rename or alias the local route to match the spec.

3. **Fix the series `leaderboard` route name mismatch** — Local server exposes `/series/:seriesId/points` but the frontend calls `/series/:seriesId/leaderboard`. Rename or alias to match the spec.

4. **Add `GET /dashboard/club/:clubId` to local server** — Dashboard page calls this endpoint for stats (upcoming events, total riders, registrations, check-ins). Implement it with the same shape as the cloud version, querying local SQLite.

5. **Add `DELETE /events/:eventId` to local server** — Organizers need to be able to delete events while working offline. Implement the route to remove the event and its associated motos/results from local SQLite.

6. **Add `POST /events/:eventId/registrations` to local server** — Without this route, organizers cannot add rider registrations while working offline. Implement it to insert a new registration row into local SQLite.

7. **Add `PATCH /auth/me` to local server** — Profile update fails silently on desktop. Implement the route to update the local user record (name, email, password if provided).

8. **Add `POST /series/:seriesId/recalculate` to local server** — Series points recalculation is unavailable on desktop. Implement it to recalculate and upsert series_points rows from local race results.

9. **Guard all Stripe and cloud-only API calls with `isDesktop` checks** — Audit `Registrations.tsx`, `Report.tsx`, `EventsList.tsx`, `RiderDetail.tsx`, `PointsTables.tsx`, and `ReaderSetup.tsx` for any query or mutation that calls a Stripe endpoint or other cloud-only route. Wrap those calls with `enabled: !isDesktop` and hide any related UI sections with `{!isDesktop && ...}` so they never appear or error in the desktop build.

10. **Bump desktop version to 1.0.49 and update Home.tsx download links** — Increment `version` in `artifacts/desktop/package.json` from current to `1.0.49`. Update `RELEASE_TAG` in `artifacts/race-platform/src/pages/public/Home.tsx` to `"desktop-v1.0.49"`.

## Relevant files

- `artifacts/local-server/src/routes/events.ts`
- `artifacts/local-server/src/routes/series.ts`
- `artifacts/local-server/src/routes/auth.ts`
- `artifacts/local-server/src/routes/index.ts`
- `artifacts/api-server/src/routes/events.ts`
- `artifacts/api-server/src/routes/series.ts`
- `artifacts/api-server/src/routes/dashboard.ts`
- `artifacts/local-server/src/db-init.ts`
- `artifacts/race-platform/src/pages/organizer/Dashboard.tsx`
- `artifacts/race-platform/src/pages/organizer/EventDetail.tsx`
- `artifacts/race-platform/src/pages/organizer/Series.tsx`
- `artifacts/race-platform/src/pages/organizer/Registrations.tsx`
- `artifacts/race-platform/src/pages/organizer/Report.tsx`
- `artifacts/race-platform/src/pages/organizer/EventsList.tsx`
- `artifacts/race-platform/src/pages/organizer/RiderDetail.tsx`
- `artifacts/race-platform/src/pages/organizer/PointsTables.tsx`
- `artifacts/race-platform/src/pages/organizer/ReaderSetup.tsx`
- `artifacts/desktop/package.json`
- `artifacts/race-platform/src/pages/public/Home.tsx`
- `lib/api-spec/openapi.yaml`
