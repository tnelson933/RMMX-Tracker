# Full-Screen Live Race Analytics

## What & Why
Turn the public live-race page into an immersive, full-screen race viewer with three clear modes: the existing live timing table, quick race analytics, and a fastest-lap ranking. Viewers should be able to switch views without leaving the live race or scrolling through the surrounding site layout.

## Done looks like
- Opening a live race uses the full available viewport instead of leaving the viewer in a partially scrolled page.
- A top navigation control has exactly three tabs: **Live Timing**, **Quick Analytics**, and **Fastest Lap**.
- Live Timing preserves the current rider order, position, laps, last lap, total time, and time-back presentation and continues updating from the live stream.
- Quick Analytics shows:
  - Moving Up — the rider who gained the most positions during the most recently completed lap.
  - Most Passes — the rider with the greatest total position gain from the end of lap 1 to the current order, including both positions.
  - Falling Back — the rider with the greatest position loss from the end of lap 1 to the current order.
  - Fastest Lap — the rider with the fastest lap in the race and the margin to the next-fastest rider.
- Fastest Lap lists every rider with their best recorded lap, sorted fastest to slowest.
- Analytics update whenever a new live timing snapshot arrives and handle missing or insufficient lap history with clear empty-state copy.
- The page remains usable on mobile and desktop, with accessible active-tab states and readable timing values.

## Out of scope
- Changes to organizer timing controls, RFID processing, or race scoring rules.
- A historical analytics page for completed events.
- Predictive estimates for riders who have not completed a full lap.
- Changes to the existing event results page’s separate schedule/standings tabs.

## Steps
1. Extend the live leaderboard data contract with race-history analytics derived from recorded crossings and lap times, preserving the existing live timing fields and SSE behavior.
2. Refactor the public live race screen into a full-viewport layout with a top-level three-tab navigation, retaining the existing live timing table as the default view.
3. Build the Quick Analytics callouts and Fastest Lap table from the live snapshot, including calculation labels, comparison values, loading/empty states, and responsive styling.
4. Verify the demo and real live-race flows at mobile and desktop widths, including SSE updates, reconnect behavior, route loading, and TypeScript/build validation.

## Relevant files
- `artifacts/race-platform/src/pages/public/LiveLeaderboard.tsx`
- `artifacts/api-server/src/routes/timing.ts:178-250`
- `artifacts/api-server/src/routes/timing.ts:1261-1297`
- `artifacts/api-server/src/routes/dashboard.ts:632-676`
- `artifacts/race-platform/src/App.tsx:203-205`