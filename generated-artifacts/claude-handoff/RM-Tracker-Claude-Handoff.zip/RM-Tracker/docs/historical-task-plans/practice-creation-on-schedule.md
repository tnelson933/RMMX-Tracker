# Add Practice Creation to Event Schedule

## What & Why
Organizers need a dedicated way to add practice sessions to the event schedule where they can select one or more classes that will ride in that session. Currently, motos only support a single class. This adds a "Create Practice" action and supports multi-class practice motos.

## Done looks like
- A "Add Practice" button (or action) is visible on the Schedule page alongside the existing "Add Moto" button
- Clicking it opens a dialog with:
  - A list of all event classes shown as checkboxes (multi-select)
  - An optional name field (auto-fills like "Practice 1", "Practice 2" based on how many practices exist)
  - A lap count field (defaults to 3 or whatever the event default is)
- The organizer can check 1–4+ classes and submit
- The new practice moto appears in the run order on the schedule
- Practice cards on the schedule display all selected classes (e.g., "250 Amateur · 125 Beginner · Open Pro")
- Existing single-class motos are unaffected

## Out of scope
- Auto-populating lineups with riders from the selected classes at creation time
- Generating multiple split practice groups per class (that's the existing "Generate Lineups" flow)
- Changes to the public heat sheet display (that's a separate proposed task #80)

## Steps

1. **DB schema — add `raceClasses` column**: Add a nullable `text[]` column called `raceClasses` to the `motosTable`. When set, this overrides `raceClass` for display. Existing motos with only `raceClass` are unaffected. Run a migration.

2. **OpenAPI spec — extend Moto model**: Add `raceClasses` (optional string array) to the `Moto` schema in `openapi.yaml`. Add a `CreatePracticeMoto` request body (or extend `CreateMoto`) to accept `raceClasses` as an array. Re-run codegen.

3. **API — handle `raceClasses` on create**: In the create moto route handler, accept `raceClasses` in the request body. When it is present and non-empty, persist it to the new column. Set `raceClass` to the first entry (for any legacy code that reads the single-class field).

4. **Frontend — "Add Practice" dialog**: Add an "Add Practice" button on the schedule page header toolbar. Build a dialog that lists all event `raceClasses` as checkboxes (pulled from the event data already loaded on the page). Include auto-named default (e.g., "Practice 1") and a lap count input. Submit calls the create moto API with `type: "practice"` and the selected `raceClasses` array.

5. **Frontend — schedule card display**: Update the moto card component on the schedule to show all values from `raceClasses` when the field is populated (e.g., as a comma/dot-separated tag row under the moto name). Falls back to the existing `raceClass` display for non-practice or single-class motos.

## Relevant files
- `lib/db/src/schema/motos.ts`
- `lib/api-spec/openapi.yaml`
- `artifacts/api-server/src/routes/motos.ts`
- `artifacts/race-platform/src/pages/organizer/EventSchedule.tsx`
