# Per-Class Series Assignment on Events

## What & Why
Organizers need to assign one or more series to each race class individually on the event creation/edit page. A rider in a single class (e.g. "150cc") should be able to earn points in two different series simultaneously, each applying its own scoring rules. Currently series are linked at the event level with no class-level granularity.

## Done looks like
- In the event edit form, each class row has a multi-select dropdown between the Class Name field and the Max Riders field showing all of the club's series; organizers can pick zero, one, or multiple series per class
- Saving the event persists which series each class is mapped to
- When motos are scored and results finalized for an event, riders in a class that maps to multiple series receive points in all of those series (each calculated independently using its own scoring table)
- The existing single-event series selector (the one that links a whole event to one series) continues to work unchanged — the new per-class map is additive

## Out of scope
- Retroactively recalculating points for historical events
- Changing how the leaderboard or standings pages display dual-series riders (existing display is unchanged)
- Modifying the "series_points" gate seeding method (still uses the first series linked to the event)

## Steps

1. **DB migration** — Add a `raceClassSeriesMap` jsonb column to `eventsTable` typed as `Record<string, number[]>` (class name → array of series IDs), defaulting to `{}`. Run `pnpm --filter @workspace/db run push` to apply.

2. **OpenAPI spec** — Add `raceClassSeriesMap` as an optional object with `additionalProperties: { type: array, items: integer }` to the `Event`, `EventInput`, and `EventUpdateInput` schemas in `lib/api-spec/openapi.yaml`. Run codegen after.

3. **API route — save** — In the events route (`artifacts/api-server/src/routes/events.ts`), read `raceClassSeriesMap` from the request body on both POST and PATCH and persist it to the DB column.

4. **Form schema + UI** — In `artifacts/race-platform/src/pages/organizer/EventDetail.tsx`:
   - Add `seriesIds: z.array(z.number()).default([])` to each item in the `raceClasses` Zod array schema.
   - When loading an existing event, populate each class's `seriesIds` from `event.raceClassSeriesMap`.
   - Widen the class row grid from `grid-cols-[1fr_140px_32px]` to `grid-cols-[1fr_1fr_140px_32px]` and insert a multi-select dropdown (using shadcn Popover + Checkbox pattern already used elsewhere) that lists `clubSeriesList`. The selected values bind to `raceClasses.${index}.seriesIds`.
   - On submit, build `raceClassSeriesMap` from the field array and include it in the `updateEvent` / `createEvent` mutation payload.

5. **Series points calculation** — In `artifacts/api-server/src/routes/motos.ts` (or wherever results are finalized and `series_points` rows are written), update the points-awarding logic so that for each completed moto it:
   - Reads `event.raceClassSeriesMap` for the moto's class.
   - For every series ID in that list (not just the single event-level series), looks up that series' `scoringTableId`, calculates position-based points, and upserts a row into `seriesPointsTable`.

## Relevant files
- `lib/db/src/schema/events.ts`
- `lib/api-spec/openapi.yaml`
- `artifacts/api-server/src/routes/events.ts`
- `artifacts/api-server/src/routes/motos.ts`
- `artifacts/api-server/src/routes/series.ts`
- `artifacts/race-platform/src/pages/organizer/EventDetail.tsx`
