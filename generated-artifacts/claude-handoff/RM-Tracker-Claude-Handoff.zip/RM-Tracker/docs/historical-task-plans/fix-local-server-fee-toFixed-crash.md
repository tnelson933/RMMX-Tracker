# Fix local server fee crash on Registrations page

## What & Why
The Registrations page crashes with `TypeError: Ie.toFixed is not a function` on the local (desktop) server. The local server's `serializeEvent` returns `entryFee` and `transponderRentalFee` as raw SQLite values — because the cloud API stores those columns as text strings (e.g. `"25.00"`), they arrive in SQLite as strings and are passed through to the frontend without a `Number()` conversion. The frontend then calls `.toFixed(2)` on a string and blows up. The `amountPaid` field in `deserializeReg` has the same problem (used on the payment-done confirmation screen).

## Done looks like
- The Registrations page loads without crashing on the local/desktop server
- Entry fee, transponder rental fee, and amount paid display correctly as formatted dollar amounts
- No runtime `toFixed is not a function` errors anywhere on the page

## Out of scope
- Any changes to the cloud API server or race-platform frontend
- Other pages or routes in the local server

## Steps
1. **Fix `serializeEvent` in the local server's events route** — Wrap `entryFee` and `transponderRentalFee` with `Number()` (matching the cloud API pattern): `entryFee: e.entry_fee ? Number(e.entry_fee) : null` and `transponderRentalFee: e.transponder_rental_fee ? Number(e.transponder_rental_fee) : null`.

2. **Fix `deserializeReg` in the local server's registrations route** — Wrap `amountPaid` with a numeric coercion: `amountPaid: r.amount_paid != null ? Number(r.amount_paid) : null`.

3. **Rebuild the local-server and race-platform bundles** — Run `pnpm --filter @workspace/local-server run build` and `pnpm --filter @workspace/race-platform run build` (with required env vars) so the fix is baked into the assets the desktop app serves.

## Relevant files
- `artifacts/local-server/src/routes/events.ts:21-52`
- `artifacts/local-server/src/routes/registrations.ts:6-27`
