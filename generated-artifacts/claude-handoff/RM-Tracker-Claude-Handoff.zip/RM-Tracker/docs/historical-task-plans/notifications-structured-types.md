# Structured Notification Types with Time-Windowed Events

## What & Why
Replace the free-form push notification UI with structured notification types that auto-generate the message. Tighten the event filter so only events within the valid sending window appear in the dropdown, and extend that window to 24 hours after the event ends (not midnight on event day). Add a matching notifications route to the local server so organizers using the desktop app can send the same types.

## Done looks like
- The event dropdown on the Notifications page only shows events that fall within the allowed window: 24 hours before the event starts through 24 hours after the event ends. Events outside that window are hidden entirely — not shown as disabled options.
- Instead of a free-form title and body, organizers pick a notification type from a dropdown:
  - **Schedule Change / Delay** — choose a delay reason (Weather, Track Maintenance, Timing Delay), enter an expected resumption time, and the title/body are auto-generated. A "Cancel for the day" toggle changes the message to a day-cancellation notice that also asks for the continuation date.
  - **Weather Alert** — describe the incoming conditions in a short field; the title and preview body auto-generate.
- A read-only preview of the generated title and body is shown before sending so the organizer can see exactly what riders will receive.
- The backend timing window is extended so `windowEnd = event date + 24 hours` (was previously midnight on the event date).
- The local server (`artifacts/local-server`) has a `POST /admin/notifications/broadcast` route that applies the same timing window and 4-hour rate limit, sends push tokens via the shared `sendPushNotifications` helper, and is wired into the local server's Express app.

## Out of scope
- Changing automatic race-day notifications (next-up / 3-away)
- Super admin broadcast-all behavior
- Adding new notification types beyond the two listed above
- Persisting notification history or a send log

## Steps
1. **Extend the backend timing window** — In `artifacts/api-server/src/routes/notifications.ts`, change `windowEnd` from `end-of-event-day (23:59:59)` to `eventDate midnight + 48 hours` (i.e. 24 hours after the last possible end of the event day). Update the error message text to match.

2. **Add notifications route to the local server** — Create `artifacts/local-server/src/routes/notifications.ts` mirroring the cloud route's broadcast logic: session auth, event lookup, same timing window formula, 4-hour rate limit using `lastPushSentAt` on the users table, rider → account → push token resolution, and dispatch via the push helper. Wire it into `artifacts/local-server/src/routes/index.ts`.

3. **Filter events in the dropdown** — In `Notifications.tsx`, filter the events list before rendering the `<Select>` so only events within the `[now - 24h, eventDate + 48h]` window appear. Remove the after-selection timing error state since ineligible events are never shown.

4. **Add notification type selector** — Replace the title/body inputs with a notification type `<Select>` (Schedule Change/Delay, Weather Alert). Below it render the appropriate fields for the selected type.

5. **Schedule Change / Delay fields** — When "Schedule Change / Delay" is selected, show: a reason dropdown (Weather, Track Maintenance, Timing Delay), a time input for expected resumption, and a "Cancel for the day" checkbox. When the checkbox is checked, swap the resumption time for a date picker for the continuation date. Auto-generate title and body from all selections.

6. **Weather Alert fields** — When "Weather Alert" is selected, show a short textarea for the organizer to describe the incoming conditions. Auto-generate the title ("⛈ Weather Advisory — [Event Name]") and body from the description.

7. **Message preview** — Below the type-specific fields, render a read-only card showing the generated title and body so organizers can review before hitting Send. Wire the existing `handleSend` to use the generated title/body instead of free-form state. Update the policy callout to describe the two supported types and the new window (24h before through 24h after).

## Relevant files
- `artifacts/race-platform/src/pages/organizer/Notifications.tsx`
- `artifacts/api-server/src/routes/notifications.ts`
- `artifacts/local-server/src/routes/index.ts`
