# Fix Rocky's Product Links

## What & Why
Rocky (the AI mechanic assistant in the Rider App) generates product links using a broken hash-fragment URL format that leads to "no results" pages. On top of that, when it does generate a link it sometimes includes variant-specific parameters (e.g. a specific oil weight) that open a dropdown pre-selected — which can still show nothing if the variant doesn't resolve. The instruction lives in a single line of the system prompt inside the mechanic-chat route.

## Done looks like
- When Rocky recommends a product (e.g. "Maxima oil"), the link opens the base product or category page — no variant pre-selected, no dropdown jumped to
- No "product not found" pages appear
- If Rocky recommends "Maxima 10W-40 oil", the link goes to the Maxima oil page (or the Rocky Mountain ATV/MC search results for "Maxima oil"), NOT a URL that pre-selects the 10W-40 weight in a dropdown
- The rule is: link to the broadest applicable page — the product's main page or a category search — never to a specific variant or dropdown selection

## Out of scope
- Changing which products Rocky recommends
- Any other changes to Rocky's behavior or personality

## Steps
1. **Determine the working search URL format** — The Rocky Mountain ATV/MC site's working search URL is `https://www.rockymountainatvmc.com/search?query=<term>` or similar (not the hash-fragment format). Confirm which format resolves to real results by inspecting what the site uses.

2. **Update the system prompt instruction on line 1359 of `artifacts/api-server/src/routes/rider-portal.ts`** — Replace the broken hash-fragment format with the verified working format. The instruction must tell Rocky to:
   - Use only the base search URL with a broad term (e.g. brand + product type, like "Maxima oil" — not "Maxima 10W-40 Motorcycle Oil 1 quart")
   - Never include variant parameters, dropdown anchors, or SKU-specific slugs in the URL — link to the broadest applicable page only
   - Example: for Maxima 10W-40, the link should be `https://www.rockymountainatvmc.com/search?query=Maxima+oil` not a URL with the weight pre-selected

## Relevant files
- `artifacts/api-server/src/routes/rider-portal.ts:1359`
