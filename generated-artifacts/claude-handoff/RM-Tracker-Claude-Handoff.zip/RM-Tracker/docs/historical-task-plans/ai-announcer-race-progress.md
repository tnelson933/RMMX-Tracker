# Announcer Race Progress Language

## What & Why
Make the shared AI race announcer use industry-standard timing language. Commentary should never mention a rider’s cumulative time on track; it should focus on individual lap times, time gaps to other riders, and the correct remaining-time or remaining-laps context for the race format.

## Done looks like
- The announcer never speaks a leader’s or winner’s total elapsed race time, including during lap updates and finish recaps
- Rider timing commentary uses individual lap times and same-lap time-behind gaps instead of cumulative time-on-track language
- During timed races, lap-progress calls periodically report the accurate pause-adjusted time remaining
- When a timed race expires, every viewer hears one shared call that time is up and states the configured number of extra laps remaining
- As the leader completes post-expiry laps, subsequent calls use the correct remaining extra-lap count without repeating or going negative
- During fixed-lap races, lap-progress calls periodically state how many laps remain, with correct singular/plural wording
- Repeated timing snapshots, API restarts, and viewer reconnects do not replay countdown, time-expired, or laps-remaining announcements
- Automated coverage verifies the language rules and both race formats

## Out of scope
- Removing total-time data from scoring, stored results, leaderboard displays, exports, or timing integrations
- Changing how organizers configure timed or fixed-lap races
- Reworking the existing race-completion and plus-laps scoring rules
- Changing the announcer voice, branding, or Watch Live mute controls

## Steps
1. **Use race-relevant commentary facts** — Refactor lap and finish script generation so cumulative race time is never spoken, while leader calls can use individual lap times and other same-lap riders continue to be described by their time-behind gaps.
2. **Add format-aware progress calls** — Supply the shared announcer with fixed-lap targets, pause-adjusted timed-race countdown state, and post-expiry leader progress so each lap update can choose the appropriate time-left or laps-left language.
3. **Announce the timed-race transition once** — Publish the existing time-expiration state into the shared announcer lifecycle and persist enough progress to prevent duplicate “time is up” or extra-lap calls across repeated snapshots, reconnects, and server restarts.
4. **Verify announcer language and sequencing** — Add focused script, lifecycle, route, and shared-broadcast tests for no total-time wording, individual lap and gap wording, fixed-lap remaining counts, timed countdowns, the one-time expiry call, post-expiry lap countdowns, and duplicate suppression.

## Relevant files
- `artifacts/api-server/src/routes/timing.ts:513-647`
- `artifacts/api-server/src/routes/timing.ts:1045-1080`
- `artifacts/api-server/src/routes/timing.ts:2056-2478`
- `artifacts/api-server/src/lib/announcerLifecycle.ts`
- `artifacts/api-server/src/lib/announcerLifecycle.test.ts`
- `artifacts/api-server/src/routes/motos.ts:321-397`
- `artifacts/race-platform/src/pages/organizer/Motos.tsx:689-733`
- `artifacts/race-platform/src/pages/organizer/Motos.tsx:3564-3585`
- `artifacts/race-platform/src/lib/sharedAnnouncer.ts`
- `artifacts/race-platform/src/lib/sharedAnnouncer.test.ts`
- `artifacts/race-platform/tests/browser/live-race-tabs.spec.ts:323-378`
- `lib/db/src/schema/motos.ts`
