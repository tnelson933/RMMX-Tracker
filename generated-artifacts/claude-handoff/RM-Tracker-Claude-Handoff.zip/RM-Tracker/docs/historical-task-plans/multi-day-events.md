# Multi-Day Event Support

## What & Why
Organizers can mark an event as spanning multiple days by selecting a date range (start + end date) in the event creation and edit forms. Riders viewing the event on the public site see the full date range so they know it's a two-day (or longer) event. Single-day events are unaffected.

## Done looks like
- Event creation dialog has a "Multi-day event" toggle. When turned on, a second end-date picker appears alongside the existing start-date picker.
- Saving a multi-day event stores the end date. Single-day events leave end date null.
- The organizer's event detail edit form also supports viewing and editing the end date.
- Public event listing cards and the event detail/registration page show the full range (e.g. "Jun 21 – Jun 22, 2026") for multi-day events and just the single date for single-day events.
- The local (desktop) server's event schema and handlers accept and return `endDate` so desktop-synced events display correctly too.

## Out of scope
- Per-day class or moto scheduling (just date range storage and display for now).
- Registration open/close windows tied to specific days.
- Rider app changes (public web covers the rider-facing surface).

## Steps
1. **DB migration** — Add a nullable `endDate` text column to the `eventsTable` in `lib/db/src/schema/events.ts`. Run `pnpm --filter @workspace/db run push` to apply. Confirm `endDate` is included in the Drizzle select/insert types.

2. **OpenAPI spec** — Add optional `endDate` (string, format date, nullable) to `EventInput`, `EventUpdate`, and the `Event` response schema in `lib/api-spec/openapi.yaml`. Run codegen (`pnpm --filter @workspace/api-spec run codegen`) to regenerate hooks and Zod schemas.

3. **API server routes** — In the create and update event handlers (`artifacts/api-server/src/routes/events.ts`), accept and persist `endDate`. Include it in all event SELECT queries so it is returned in responses.

4. **Event creation dialog (web)** — In `artifacts/race-platform/src/pages/organizer/EventsList.tsx`, add a "Multi-day event" checkbox/toggle to the create-event dialog. When checked, show a second date input for the end date. Wire both dates into the mutation payload.

5. **Event detail edit form (web)** — In `artifacts/race-platform/src/pages/organizer/EventDetail.tsx`, add the same multi-day toggle and end-date field to the event settings/edit section so organizers can update existing events.

6. **Public display (web)** — Update event listing cards and the public event detail/registration page to show a date range when `endDate` is present. Build a small shared date-range formatter (e.g. `formatEventDates(date, endDate)`) used in both places.

7. **Local server (desktop)** — In `artifacts/local-server`, update the local events schema/migration (SQLite) and route handlers to store and return `endDate`, mirroring the cloud API so synced events show the correct date range in the desktop app.

## Relevant files
- `lib/db/src/schema/events.ts`
- `lib/api-spec/openapi.yaml`
- `lib/api-client-react/src/generated/`
- `artifacts/api-server/src/routes/events.ts`
- `artifacts/race-platform/src/pages/organizer/EventsList.tsx`
- `artifacts/race-platform/src/pages/organizer/EventDetail.tsx`
- `artifacts/race-platform/src/pages/public/Home.tsx`
- `artifacts/race-platform/src/pages/public/Results.tsx`
- `artifacts/local-server`
