# Move Event Rules to Schedule Tab

## What & Why
The "Minimum Lap Time" and "Advance to Main" controls currently live on the Motos & Lineups tab. They are event-wide rules that belong on the Schedule tab, which is intended as the central place organizers configure how the event runs.

## Done looks like
- The **Minimum Lap Time** input card appears on the Schedule tab with the same debounce-save behavior it has today (auto-saves as the organizer types, shows saving/saved indicator).
- The **Advance to Main** card appears on the Schedule tab for Supercross-format events, below the Minimum Lap Time card.
- Neither card appears on the Motos & Lineups tab anymore.
- The Motos & Lineups tab still correctly flags short laps red (it continues reading `event.minLapMs` via `useGetEvent`, which it already fetches — only the editing UI moves).

## Out of scope
- Any changes to how the values are stored or the API.
- Moving any other controls between tabs.

## Steps
1. **Port helpers and state to EventSchedule** — Add `useGetEvent`, `useUpdateEvent`, `useAdvanceToMain`, and `useListPointsTables` imports to `EventSchedule.tsx`. Copy `parseMinLapTime` and `formatMinLapTime` helper functions into it. Port the full minLap state variables, refs, debounce effect, blur handler, unmount-flush effect, and `saveMinLapRef` from `Motos.tsx`.

2. **Derive `isSupercrossFormat` in EventSchedule** — Fetch `pointsTables` via `useListPointsTables` and compute `isSupercrossFormat` the same way Motos does (`eventScoringTable?.mainEventOnly === true`).

3. **Add the two cards to the Schedule UI** — Render the Minimum Lap Time card and the Advance to Main card (Supercross-only) in `EventSchedule.tsx`, placed below the auto-fill toolbar and above the moto list. Match the existing card styling exactly.

4. **Remove the cards and dead state from Motos** — Delete the "Settings row" JSX block (~lines 2379–2490) from `Motos.tsx`. Remove the minLap state variables, all associated refs, the debounce/save effects, and the blur handler. Keep `parseMinLapTime` and `formatMinLapTime` (still used for lap display). Keep `useAdvanceToMain` import only if used elsewhere in the file; otherwise remove it.

## Relevant files
- `artifacts/race-platform/src/pages/organizer/EventSchedule.tsx`
- `artifacts/race-platform/src/pages/organizer/Motos.tsx:1070-1250,2379-2500`
