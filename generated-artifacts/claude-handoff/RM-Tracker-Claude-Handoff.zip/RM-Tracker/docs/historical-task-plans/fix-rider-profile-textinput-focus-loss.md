# Fix profile edit inputs losing focus after one character

## What & Why
When editing a rider profile (bike info, name, etc.), typing one character causes the keyboard to dismiss and focus to leave the field, forcing the user to tap back in for every character. This makes the form essentially unusable.

The cause: `Field`, `TwoColFields`, and `SimpleField` are defined as React component functions *inside* the `RiderDetailScreen` function body. Every keystroke updates `form` state → re-renders the screen → React sees these as brand-new component types (new function references each render) → it unmounts and remounts the `TextInput` elements → focus is lost.

## Done looks like
- Typing in any profile edit field (first/last name, bike model, city, etc.) works continuously without the keyboard dismissing between characters
- All field types (single-line, two-column, multiline) behave correctly
- No visual or behavioral change to the form otherwise

## Out of scope
- Redesigning the profile edit form
- Any other screens or inputs

## Steps
1. **Move `Field`, `TwoColFields`, and `SimpleField` outside `RiderDetailScreen`** — lift these three component definitions to module scope (above `RiderDetailScreen`). They currently close over `s`, `colors`, `editing`, `form`, and `setField` from the parent scope; convert those to explicit props instead.
2. **Update call sites** — pass the required style/state props wherever `Field`, `TwoColFields`, and `SimpleField` are used inside the JSX. Ensure `setField` is passed as a stable callback (it already uses the functional `setForm` updater pattern, so no extra `useCallback` is needed as long as the reference passed down is stable — wrap with `useCallback` if needed to prevent unnecessary re-renders).
3. **Verify** — confirm the fix works for at minimum: First Name, Bike Model, City, and Sponsors (multiline). Ensure the brand picker grid and RFID inline edit are unaffected (they are not defined-inside-component components, so they should be fine already).

## Relevant files
- `artifacts/rider-app/app/rider/[id].tsx`
