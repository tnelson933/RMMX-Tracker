# Show Antenna Count on LLRP Adjustment Page

## What & Why
Organizers using the LLRP RF Configuration section of Reader Setup want to see how many antenna ports the reader is detecting tags on — useful for confirming cables are connected and the reader is seeing all expected antennas.

## Done looks like
- The LLRP RF Configuration card on Reader Setup shows "X antenna(s) active" (e.g. "2 antennas active") when RM Connect is connected and has seen reads
- The count updates in real-time as the connector status polls (same 10 s poll as today)
- If no tags have crossed yet (no reads in the session), the count shows "—" or is omitted rather than showing 0 incorrectly
- The count is only shown for LLRP-type readers (Impinj / Zebra / Generic), not MyLaps

## Out of scope
- Querying GET_READER_CAPABILITIES from the hardware at connect time
- Showing per-antenna signal strength or read counts
- Persisting antenna info to the database

## Steps
1. **Track unique antennas in LlrpClient** — In `llrp.ts`, maintain a `Set<number>` of antenna IDs seen during the current connection session. Populate it from `antennaId` on each tag read (skip `null` values). Expose as `antennaIds: number[]` in `getStatus()`. Reset the set on disconnect.

2. **Flow through connector status chain** — Add `antennaIds: number[]` to: `LlrpStatus` (llrp.ts), the `device` block of `getAggregateStatus()` in `main.ts`, `CloudStatusReport` in `cloud.ts`, and the `hardware` block of `ConnectorStatus` in `connectorRelay.ts`. In the relay's message handler, parse `antennaIds` from incoming status messages (validate as `number[]`, default to existing value if missing).

3. **Display on Reader Setup page** — In `ReaderSetup.tsx`, inside the LLRP RF Configuration section, add a small stat below (or beside) the existing status indicators: "Antennas detected: X" where X is `antennaIds.length`. Only show it when the connector is connected and `antennaIds` is non-empty. Match the existing muted-text style used for other status details on that card.

## Relevant files
- `artifacts/connector/src/llrp.ts`
- `artifacts/connector/src/main.ts`
- `artifacts/connector/src/cloud.ts`
- `artifacts/connector/src/ipc-types.ts`
- `artifacts/api-server/src/lib/connectorRelay.ts`
- `artifacts/race-platform/src/pages/organizer/ReaderSetup.tsx`
