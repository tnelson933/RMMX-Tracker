# Discount Codes Management Page

## What & Why
Add a dedicated **Discount Codes** section to the organizer portal left-nav where organizers can create and manage discount codes for their club — with support for one-time use, expiring, and unlimited codes. A companion **Discount Code Categories** panel on the same page lets organizers define named categories (e.g. "Entry Fees", "Pit Passes", "Transponder Rental") and restrict each code to only apply toward specific categories.

## Done looks like
- "Discount Codes" appears in the organizer sidebar between Payments and Reader Setup
- The page has two tabbed or stacked sections: **Discount Codes** and **Discount Code Categories**
- Organizer can create a discount code with:
  - A custom or auto-generated code string
  - Discount amount (dollar value)
  - Usage type: **One-time use** (max 1 use), **Limited uses** (custom count), or **Unlimited**
  - Expiration: **No expiration** or a specific expiry date/time
  - One or more categories the code is valid for (checked from the club's category list)
- Organizer can see all their club's codes in a table showing code, amount, uses remaining, expiry status, and applicable categories
- Organizer can deactivate (soft-delete) a code and delete a category
- Discount Code Categories section lets organizers add/rename/delete named categories for their club
- Existing comp-code validation at registration time is updated to check expiry date and enforce category restrictions if any are set
- DB schema migrated with new columns and tables; codegen re-run so typed hooks are available in the frontend

## Out of scope
- Per-event scoping of categories (categories are club-wide)
- Percentage-based discounts (dollar amounts only, matching existing system)
- Rider-facing UI to browse available categories
- Retroactively categorizing old comp codes

## Steps

1. **DB schema — extend comp_codes and add new tables**
   Add `expires_at` (nullable timestamp), `is_active` boolean (default true), and `category_ids` (integer array jsonb) columns to `comp_codes`. Create a new `discount_categories` table with `id`, `club_id`, `name`, `created_at`. Run `pnpm --filter @workspace/db run push` to apply.

2. **Update comp_codes to be club-scoped**
   The existing `comp_codes` table is event-scoped (`event_id`). Add a nullable `club_id` foreign key so club-level codes (created from the new page) are stored without an event_id. Event-level codes (legacy) remain unchanged. Update the existing validation route to handle both scopes.

3. **OpenAPI spec — discount categories endpoints**
   Add CRUD endpoints to `openapi.yaml` for discount categories: `GET /discount-categories`, `POST /discount-categories`, `DELETE /discount-categories/:id`. Add schemas for `DiscountCategory` and `DiscountCategoryList`.

4. **OpenAPI spec — discount codes endpoints**
   Add club-level discount code endpoints: `GET /discount-codes`, `POST /discount-codes`, `PATCH /discount-codes/:id` (deactivate), `DELETE /discount-codes/:id`. Add `DiscountCode` and `DiscountCodeList` schemas with all new fields (expiresAt, isActive, categoryIds, maxUses).

5. **Run codegen**
   Run `pnpm --filter @workspace/api-spec run codegen` to generate typed React Query hooks and Zod schemas for all new endpoints.

6. **API route — discount categories**
   Implement the discount categories Express route handlers. All routes are club-scoped to the logged-in organizer's club. Support list, create, and delete.

7. **API route — discount codes (club-level)**
   Implement club-level discount code route handlers: list all codes for the club, create a new code (with expiry, maxUses, categoryIds), deactivate a code, and delete a code. Generate code strings using the existing `generateCode()` helper or accept a custom code from the request body.

8. **Update comp-code validation logic**
   In the existing `validate-comp-code` and registration routes, add checks: (a) reject codes where `is_active = false`; (b) reject codes where `expires_at` is set and is in the past; (c) if the code has `category_ids`, accept an optional `categoryId` param on the validate request and reject if no match. Keep backward compatibility for codes without categories.

9. **Frontend — Discount Code Categories section**
   Build the `DiscountCodeCategories` sub-component: a list of the club's categories with Add and Delete controls. Uses the generated hooks from step 5.

10. **Frontend — Discount Codes table and create form**
    Build the `DiscountCodes` sub-component: a table listing all club codes (code string, amount, usage type badge, uses remaining, expiry, categories, active status) and a create drawer/dialog. The create form has fields for code (auto-generate or custom), amount, usage type (one-time / limited / unlimited), expiry toggle + date picker, and a checkbox list of categories from the club's category list.

11. **Frontend — Discount Codes page and nav wiring**
    Create the `DiscountCodesPage` route component that composes the two sections. Add the route `/discount-codes` to `App.tsx` wrapped in `ProtectedRoute`. Add a "Discount Codes" nav item (Tag icon) to the sidebar in `OrganizerLayout.tsx`.

## Relevant files
- `lib/db/src/schema/comp-codes.ts`
- `lib/db/src/schema/index.ts`
- `lib/api-spec/openapi.yaml`
- `artifacts/api-server/src/routes/comp-codes.ts`
- `artifacts/api-server/src/routes/registrations.ts`
- `artifacts/api-server/src/app.ts`
- `artifacts/race-platform/src/App.tsx`
- `artifacts/race-platform/src/components/layout/OrganizerLayout.tsx`
- `lib/api-client-react/src/generated/`
