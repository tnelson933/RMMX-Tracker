# Fix: Voiding one registration removes all for that rider

## What & Why
Clicking the X (void) button on one registration for a rider removes all of that rider's registrations instead of just the one clicked. The root cause is a duplicate-row bug in the registrations list query: the `GET /events/:eventId/registrations` endpoint does a `LEFT JOIN` on `rfid_assignments` matching by `riderId + eventId`. If a rider has more than one RFID assignment record for the same event, the JOIN multiplies each registration row — so a rider with 3 registrations and 2 RFID records appears as 6 rows, all sharing the same `reg.id`. When one is voided and the list refreshes, those duplicates collapse into one voided row, making it appear as if all were removed.

## Done looks like
- Clicking X on one registration row voids only that registration; the other registrations for the same rider remain unaffected and still show in the list.
- The registrations list never shows duplicate rows for a rider who has multiple RFID assignments.
- Each registration row shows the correct RFID number (or none if unassigned).

## Out of scope
- Any changes to how RFID assignments are created or managed.
- Changes to the void/confirm logic itself.

## Steps
1. **Fix the duplicate-row JOIN** — In `GET /events/:eventId/registrations`, replace the simple `LEFT JOIN rfid_assignments` (which fans out on multiple RFID records per rider per event) with a subquery or `DISTINCT ON` so each registration appears exactly once. The safest approach: use a lateral/subquery to fetch only the first (or most recent) RFID assignment per `riderId + eventId`, then join that.

2. **Verify no other list endpoints have the same fan-out** — Check `GET /events/:eventId/checkins` and any other joined queries that join `rfid_assignments` the same way; apply the same fix if found.

3. **Smoke test the fix manually** — Log in as Jake, navigate to an event with multiple registrations for the same rider, void one registration, confirm only that registration shows as voided and the others remain.

## Relevant files
- `artifacts/api-server/src/routes/registrations.ts:59-118`
- `artifacts/api-server/src/routes/checkins.ts`
