# Multi-Bike Garage Support

## What & Why
Riders often own 2–3 bikes. Right now the system stores a single bike (manufacturer/model/year) directly on the rider profile row. This task lifts bike info into its own table, allows multiple bikes per rider, and adds a "default" flag so one bike is pre-selected. The change surfaces in both the Expo rider app and the web rider portal.

## Done looks like
- A rider can add, edit, and delete any number of bikes on their profile (no hard cap, but UI is designed for 2–3)
- A checkmark / toggle marks one bike as the default; tapping a different bike's checkmark moves the default to that one
- Garage sections in the rider app (profile tab) and the web rider portal both show the full list and the default indicator
- Existing bike data (currently one per rider row) is automatically migrated into the new table as the first/default bike; no rider loses their existing bike info
- Maintenance schedules remain linked to the rider (not to a specific bike row) so nothing breaks there
- The Rocky AI context (bikeInfoMap) uses the default bike for personalization

## Out of scope
- Linking maintenance items to a specific bike (future work)
- Bike photo uploads
- Class/displacement auto-suggest based on bike model

## Steps

1. **DB schema — new `rider_bikes` table** — Add a `rider_bikes` table with columns: `id` (serial PK), `rider_id` (FK → riders.id, cascade delete), `bike_manufacturer` (text), `bike_model` (text), `bike_year` (text), `is_default` (boolean, not null, default false), `created_at` (timestamp). Write a data migration that copies existing `bike_manufacturer`, `bike_model`, `bike_year` from each `riders` row into a new `rider_bikes` row marked `is_default = true` (skip riders where all three fields are null). Run `pnpm --filter @workspace/db run push` after.

2. **API endpoints — bike CRUD** — Add five rider-portal routes (all scoped to the authenticated rider's own profiles):
   - `GET /rider/profiles/:riderId/bikes` — list all bikes for a rider profile
   - `POST /rider/profiles/:riderId/bikes` — add a new bike; if it's the first bike, auto-set `is_default = true`
   - `PATCH /rider/profiles/:riderId/bikes/:bikeId` — update manufacturer/model/year fields
   - `DELETE /rider/profiles/:riderId/bikes/:bikeId` — delete; if it was default, promote the most-recently-added remaining bike to default
   - `POST /rider/profiles/:riderId/bikes/:bikeId/set-default` — atomically clears `is_default` on all other bikes for this rider then sets it on the target

3. **OpenAPI spec + profile response** — Add the five new routes and a `RiderBike` schema to `openapi.yaml`. Update the `RiderProfile` response schema to include a `bikes: RiderBike[]` field alongside the (now-legacy) top-level `bikeManufacturer/Model/Year` fields so nothing breaks before the frontend is updated. Run `pnpm --filter @workspace/api-spec run codegen` to regenerate hooks and Zod schemas.

4. **Rider app — multi-bike garage UI** — In `artifacts/rider-app/app/(tabs)/profile.tsx`, replace the single-bike display in the My Garage section with a scrollable list of bike cards. Each card shows Year / Make / Model, a checkmark button (filled if `is_default`), an edit pencil, and a delete trash icon (with a confirmation prompt). An "Add bike +" button at the bottom of the list opens a bottom sheet (matching the existing edit-sheet pattern) with Year/Make/Model inputs. In `artifacts/rider-app/app/rider/[id].tsx` remove or redirect the old single-bike edit flow. Update `RockyChatContext.tsx` to pick the `is_default` bike from the profiles bikes array instead of the old `bikeInfoMap` fallback.

5. **Rider portal (web) — multi-bike garage UI** — In `artifacts/race-platform/src/pages/rider/RiderPortal.tsx` (and any linked detail page), replace the single-bike display with a bike list that shows all bikes and marks the default with a checkmark icon. Add an "Add bike" button and inline edit/delete controls. Wire everything to the new generated hooks from step 3. Keep the layout consistent with the existing card/panel design on that page.

## Relevant files
- `lib/db/src/schema/riders.ts`
- `lib/db/src/schema/maintenance.ts`
- `lib/api-spec/openapi.yaml`
- `artifacts/api-server/src/routes/rider-portal.ts`
- `artifacts/rider-app/app/(tabs)/profile.tsx`
- `artifacts/rider-app/app/rider/[id].tsx`
- `artifacts/rider-app/context/RockyChatContext.tsx`
- `artifacts/race-platform/src/pages/rider/RiderPortal.tsx`
- `artifacts/race-platform/src/lib/rider-api.ts`
