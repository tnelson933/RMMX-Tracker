# Fix Run Order Accuracy vs Grid View

## What & Why
The Run Order view and Grid View show motos in different sequences, making Run Order feel inaccurate. There are two compounding bugs:

**Bug 1 — Grid View uses a status-first sort:**
Grid View sorts motos by status (in_progress → scheduled → completed) and then by motoNumber within each group. Run Order sorts only by motoNumber (true chronological order). Once any moto starts or finishes, the two views show completely different orderings — the same set of motos appears in a totally different sequence in each view.

**Bug 2 — Drag-drop computes positions against motoNumber order, not visual order:**
`handleMotoDrop` builds `allMotos` sorted by motoNumber to compute insert positions. But the user drags based on what they see in Grid View, which is status-sorted. So a drag that looks like "move moto A before moto B" in Grid View may produce a completely different global position in `handleMotoDrop` — silently corrupting the motoNumber sequence stored in the DB, which then shows up as a wrong order in Run Order.

## Done looks like
- Grid View and Run Order always show motos in the same sequence (motoNumber order).
- Dragging a moto in Grid View produces the correct result: the moved moto lands exactly where the user dropped it, and Run Order reflects the new order immediately.
- In-progress and completed motos remain visually distinguished (colored badges, opacity) but are no longer floated to different positions.
- The drag-drop handler uses the `/motos/reorder` bulk endpoint for a single atomic update instead of parallel individual PATCHes, eliminating any race-condition risk when multiple motoNumbers change at once.

## Out of scope
- Changing how completed/in_progress motos are visually styled (badges, colors, opacity stay as-is).
- Any changes to the Run Order view itself — it is already correct.
- The public heat sheet / print view.

## Steps
1. **Remove status-based sort from Grid View** — Change the Grid View sort to use motoNumber only (same as Run Order). The existing visual indicators (colored number block, pulsing dot, opacity, status badge) already make status clear without reordering cards.

2. **Fix drag-drop position computation** — In `handleMotoDrop`, build `allMotos` from the current `localOrderIds` order when it's set, or from motoNumber order when it's not — matching exactly what the user sees. This ensures a drag from visual position X to visual position Y always means the same thing in both views.

3. **Switch to the bulk reorder endpoint** — Replace the parallel individual `updateMutation` PATCH calls in `handleMotoDrop` with a single call to `POST /events/:eventId/motos/reorder` (passing the full ordered `motoIds` array). This is atomic, consistent, and avoids the edge case where parallel patches leave motoNumbers in a partial state. Keep the name auto-rename logic as a follow-up PATCH batch (or fold it into the reorder endpoint response if it already returns updated motos).

## Relevant files
- `artifacts/race-platform/src/pages/organizer/Motos.tsx:2982-2990`
- `artifacts/race-platform/src/pages/organizer/Motos.tsx:1271-1330`
- `artifacts/race-platform/src/pages/organizer/Motos.tsx:2784-2789`
- `artifacts/api-server/src/routes/motos.ts:1120-1167`
