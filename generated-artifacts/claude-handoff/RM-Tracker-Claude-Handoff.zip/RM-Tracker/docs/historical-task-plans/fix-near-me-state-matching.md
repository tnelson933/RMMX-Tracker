# Fix Near Me event matching (state normalization)

## What & Why
The Salem Showdown event (production event #43, Utah) doesn't appear in the "Near Me" tab on the rider app or in the Near Me view on the public home page. Root cause: the event's `state` is stored as the free-form text "Utah" while every other Utah event is stored as "UT". Both Near Me filters do exact string matching:
- Rider app filters events by `e.state === nearMeState`, where `nearMeState` comes from a reverse geocode (`geo.region`, which is the full name "Utah" on iOS/Android — meaning today only the one misentered "Utah" event would match, and all 21 "UT"/"ut" events are hidden).
- Web home page computes distance from `STATE_CENTROIDS[e.state]`, keyed by 2-letter codes, so "Utah", "ut", and "nv" events get no distance and are filtered out of Near Me.

Production data currently has 7 distinct state spellings: UT (17), ut (4), AZ (2), Utah (1), nv (1), NV (1), CO (1). Nothing normalizes state on event create/update, so this will keep recurring.

## Done looks like
- Salem Showdown appears under Near Me in the rider app (for a rider in Utah) and in the Near Me view on the public home/rider login page.
- All existing lowercase/full-name state values in dev and production are normalized to 2-letter uppercase codes.
- Creating or editing an event with any reasonable state input ("Utah", "ut", "UT") stores the canonical 2-letter code, so this can't recur.
- The rider app's GPS state detection ("Utah" from reverse geocode) correctly matches events stored as "UT".

## Out of scope
- Distance-based (lat/lng per track) Near Me ranking — keep the existing state-based approach.
- Non-US regions.

## Steps
1. **Shared state normalizer** — Add a shared US-state normalization helper (full name / any casing → 2-letter uppercase code, pass through unknown values like "TBD") in a shared lib so server and both frontends can use one source of truth.
2. **Server-side normalization** — Normalize `state` in the event create and update routes before persisting, so all new/edited events store canonical 2-letter codes.
3. **Data backfill** — Write a one-off script to normalize existing `events.state` values; run it against dev, and coordinate running it against production (production DB writes require the deployment/database flow, not dev tooling).
4. **Rider app Near Me matching** — Convert the reverse-geocoded region name to the 2-letter code before comparing, and make the comparison case-insensitive as a safety net. Update the "Open in {state}" label to show a friendly name.
5. **Web home page Near Me matching** — Normalize the event state before the centroid lookup so legacy or unexpected values still resolve, and verify Near Me sorting shows the Utah events.
6. **Verify** — Confirm with dev seed data plus a simulated Utah location that Near Me shows correctly-stored and previously-misstored events in both apps.

## Relevant files
- `artifacts/rider-app/app/(tabs)/my-races.tsx:706-826`
- `artifacts/race-platform/src/pages/public/Home.tsx:312-381`
- `artifacts/race-platform/src/lib/stateCentroids.ts`
- `artifacts/api-server/src/routes/events.ts:146-180,304-340`
- `artifacts/api-server/src/routes/dashboard.ts:280-320`
