# My Race Organizations — Profile & Notification Prefs

## What & Why
Riders want to see every club they've ever raced with in one place, and control which of those clubs can send them push notifications. This adds a "My Race Organizations" entry point to the profile screen, a dedicated organizations list page, and per-club notification opt-out toggles backed by a new API and DB table.

## Done looks like
- Profile page has a tappable "My Race Organizations" row (similar to other sections) that navigates to the organizations screen.
- The organizations screen lists every club the rider has ever registered with, showing the club name and state.
- Each club row has a toggle (checked by default) labeled "Notifications". Unchecking it opts the rider out of push notifications from that club.
- Preferences persist — toggling survives app restarts and is stored server-side.
- When an organizer broadcasts a push notification, riders who have opted out of that club no longer receive it.
- Empty state shown when the rider has no race history yet.

## Out of scope
- Fine-grained notification types per club (e.g. event reminders vs. general announcements) — just one on/off per club.
- Organizer-side visibility into who has opted out.
- Notification preferences for riders who have never logged into the app.

## Steps

1. **DB schema** — Add a new `rider_notification_prefs` table with columns `id`, `riderAccountId` (FK → rider_accounts), `clubId` (FK → clubs), `enabled` (boolean, default true), `updatedAt`. Add a unique constraint on `(riderAccountId, clubId)`. Export from the schema index and run a migration.

2. **API endpoint — list organizations** — Add `GET /rider/my-organizations` (mobile Bearer auth). Query the `registrations` table joined to `events` and `clubs` to find the distinct set of clubs any rider profile under this account has ever registered with. Also join `rider_notification_prefs` to include the current `enabled` flag for each club (default true if no row exists). Return `[{ clubId, clubName, state, logoUrl, notificationsEnabled }]`.

3. **API endpoint — update notification pref** — Add `PATCH /rider/my-organizations/:clubId/notifications` (mobile Bearer auth). Accept `{ enabled: boolean }` in the body. Upsert a row in `rider_notification_prefs` for `(riderAccountId, clubId)`. Return the updated preference.

4. **OpenAPI spec + codegen** — Add both endpoints to `lib/api-spec/openapi.yaml` under the `rider` tag. Run codegen to generate the React Query hooks.

5. **Notification sender — respect opt-outs** — In `artifacts/api-server/src/routes/notifications.ts`, after collecting the list of push tokens to send to, filter out any token whose `riderAccountId` has `enabled = false` in `rider_notification_prefs` for the broadcasting club.

6. **Rider app — Organizations screen** — Create `artifacts/rider-app/app/organizations.tsx`. Use the generated hook to fetch and display the club list. Each row shows club name and state. A toggle switch on each row calls the update pref hook on change. Include a pull-to-refresh and a friendly empty state.

7. **Rider app — Profile entry point** — In `artifacts/rider-app/app/(tabs)/profile.tsx`, add a "My Race Organizations" tappable row inside the logged-in `ProfileList` component (place it after the Rider Profiles section, before My Garage). Tapping navigates to `/organizations`. Style it consistently with the existing section cards.

## Relevant files
- `artifacts/rider-app/app/(tabs)/profile.tsx`
- `artifacts/rider-app/app/rider/[id].tsx`
- `artifacts/api-server/src/routes/notifications.ts`
- `artifacts/api-server/src/routes/riders.ts`
- `lib/db/src/schema/index.ts`
- `lib/db/src/schema/rider_accounts.ts`
- `lib/db/src/schema/rider_push_tokens.ts`
- `lib/db/src/schema/registrations.ts`
- `lib/api-spec/openapi.yaml`
- `lib/api-client-react/src/generated/`
