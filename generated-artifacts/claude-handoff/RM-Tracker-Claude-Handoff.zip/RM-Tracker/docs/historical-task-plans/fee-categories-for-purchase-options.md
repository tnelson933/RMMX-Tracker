# Categorize Additional Charges Using Discount Categories

## What & Why
When organizers create or edit an event, each additional charge (purchase option) they define should be assignable to a fee category via a dropdown. Categories come from the same `discount_categories` table already used on the Discount Codes screen — so the two features stay in sync. A built-in **"Entry Fees"** category is automatically created for every club at account creation time and the base entry fee on every event is pre-assigned to it, so discount codes restricted to "Entry Fees" will correctly apply to registration entry fees.

## Done looks like
- Every club always has an "Entry Fees" category (created automatically when the club account is first created, and backfilled for existing clubs via a migration).
- In the Create Event and Edit Event forms, each purchase option row has a **Category** dropdown that lists the club's discount categories; organizers can pick one (or leave it uncategorized).
- The base **Entry Fee** field is always implicitly tagged "Entry Fees" — no dropdown needed on that field, but the category ID is stored so discount code filtering can reference it.
- The `purchaseOptions` JSONB items gain a `categoryId` field (nullable integer); the existing discount code application logic respects this field when filtering by category.
- The Discount Codes screen is unaffected — categories are managed there exactly as today.
- Seed data backfills "Entry Fees" for all 3 existing dev clubs.

## Out of scope
- Changing how categories are created or managed (that stays on the Discount Codes screen).
- Changing the discount code application logic beyond ensuring `categoryId` on purchase options is read (it already checks category IDs; this task makes the data consistent).
- Adding a category to transponder rental fee.
- Any public-facing UI changes.

## Steps
1. **Ensure "Entry Fees" default category exists for every club** — Add a DB migration that inserts a `discount_categories` row named "Entry Fees" for any club that doesn't already have one. Also update the club-creation API route to seed "Entry Fees" automatically whenever a new club account is created. Update seed data to include the "Entry Fees" category for all 3 dev clubs.

2. **Extend `purchaseOptions` schema with `categoryId`** — The `purchaseOptions` column is JSONB so no DB migration is needed for the column itself; update the TypeScript type/Zod schema for the purchase option item shape to include an optional `categoryId: number | null`. Update the OpenAPI spec to reflect the new field in the event request/response bodies.

3. **Store the Entry Fee's category implicitly** — Add an `entry_fee_category_id` integer column (nullable, FK to `discount_categories`) to the `events` table. Populate it automatically to the club's "Entry Fees" category ID when an event is created, via the create-event API route. This lets discount code filtering treat the entry fee as a categorized line item.

4. **Wire category dropdown in the event form UI** — In `EventDetail.tsx` and the Create Event dialog in `EventsList.tsx`, fetch the club's discount categories (reuse the existing `useGetDiscountCategories` hook or equivalent). For each purchase option row in the field array, add a **Category** select/combobox populated with the club's categories plus an "— None —" option. Bind it to the `categoryId` field of that purchase option.

5. **Run codegen and fix any type errors** — Run `pnpm --filter @workspace/api-spec run codegen` after OpenAPI changes, then resolve any TypeScript errors surfaced in the event form, API routes, and registration checkout logic.

## Relevant files
- `lib/db/src/schema/comp-codes.ts`
- `lib/db/src/schema/events.ts`
- `lib/api-spec/openapi.yaml`
- `artifacts/api-server/src/routes/events.ts`
- `artifacts/api-server/src/routes/discount-codes.ts`
- `artifacts/api-server/src/routes/registrations.ts`
- `artifacts/race-platform/src/pages/organizer/EventDetail.tsx`
- `artifacts/race-platform/src/pages/organizer/EventsList.tsx`
- `artifacts/race-platform/src/pages/organizer/DiscountCodes.tsx`
