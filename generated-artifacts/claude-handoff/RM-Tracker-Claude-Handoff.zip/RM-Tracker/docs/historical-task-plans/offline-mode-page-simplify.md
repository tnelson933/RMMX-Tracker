# Simplify the Offline Mode Page

## What & Why
The current Offline Mode page is written for developers — it has six nested phases, multiple terminal code blocks, OS-specific command variants, environment variable syntax, and dense technical prose. Most club organizers running offline events are non-technical and older; the current page risks overwhelming them before they even start.

The goal is to rewrite the page so it reads like a plain-English checklist: short sentences, no jargon, minimal visible commands, and a clear sense of "what do I do next."

## Done looks like
- The page has 3–4 clearly numbered steps ("Before race day", "On race day", "After the race") — not 6 phases
- There are no raw terminal code blocks visible in the default view; any command that must be shown is labeled clearly as "Type this into your terminal" and is in a copy-able box
- OS-specific variants (macOS/Linux vs Windows) are hidden behind a small toggle or removed entirely from the main flow
- The Works Offline / Not Available Offline grid is kept but simplified to plain language (no technical terms like "RFID tag assignment")
- There is no environment variable syntax visible on the main page (`SQLITE_FILE=`, `CLOUD_URL=`, `export`, `set`) — these are either hidden in an expandable "Advanced" section or removed if the UI sync tool covers the use case
- All callouts (Warning/Tip/Note) are reduced to at most one per section and written in plain language ("Do this before you leave home", "Keep this window open all day")
- Page intro is 1–2 sentences max, with no technical explanation of what a local server is
- The page still preserves all the information task #60 added (dynamic club ID, dynamic cloud domain, working sync link) — it just presents it more simply
- A non-technical person can read the page top to bottom and know exactly what to do without Googling any terms

## Out of scope
- Changing how the backend works or what the offline package contains
- Building a GUI installer or wrapper around the terminal commands (future work)
- Any changes to the API or sync functionality

## Steps
1. **Restructure into 3 steps** — Replace the 6-phase layout with three top-level sections: "Before Race Day (one-time setup)", "On Race Day", and "After the Race". Each section gets a large, friendly heading and a short plain-English intro sentence.

2. **Rewrite all prose in plain language** — Remove or replace every technical term in the body text. "Local server" → "the software on your laptop". "SQLite database" → "your race data file". "HTTP POST endpoint" → "where your timing reader sends data". Write at a 6th-grade reading level throughout.

3. **Collapse terminal commands** — Any terminal command that is required (npm install, npm start, sync command) should be shown in a clearly labeled copy box ("Open the Terminal app and type:") but collapsed by default behind a "Show me how" expand button. The default view shows only what the user needs to do, not how to type it.

4. **Remove OS variants from the main flow** — Keep only the macOS/Linux version visible by default. Add a small "I'm on Windows" toggle that swaps the command text inline. Do not show both versions stacked on top of each other.

5. **Simplify the hardware configuration section** — Replace the IP address lookup commands and code blocks with a short paragraph and a single copy-able endpoint string (populated dynamically from the session). Link to the Reader Setup page for details. Remove the raw `ipconfig` / `ipconfig getifaddr` blocks from the main view entirely.

6. **Trim and rewrite callouts** — Keep at most one callout per section. Rewrite each to a single direct sentence ("Test this at home before your first event" instead of the current multi-sentence Warning block).

7. **Simplify the Works Offline list** — Rewrite each list item in plain language a rider or club volunteer would recognize. Remove items that are too technical for users to act on (e.g., "RFID tag assignment" → "Transponder / bib setup").

## Relevant files
- `artifacts/race-platform/src/pages/organizer/OfflineMode.tsx`
