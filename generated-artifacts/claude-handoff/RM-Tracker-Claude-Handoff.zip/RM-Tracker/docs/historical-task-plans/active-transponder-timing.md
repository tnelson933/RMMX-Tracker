# Active Transponder Timing

## What & Why
Replace the unsupported MyLaps/AMBrc integration with the F2000 active transponder system and rename the organizer-facing timing option to **Active Transponder Timing**. The connector should communicate directly with the F2000 over its documented TCP socket protocol, receive PowerTag crossings with reader timestamps, and feed them into the existing race timing pipeline without changing RFID/LLRP support.

## Done looks like
- Organizers see “Active Transponder Timing” everywhere instead of MyLaps, including event setup, reader setup, status screens, desktop/connector controls, help text, and AI guidance
- RM Connect can connect to the plugged-in F2000 over its socket interface, show clear connection/heartbeat status, and reconnect automatically after interruptions
- The connector starts/stops the reader correctly, parses F2000 crossing messages, preserves millisecond timestamps, and forwards each PowerTag as an active-transponder crossing through the existing timing pipeline
- Reader setup supports the F2000’s address and port (default port 3333), provides a connection test/live crossing feed, and reports actionable setup errors
- Existing events and rider/registration transponder numbers continue to work after the rename; historical timing data is not lost
- MyLaps AMBrc clients, MyLaps-specific controls, setup instructions, branding, and runtime paths are removed
- RFID/LLRP timing continues to work unchanged
- Protocol parsing, reconnect behavior, duplicate reads, and active-transponder ingest have automated coverage
- The live plugged-in F2000 is smoke-tested end to end: connect, heartbeat, reader start, tag crossing, cloud ingest, and visible crossing in the race-day interface

## Out of scope
- Adding LLRP firmware to the F2000
- Supporting MyLaps hardware as a fallback after this replacement
- Changing the physical antenna/loop installation or F2000 firmware
- Destructively renaming legacy database columns in a way that risks historical rider or registration data; compatibility storage may remain internal and invisible while public terminology becomes generic

## Steps
1. **Introduce the F2000 adapter** — Build a TCP client for the device socket protocol with framing, heartbeat handling, reader control, PowerTag crossing parsing, millisecond timestamps, reconnect/backoff, and duplicate protection.
2. **Connect it to RM Connect** — Replace the MyLaps adapter and IPC/runtime paths with generic active-transponder hardware selection, connection status, forwarding, and safe startup/shutdown behavior while preserving RFID/LLRP.
3. **Generalize the timing contract** — Update API and connector payloads to use generic active-transponder terminology, while accepting legacy stored values and field names where required so existing events and transponder assignments continue working.
4. **Replace setup and branding** — Remove MyLaps branding, AMBrc configuration, guides, and status copy from the organizer web app, desktop app, generated API clients, docs, and AI guidance; label the technology “Active Transponder Timing.”
5. **Add F2000 setup tools** — Provide host/port configuration (3333 default), a connection test, heartbeat/reader state visibility, and live crossing confirmation with useful errors for network, protocol, and reader-state failures.
6. **Verify compatibility and safety** — Add focused protocol and ingest tests, confirm RFID/LLRP regression coverage, and validate that existing MyLaps-valued events are transparently treated as active-transponder events after upgrade.
7. **Test the real hardware** — Discover or enter the F2000’s LAN address, connect to the plugged-in unit, start reading, pass a PowerTag over the loop, and verify the crossing reaches the event interface with the correct tag and timestamp.

**Critical constraint:** Reader protocol messages use the documented semicolon-terminated socket format and the F2000/A400 command set from Device Socket Protocol V3.2. Preserve historical data through compatibility reads/migration; remove MyLaps from the product and runtime without blindly dropping persisted fields first.

## Relevant files
- `artifacts/connector/src/main.ts`
- `artifacts/connector/src/mylaps.ts`
- `artifacts/connector/src/cloud.ts`
- `artifacts/connector/src/ipc-types.ts`
- `artifacts/desktop/src/main.ts`
- `artifacts/desktop/src/mylaps.ts`
- `artifacts/desktop/src/ipc-types.ts`
- `artifacts/race-platform/src/pages/organizer/ReaderSetup.tsx`
- `artifacts/api-server/src/routes/readers.ts`
- `artifacts/api-server/src/lib/connectorRelay.ts`
- `lib/db/src/schema/events.ts`
- `lib/db/src/schema/readers.ts`
- `lib/db/src/schema/riders.ts`
- `lib/db/src/schema/registrations.ts`
- F2000 Device Socket Protocol V3.2 reference
- `replit.md`
