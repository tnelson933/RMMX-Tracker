# Fix "Round" → "Moto" Labels on Schedule Page

## What & Why
On the Schedule page's Generate Lineups dialog and the round filter pills, the UI says "Round 1", "Round 2", etc. The correct term for this platform is "Moto 1", "Moto 2", etc. This is a label-only fix — no logic changes.

## Done looks like
- The filter pills above the moto list read "Moto 1", "Moto 2", … (not "Round 1", "Round 2")
- The checkboxes inside the Generate Lineups dialog read "Moto 1", "Moto 2", … (not "Round 1", "Round 2")
- The session count summary text (e.g. "Round 2 (3 sessions)") also reads "Moto 2 (3 sessions)"

## Out of scope
- Any backend or data model changes
- Renaming internal variable names (roundFilter, maxRounds, etc.) — only visible UI strings change

## Steps
1. **Replace display strings in EventSchedule.tsx** — change every rendered `Round {n}` / `Round {r}` / `Round ${roundFilter}` string to `Moto {n}` / `Moto {r}` / `Moto ${roundFilter}`. There are three occurrences: the filter pill label (line ~2054), the session count summary (line ~1950), and the generate dialog checkbox label (line ~2676).

## Relevant files
- `artifacts/race-platform/src/pages/organizer/EventSchedule.tsx:1950,2044-2056,2636-2680`
