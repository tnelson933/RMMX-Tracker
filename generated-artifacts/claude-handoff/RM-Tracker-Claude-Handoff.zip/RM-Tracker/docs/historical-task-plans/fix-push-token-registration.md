# Fix Push Token Registration in Rider App

## What & Why
Two bugs prevent push notifications from working in TestFlight (and production):
1. `getExpoPushTokenAsync()` is called without a `projectId`, which causes a silent error in Expo SDK 49+ — the token never reaches the server, so the organizer audience count stays at 0.
2. The permission request only fires at login but gives no feedback when iOS silently skips the prompt (e.g. previously denied). Riders have no way to know notifications are off or how to fix it.

## Done looks like
- After logging in on a real device, the rider's push token is successfully saved to the server and the organizer notification audience count reflects them.
- If notification permissions are not granted at login time, the app shows an alert explaining that notifications are off with a button that deep-links directly to the iOS/Android Settings page for the app.
- If permissions are already granted, no prompt appears — login behaves exactly as before.

## Out of scope
- Changing the notification types or content.
- Retroactively notifying riders who already have denied permissions (they must manually enable in Settings first).

## Steps

1. **Locate or confirm the EAS project ID** — Run `eas project:info` in `artifacts/rider-app` to get the project UUID. Add it to `app.json` under `expo.extra.eas.projectId`. If no EAS project exists yet, run `eas init` to create one.

2. **Fix `getExpoPushTokenAsync` call** — In `artifacts/rider-app/context/AuthContext.tsx`, update `tryRegisterPushToken` to pass `{ projectId }` sourced from `Constants.expoConfig?.extra?.eas?.projectId`. If the projectId is missing at runtime, log a warning and bail early rather than letting the error swallow silently.

3. **Surface a "go to Settings" alert when permission is denied** — After calling `requestPermissionsAsync()`, if `finalStatus` is not `"granted"`, show an `Alert` with a message like "Enable notifications to receive race-day updates" and an "Open Settings" button that calls `Linking.openSettings()`. Show the alert on every login so it's impossible to miss, but only when permission is not granted. Import `Alert` and `Linking` from `react-native`.

## Relevant files
- `artifacts/rider-app/context/AuthContext.tsx:76-103`
- `artifacts/rider-app/app.json`
