# Fix Profile Tab Crash on iOS 26+

## What & Why
`ProfileList` in `profile.tsx` calls `useBottomTabBarHeight()` from `@react-navigation/bottom-tabs`. On iOS 26+, the tab layout switches to `NativeTabs` (from `expo-router/unstable-native-tabs`), which is a native iOS component and does not provide the React Navigation `BottomTabBarHeightContext` that hook reads from. The result is a hard crash on load for any user on iOS 26+.

`tabBarHeight` is only used in one place: `paddingBottom: tabBarHeight + 16` in the `ProfileList` stylesheet. The safe area insets bottom (already available in the component via `useSafeAreaInsets()`) is the correct fallback — on iOS 26+ with NativeTabs, the native tab bar manages its own spacing and the home indicator inset is the relevant padding value.

## Done looks like
- The Profile tab loads without error on both iOS 26+ (NativeTabs) and older iOS / Android (ClassicTabLayout).
- Bottom padding of the profile scroll view still clears the tab bar on both paths.

## Out of scope
- Changes to any other tab screen.
- Redesigning how the tab layout works.

## Steps
1. **Replace `useBottomTabBarHeight` with a safe fallback** — In `ProfileList`, remove the `useBottomTabBarHeight()` call and instead derive the bottom padding from `useSafeAreaInsets().bottom` (already in scope) plus a standard tab bar height constant (e.g. 49) when inside the classic tab layout, or just `insets.bottom` when using NativeTabs. The simplest correct approach is to read `BottomTabBarHeightContext` via `useContext` with a `?? 0` fallback, then add `insets.bottom` to cover the NativeTabs case. Alternatively, use the `useContext(BottomTabBarHeightContext)` pattern with a safe default.

## Relevant files
- `artifacts/rider-app/app/(tabs)/profile.tsx:133-210`
- `artifacts/rider-app/app/(tabs)/_layout.tsx`
