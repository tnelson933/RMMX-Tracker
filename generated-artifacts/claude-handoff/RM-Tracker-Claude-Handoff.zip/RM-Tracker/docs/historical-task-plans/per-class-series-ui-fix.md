# Per-Class Series Multi-Select in Event Form

## What & Why
Task #299 added `raceClassSeriesMap` to the DB and API but the UI was never wired. Organizers cannot assign series to individual classes because the multi-select control is missing from each class row in the event creation and edit form.

## Done looks like
- Each class row in the event creation form has a series multi-select between the class name field and the max riders field
- Organizers can select zero, one, or multiple series per class (e.g. a 150cc class can count toward both a points series and a championship series simultaneously)
- Only series belonging to the organizer's club are shown in the dropdown
- The selected series are included in the `raceClassSeriesMap` payload on create and on edit/save
- When editing an existing event, the class rows pre-populate with the previously saved series assignments
- The club-default class chip selector (the quick-add buttons) preserves this behavior — clicking a chip adds the class with empty series; organizer then picks series from the row

## Out of scope
- Changing how series points are calculated (scoring engine)
- Showing series assignments on the public results page
- The event-level series dropdown (keep it as-is or remove it if it conflicts — see notes below)

## Steps
1. **Extend the per-class Zod schema** — Add `seriesIds: z.array(z.number()).default([])` to the `raceClasses` array item schema in `EventsList.tsx`. Update the grid column template from `[1fr_140px_32px]` to `[1fr_1fr_140px_32px]` (or similar) to make room for the series column. Add a matching header label.

2. **Add the multi-select per class row** — Between the class name input and the max riders input, render a multi-select (use a popover-with-checkboxes pattern matching existing shadcn patterns in the codebase, or a simple multi-checkbox dropdown). Show club series names; store selected series IDs in `raceClasses[index].seriesIds`.

3. **Wire create submission** — In the `onSubmit` handler, before calling `createMutation.mutate(...)`, build `raceClassSeriesMap` from `raceClasses`: `{ [className]: seriesIds[] }`. Pass it in the create payload. Remove (or keep) the existing event-level `createSeriesId` single-select — if it causes double-linking, remove it; if it's for a different purpose, leave it and add a comment.

4. **Wire edit/save submission** — In the edit form (or event edit dialog/sheet if separate), do the same: build `raceClassSeriesMap` from the class rows and include it in the update payload. Pre-populate `seriesIds` on each class row from the event's existing `raceClassSeriesMap`.

5. **Update the AI system prompt** — Add a note to `artifacts/api-server/src/routes/anthropic/SYSTEM_PROMPT.md` that per-class series assignment is now available on the event form.

## Relevant files
- `artifacts/race-platform/src/pages/organizer/EventsList.tsx:78-100,978-1040`
- `lib/db/src/schema/events.ts`
- `lib/api-spec/openapi.yaml`
- `artifacts/api-server/src/routes/anthropic/SYSTEM_PROMPT.md`
