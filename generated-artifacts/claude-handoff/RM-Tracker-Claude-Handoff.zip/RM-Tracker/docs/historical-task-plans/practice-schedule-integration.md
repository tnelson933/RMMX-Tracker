# Add Practice Sessions to the Event Schedule

## What & Why
Organizers need to schedule practice sessions so they appear on the Motos & Lineups page and in the rider portal alongside race motos. Right now, the "Start Practice" button on the Event Practice page immediately starts a live session — there's no way to queue a practice in advance. Riders also have no visibility into when they're up for practice.

## Done looks like
- On the Event Practice page, a second **"Add to Schedule"** button sits next to "Start Practice." Clicking it opens a small dialog for a session name, creates a `practice` moto with `status: scheduled`, and shows a success toast. The organizer can then go to Motos & Lineups and start it from there.
- On the **Motos & Lineups** page, the **"Create Moto"** dialog's Type dropdown includes a **"Practice"** option. When selected, the Race Class field becomes optional (clears and shows "All Classes / Open" option). Practice motos appear in the schedule list and grid view alongside race motos (currently the page filters them out with `type !== "practice"`).
- In the **Rider Portal** schedule (the "Today" and "Upcoming" tabs in RiderHistory), practice motos show up in the run order and "My Schedule" views with a distinct **"Practice"** badge instead of a heat/main/lcq label. The "now up" and "up next" markers work the same way as for race motos. Riders who are checked in to the event (even if not individually slotted in a lineup) see the practice in the run order view.
- Organizers can start a scheduled practice moto directly from the Motos & Lineups page using the same Start button as race motos.

## Out of scope
- Rider-specific lineup slots within a practice moto (practice is open to all checked-in riders — no gate picks needed)
- RFID timing changes (the existing practice timing system is unchanged)
- Standalone practice sessions (not attached to an event) — those remain on the Standalone Practice page
- Notification or push alert when practice is up next

## Steps

1. **"Add to Schedule" button on Event Practice page** — Add a second action button next to "Start Practice" labeled "Add to Schedule." Clicking it opens a simple inline dialog/popover to enter a session name (pre-filled with e.g. "Open Practice"), then calls `useCreateMoto` with `type: "practice"` and `status: "scheduled"`. On success, show a toast: "Practice added to schedule — go to Motos & Lineups to start it."

2. **Add Practice type to the Create Moto dialog on Motos page** — Add `"practice"` to the Type `<SelectItem>` list in the Create Moto dialog. When practice is selected, make the Race Class field optional (add an "All Classes" option and clear the required validation so the moto can be created without a specific class). Wire through `type: "practice"` when calling `useCreateMoto`.

3. **Show practice motos in the Motos & Lineups schedule view** — Remove or loosen the `m.type !== "practice"` filter in the schedule list and grid views so practice motos appear in sequence. Render practice motos with a distinct visual treatment (e.g. a "Practice" badge in a neutral color, no gate/position numbers). The Start button should work for practice motos the same as race motos.

4. **Include practice motos in the rider portal schedule API** — The `/rider/profiles/:id/schedule` route currently filters for race-type motos. Update it to also return `type: "practice"` motos for events the rider is checked into, regardless of whether they have a lineup slot.

5. **Render practice motos in the rider portal schedule UI** — In `RiderHistory.tsx`, update `ScheduleMotoCard` and `ScheduleEventSection` to handle `type: "practice"` motos: show a "Practice" badge, omit gate position info, and include them in the "now up / up next" run-order logic. Practice motos should always appear in the run order view (all checked-in riders are eligible); the "My Schedule" toggle can also show them since the rider is checked in.

## Relevant files
- `artifacts/race-platform/src/pages/organizer/EventPractice.tsx`
- `artifacts/race-platform/src/pages/organizer/Motos.tsx`
- `artifacts/race-platform/src/pages/rider/RiderHistory.tsx:1033-1560`
- `artifacts/race-platform/src/lib/rider-api.ts`
- `artifacts/api-server/src/routes/riders.ts`
- `lib/api-spec/openapi.yaml`
