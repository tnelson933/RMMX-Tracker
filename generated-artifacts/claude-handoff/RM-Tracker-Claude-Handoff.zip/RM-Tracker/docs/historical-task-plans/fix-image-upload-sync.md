# Fix Image Upload Save & Cloud Sync

## What & Why
Image uploads are broken in two different ways depending on where they happen:

1. **Cloud API server saves images to local disk** — `EventDetail.tsx` and `Dashboard.tsx` both call `POST /api/storage/uploads/file` which writes files to a `.uploads/` folder on the server's disk. On the deployed cloud server, these files are ephemeral — they disappear on every restart/redeploy, causing broken images across the organizer portal and public pages.

2. **Local server images never reach the cloud** — When an organizer uploads an event image or club logo on the desktop app, the binary stays on the local machine. During sync (`runSync`), only the text path (`/api/storage/uploads/<uuid>.png`) is pushed to the cloud DB as a string. The actual image file is never transferred, so the web platform shows broken links for every locally-uploaded image.

3. **Creating an event with an image on desktop silently drops the file** — `EventsList.tsx` has a `!isDesktop` guard that skips the image upload step entirely when running in the Electron desktop app. No fallback is attempted, no error is shown.

## Done looks like
- Event images and club logos uploaded through the organizer portal on the **web** (EventDetail, Dashboard) are durably stored in cloud object storage — they survive server restarts
- Event images uploaded on the **desktop app** (EventDetail) show up correctly on the web platform after the next auto-sync cycle
- Club logos uploaded on the **desktop app** (Dashboard) show up correctly on the web after the next sync
- Creating an event with an image attached on the desktop app uploads the image via the direct binary endpoint (no silent drop)
- No regressions: existing presigned URL flow (`EventsList.tsx` on cloud) continues working unchanged

## Out of scope
- Migrating any already-broken/missing images that were lost before this fix
- Rider photo uploads (no photo field exists in the schema)
- The `GET /api/storage/uploads/:filename` fallback serving endpoint (keep as-is for backwards compat)

## Steps

1. **Fix cloud API server direct binary upload to use object storage** — In `artifacts/api-server/src/routes/storage.ts`, change the `POST /storage/uploads/file` handler to upload the received binary into cloud object storage (via `objectStorageService`) instead of writing to local disk. Return an `objectPath` in the `/objects/...` format so the stored URL resolves through the existing `GET /storage/objects/*` proxy. Keep the local `.uploads/` disk path as a last-resort fallback only if the object storage service is unavailable (so the local server's identical endpoint is unaffected — it has no object storage service).

2. **Add image sync step to local server auto-sync** — In `artifacts/local-server/src/auto-sync.ts`, add a `runImageSync()` function that:
   - Queries local SQLite for events with `image_url` matching `/api/storage/uploads/%` and clubs with `logo_url` matching the same pattern
   - For each record, reads the binary from the local `.uploads/` directory
   - POSTs the binary to the cloud's `POST /api/storage/uploads/file` endpoint (using the existing auth header)
   - On success, PATCHes the event (`PATCH /api/events/:id`) or club (`PATCH /api/clubs/:id`) on the cloud with the new cloud-returned `objectPath`
   - Updates the local SQLite record's `image_url`/`logo_url` to the new cloud path so it won't be re-synced on the next run
   - Call `runImageSync()` inside `syncOnce()` after `runSync()` and `runPull()`

3. **Fix desktop event creation to upload image via direct endpoint** — In `artifacts/race-platform/src/pages/organizer/EventsList.tsx`, remove the `!isDesktop` guard from the image upload block. Add a branch: if `isDesktop`, use `POST /api/storage/uploads/file` (direct binary upload, same as EventDetail uses); otherwise keep the existing presigned URL flow. Show a toast error if either path fails.

## Relevant files
- `artifacts/api-server/src/routes/storage.ts`
- `artifacts/api-server/src/lib/objectStorage.ts`
- `artifacts/local-server/src/routes/storage.ts`
- `artifacts/local-server/src/auto-sync.ts`
- `artifacts/race-platform/src/pages/organizer/EventsList.tsx:131-265`
- `artifacts/race-platform/src/pages/organizer/EventDetail.tsx:185-224`
- `artifacts/race-platform/src/pages/organizer/Dashboard.tsx:210-241`
