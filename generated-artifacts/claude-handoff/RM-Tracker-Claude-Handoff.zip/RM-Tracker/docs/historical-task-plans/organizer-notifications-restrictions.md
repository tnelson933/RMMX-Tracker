# Organizer Push Notification Restrictions + Super Admin Broadcast

## What & Why
Organizers currently can blast push notifications to all app users at any time. This scopes their access down to event-specific sends with strict timing and rate limits, while giving super admins unrestricted broadcast capability.

## Done looks like
- **Organizer notifications page**: "All riders" option is gone — organizers must pick a specific event from the dropdown
- **Timing enforcement**: The send button is disabled (with an explanation) when the selected event is not within the allowed window — 24 hours before the event date through end of day on the event date
- **Rate limiting**: Organizers can send at most 1 manual push notification every 4 hours. After sending, a live countdown timer appears on the page showing how long until they can send again. The timer persists if they navigate away and return.
- **Policy education**: A clearly visible policy section on the notifications page tells organizers about the event-only rule, the 24-hour window rule, and the 4-hour cooldown before they ever try to send
- **Super admin broadcast**: A "Push Notifications" panel is added to the super admin area (new `/admin/notifications` page, linked from the sidebar Admin section) where a super admin can send to all riders with no timing or rate restrictions
- All restrictions are enforced server-side so they cannot be bypassed from the client

## Out of scope
- Rate limiting super admin sends
- Email notifications
- Scheduled/future-dated sends

## Steps
1. **DB: track last sent timestamp per user** — Add a `lastPushSentAt` timestamp column to the users table (nullable). Update the Drizzle schema and run a migration. This is used for server-side rate limit enforcement.

2. **API: restrict organizer broadcast endpoint** — Update `POST /admin/notifications/broadcast` to: (a) reject requests with no `eventId` for non-super-admin callers; (b) look up the event date and reject if `now` is not within the window [eventDate − 24h, end of eventDate]; (c) read `lastPushSentAt` for the calling user and reject with a 429 and `retryAfterSeconds` field if fewer than 4 hours have elapsed; (d) on success, update `lastPushSentAt` for the calling user. Include the user's `lastPushSentAt` in the response so the client can sync its timer without a separate fetch.

3. **API: new super-admin-only broadcast endpoint** — Add `POST /admin/notifications/broadcast-all` that requires `role === 'super_admin'` and sends to all registered push tokens with no timing or rate restrictions. Also add `GET /admin/notifications/push-stats` access for super admins (already exists; verify it is accessible from the new page).

4. **Organizer UI: remove "All riders", add policy callout, add timer** — Update `Notifications.tsx`: remove the "All riders" `SelectItem` and change the default state to an empty selection. When no event is selected, show a prompt to pick one. When an event is selected but outside the allowed window, show which window it falls in and disable send. After a successful send (or on page load if `lastPushSentAt` is recent), display a countdown timer ("Next notification available in X:XX:XX") that ticks down and re-enables the form when it expires. Add a clearly visible "Notification Policy" info box near the top of the page (before the form) listing all three rules in plain language.

5. **Super admin UI: new /admin/notifications page** — Create `AdminNotifications.tsx` with a broadcast form (title + body, no event filter, targets all riders). Show the live `push-stats` count. Add a nav link (Bell icon, label "Notifications") in the Admin sidebar section in `OrganizerLayout.tsx`, visible only when `isAdmin` is true. Wire the route in `App.tsx`.

## Relevant files
- `artifacts/race-platform/src/pages/organizer/Notifications.tsx`
- `artifacts/api-server/src/routes/notifications.ts`
- `artifacts/race-platform/src/components/layout/OrganizerLayout.tsx`
- `artifacts/race-platform/src/pages/organizer/UsersAdmin.tsx`
- `artifacts/race-platform/src/App.tsx`
- `lib/db/src/schema/index.ts`
