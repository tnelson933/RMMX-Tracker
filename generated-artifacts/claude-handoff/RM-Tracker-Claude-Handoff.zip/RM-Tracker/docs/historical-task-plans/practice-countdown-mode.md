# Practice Countdown Timer Mode

## What & Why
When an organizer adds a practice moto, they can currently only run it by lap count. This adds a second mode — **countdown** — where the organizer sets a duration (e.g. 15 minutes). When the practice starts, a live countdown timer runs on screen. When it hits zero, the practice automatically completes and signals that the session is over.

## Done looks like
- "Add Practice" dialog has a mode toggle: **Lap Count** (default) or **Countdown**
- Choosing Countdown reveals a duration input (minutes, e.g. 1–120)
- The chosen mode and duration are saved with the moto record
- On the moto card / active practice view, countdown motos show a live counting-down timer instead of lap count progress
- When the countdown reaches zero, the moto status is automatically set to `completed`, the timer shows "00:00", and a clear visual signal (e.g. banner or color change) indicates practice is done
- Lap Count mode behavior is unchanged

## Out of scope
- Audio alerts or browser notifications
- Server-side enforcement of the countdown (the frontend drives the timer; the PATCH to `completed` is the only server call)
- Countdown mode for scored race motos (practice only)

## Steps
1. **DB schema** — Add two nullable columns to the `motos` table: `practiceMode` (enum: `lap_count` | `countdown`, default `lap_count`) and `countdownSeconds` (integer, nullable). Run `pnpm --filter @workspace/db run push` after.

2. **OpenAPI spec + codegen** — Add `practiceMode` and `countdownSeconds` to the moto create request body and moto response schema in `openapi.yaml`. Run codegen to regenerate hooks and Zod types.

3. **API route** — Update the `POST /events/:eventId/motos` handler to accept and persist the new fields. Update `PATCH /motos/:motoId` to confirm no extra changes needed for auto-complete (the frontend sends `status: completed` when the timer expires — no server-side timer needed).

4. **Add Practice dialog** — In `EventSchedule.tsx`, extend the practice dialog with a mode toggle (Lap Count / Countdown). When Countdown is selected, show a number input for duration in minutes. Pass `practiceMode` and `countdownSeconds` (minutes × 60) to the create mutation.

5. **Countdown timer UI** — On the moto card / active practice view, detect `practiceMode === 'countdown'` and render a live countdown instead of lap progress. Use `startedAt` + `countdownSeconds` to compute remaining time. When the timer hits zero, fire the PATCH to set `status: completed` and display a "Practice Complete" state on the card.

## Relevant files
- `lib/db/src/schema/motos.ts`
- `lib/api-spec/openapi.yaml`
- `artifacts/api-server/src/routes/motos.ts`
- `artifacts/race-platform/src/pages/organizer/EventSchedule.tsx`
