# Gate Pick Method Selection for Lineup Generation

## What & Why
Organizers need control over how gate positions are seeded when generating motos. The current system offers only a practice-seeding on/off toggle. This replaces that toggle with a first-class "Gate Pick Method" selector offering three options:

- **Random** — riders are shuffled randomly into gate positions.
- **Practice Fastest Lap** — riders are seeded by their best practice lap time (fastest = best gate pick, slowest = last pick). This is the current "practice seeding" behavior.
- **Previous Round** — riders are seeded by their finish position in the most recently completed round of motos for that class. When multiple heats ran in that round, riders tied at the same position (e.g., two 1st-place finishers from different heats) are broken by their fastest lap time in that moto — the rider with the faster lap gets the better pick.

## Done looks like
- The Generate Lineups dialog replaces the "Use practice lap seeding" checkbox with a "Gate Pick Method" selector (radio or select).
- **Random** is always available.
- **Practice Fastest Lap** is available whenever the club has practice crossing data for the event.
- **Previous Round** is available only when at least one completed moto exists for the event; it is grayed out (with a tooltip explaining why) when no prior round results exist.
- The Gate Config dropdown remains visible for all three methods.
- After generating, each moto lineup's gate assignments reflect the chosen method — random order, fastest-lap order, or previous-round-result order respectively.
- The API accepts `gateSeedingMethod: 'random' | 'practice_fastest_lap' | 'previous_round'` and defaults to `'random'` when omitted (preserving backward compatibility).
- "Previous Round" ties across heats are broken by fastest lap time in those motos (ascending). If lap data is missing for a rider, they fall to the end of the tiebreak group.

## Out of scope
- Persisting the last-used gate pick method as a per-event default (future).
- Per-class gate pick method overrides (all classes use the same method in one generation run).
- Changing how gate priorities map seed positions to physical gate numbers — that existing behavior is unchanged.

## Steps

1. **OpenAPI spec** — Add `gateSeedingMethod` as an optional enum field (`random`, `practice_fastest_lap`, `previous_round`) to the generate-lineups request body schema. Run codegen to regenerate typed hooks and Zod schemas.

2. **Backend — Previous Round seeding logic** — In the motos route's `generate-lineups` handler, implement the previous-round seeding algorithm:
   - Identify the highest completed round number for each class by querying existing motos where `status = 'completed'` for the event.
   - Load `race_results` for those motos along with each moto's `lineup` (to extract fastest lap times per rider from the lap crossing records, or from stored result data if available).
   - Build a ranked seed list: primary sort by finish position (ascending), secondary sort by fastest lap time in that moto (ascending, nulls last) to break ties across heats at the same position.
   - Wire this seed list into the existing gate-assignment path the same way practice seeding currently works.

3. **Backend — Method dispatch** — Refactor the seeding section of `generate-lineups` to branch on `gateSeedingMethod`: `random` uses the current default shuffle; `practice_fastest_lap` uses the existing practice-crossing query; `previous_round` uses the new algorithm from step 2. Default to `random` when the field is absent.

4. **Frontend — Generate Lineups dialog UI** — Replace the "Use practice lap seeding" checkbox in `Motos.tsx` with a Gate Pick Method control (segmented control or select with three options). Disable "Previous Round" and show a tooltip ("No completed motos yet — run Round 1 first") when the event has no completed motos. Keep the Gate Config dropdown visible for all three methods.

5. **Frontend — Wire selection to mutation** — Pass the selected `gateSeedingMethod` value through to the generate-lineups API call. Ensure the dialog resets to `'random'` on close.

## Relevant files
- `lib/api-spec/openapi.yaml`
- `lib/api-client-react/src/generated/`
- `artifacts/api-server/src/routes/motos.ts`
- `artifacts/race-platform/src/pages/organizer/Motos.tsx`
- `lib/db/src/schema/motos.ts`
