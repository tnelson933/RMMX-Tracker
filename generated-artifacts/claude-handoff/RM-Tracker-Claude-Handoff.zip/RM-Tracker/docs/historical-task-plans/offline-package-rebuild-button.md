# Add "Rebuild Package" Button to Offline Mode Page

## What & Why
Organizers who make changes to the local server code currently have no way to trigger a fresh package build from the UI — they have to click Download and hope the auto-rebuild kicks in. A dedicated "Rebuild Now" button next to the package info banner lets them explicitly rebuild first, then download the updated zip.

## Done looks like
- A "Rebuild" button appears next to (or below) the package version info in Step 1 of the Offline Mode page.
- Clicking it calls a new `POST /offline/package-rebuild` API endpoint, shows a loading spinner while the build runs (which can take a few seconds), and refreshes the displayed version/date when done.
- If the rebuild fails, a clear error message is shown inline.
- After a successful rebuild the download link immediately reflects the new version without a page refresh.

## Out of scope
- Changing the auto-rebuild behavior that already runs on download.
- Any scheduling or automated triggers.
- Any UI changes outside the Offline Mode page.

## Steps
1. **API endpoint** — Add `POST /offline/package-rebuild` to `artifacts/api-server/src/routes/offline.ts`. It must require authentication, run `rebuildLocalServer`, invalidate the zip cache, and return the new `{ builtAt, version, etag }` on success or a 503 with `{ error }` on failure.

2. **OpenAPI spec** — Add the `POST /offline/package-rebuild` operation to `lib/api-spec/openapi.yaml` under the `offline` tag, with a `200` response matching the existing `OfflinePackageInfo` schema and a `503` error shape.

3. **Codegen** — Run `pnpm --filter @workspace/api-spec run codegen` to generate the new `useRebuildOfflinePackage` mutation hook.

4. **Frontend button** — In `artifacts/race-platform/src/pages/organizer/OfflineMode.tsx`, add a "Rebuild" button (with `RefreshCw` icon) directly beside the version/date line in the package info area. Wire it to the new mutation hook: show a spinner + "Rebuilding…" label while pending, replace the banner text with the fresh `builtAt`/`version` on success, and show an inline error callout on failure.

## Relevant files
- `artifacts/api-server/src/routes/offline.ts`
- `lib/api-spec/openapi.yaml:56-100`
- `artifacts/race-platform/src/pages/organizer/OfflineMode.tsx:166-283`
- `lib/api-client-react/src/generated/api.ts`
