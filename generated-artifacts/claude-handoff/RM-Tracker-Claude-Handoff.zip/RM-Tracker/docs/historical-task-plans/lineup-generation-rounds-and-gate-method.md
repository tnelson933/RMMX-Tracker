# Lineup Generation — Round Selection & Gate Pick Method

## What & Why
Right now "Generate Lineups" always regenerates every round for every class at once, and the only gate seeding option is practice lap times. In practice, promoters run events round by round — they generate Round 1 before gates open, then generate Round 2 only after Round 1 is done. They also need to assign gates based on how riders finished the previous round (best finish = first gate pick), or by random draw. This change makes generation match how events are actually run.

## Done looks like
- Clicking "Generate Lineups" opens a dialog that asks which round(s) to generate — defaults to the lowest uncompleted round, shows which rounds already have completed motos.
- The dialog has a gate pick method step with these options:
  - **No gate assignment** — positions only, no gate numbers
  - **Random draw** — gates assigned randomly
  - **By practice session** — existing behavior, fastest lap gets first gate pick (only shown if practice data exists)
  - **By prior round finish** — best finisher from the previous round gets first gate pick (only available when generating Round 2 or later)
- On the Schedule tab, clicking into a moto shows a "Generate Lineup" button that regenerates just that single moto using the same gate pick options.
- On the Motos/Grid tab, each moto card has the same per-moto generate action.
- The backend respects the `rounds` array and only creates/replaces motos for the specified rounds; motos from other rounds are untouched.
- "By prior round finish" reads the completed results from the previous round for that class and assigns gates in reverse finish order (1st place picks first gate, i.e., gate priority 1).

## Out of scope
- Generating lineups for Supercross-format events (heat → main auto-advance already handles that path)
- Series points as a gate pick method (future)
- Drag-to-reorder gates after generation (Task #22 already covers that)

## Steps

1. **Extend the OpenAPI spec** — Add `rounds` (array of integers, optional — omit means all rounds), `gatePickMethod` (`"none" | "random" | "practice" | "prior_round_finish"`), and `gateConfigId` (already exists) to the `generateLineups` request body. Add a new `POST /events/{eventId}/motos/{motoId}/generate-lineup` endpoint that accepts the same gate pick params and regenerates only that one moto. Run codegen after.

2. **Backend — round filtering** — In the `generate-lineups` handler, if `rounds` is provided, skip generating any round number that isn't in the array. Round number maps to the `d` loop index (Moto 1 = round 1, Moto 2 = round 2, etc.). Existing completed-moto guard remains; the new `rounds` param is an additional filter on top.

3. **Backend — gate pick methods** — Extract gate assignment into a `resolveGates(method, riders, eventId, raceClass, round, gateSeeding)` helper. Implement `random` (shuffle gate indices), `none` (no gate field), `prior_round_finish` (query the most recently completed moto for `raceClass` in this event at `round - 1`, read its `lineup` finish positions from `race_results`, sort riders accordingly, assign gates in that order using the club's gate seeding priority list).

4. **Backend — per-moto endpoint** — Implement `POST /events/:eventId/motos/:motoId/generate-lineup`. Look up the moto's `raceClass` and round number, fetch checked-in riders for that class, apply the requested gate pick method, update the moto's `lineup` in place (only if status is `scheduled` or `in_progress` — refuse if `completed`).

5. **Frontend — round selection step in dialog** — Add a first step to the Generate Lineups dialog: a list of available rounds (Round 1, Round 2, Round 3 based on the chosen race format) with checkboxes. Pre-select the lowest round that has no completed motos for any class. Show a "(done)" badge next to rounds where every class already has a completed moto.

6. **Frontend — gate pick method step in dialog** — Add a second step (or a section below round selection) with radio buttons for the four gate pick methods. Disable "By prior round finish" when only Round 1 is selected. Show "By practice session" only if the event has at least one completed practice moto. Default to "No gate assignment" when no practice data exists.

7. **Frontend — per-moto generate action** — On the Schedule tab moto detail panel and the Motos/Grid tab moto card, add a "Generate Lineup" button that opens a compact sheet/popover with just the gate pick method options (round is already known from the moto). Wire it to the new per-moto endpoint. Disable the button if the moto is `completed`.

## Relevant files
- `lib/api-spec/openapi.yaml`
- `artifacts/api-server/src/routes/motos.ts:231-457`
- `artifacts/race-platform/src/pages/organizer/EventSchedule.tsx`
- `artifacts/race-platform/src/pages/organizer/Motos.tsx`
- `lib/api-client-react/src/generated/api.ts`
- `lib/api-zod/src/generated/api.ts`
