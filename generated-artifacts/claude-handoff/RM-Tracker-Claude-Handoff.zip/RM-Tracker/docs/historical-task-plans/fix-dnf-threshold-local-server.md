# Fix DNF Threshold Not Saving on Local Server

## What & Why
The Auto DNF threshold setting resets to its default every time the organizer navigates away from the Points Scoring Tables page on the local (desktop) server. The root cause is that the local SQLite `clubs` table, created by `db-init.ts`, only has four columns (`id`, `name`, `state`, `created_at`) — the `auto_dnf_enabled` and `auto_dnf_threshold` columns that the route handler reads and writes simply do not exist. Every PATCH silently fails to change anything, and every GET returns `null`, falling back to the hardcoded default of 75 (displayed as 80% if the DB was seeded differently).

## Done looks like
- Organizer sets the DNF threshold to any value (e.g. 50%), clicks Save, navigates away, and returns — the saved value is shown correctly every time.
- The toggle (enable/disable Auto DNF) also persists correctly across navigation.
- Existing local-server installs with the old schema are migrated automatically on next launch via an `ALTER TABLE` migration guard.

## Out of scope
- Cloud API / Postgres schema (already correct in `lib/db/src/schema/clubs.ts`).
- Any changes to the frontend `PointsTables.tsx` save/load logic (it is already correct).

## Steps
1. **Add migration in `db-init.ts`** — after the existing `CREATE TABLE IF NOT EXISTS clubs` block, add an `ALTER TABLE` migration that checks whether `auto_dnf_enabled` and `auto_dnf_threshold` columns exist (via `PRAGMA table_info(clubs)`) and adds them if missing. Use `INTEGER NOT NULL DEFAULT 0` for `auto_dnf_enabled` and `INTEGER NOT NULL DEFAULT 75` for `auto_dnf_threshold` to match the Postgres schema defaults.

## Relevant files
- `artifacts/local-server/src/db-init.ts:94-107`
- `artifacts/local-server/src/routes/clubs.ts`
