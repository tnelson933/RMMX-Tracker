# Offline Mode Page — Dynamic Data, Neutral Language, Working Links

## What & Why
The Offline Mode page has three problems today:
1. Club ID and cloud domain are hardcoded placeholders (`clubId=<id>`, `CLUB_ID=1`, `https://your-app.replit.app`) — organizers have to look these up and fill them in manually.
2. "RFID" is used throughout, which implies only RFID hardware is supported. The platform also works with MyLaps and other transponder-based systems.
3. The "Admin → Sync from Offline Export" link is marked "Coming soon" and goes nowhere — it should be a real, working upload page.

## Done looks like
- Every code snippet and URL on the page that references the club ID or cloud domain is pre-filled with the logged-in organizer's actual values — they can copy and paste without editing.
- "RFID" is replaced with neutral language ("transponder", "timing hardware", "timing system") everywhere on the page. The link to the reader setup page uses neutral link text.
- The "Sync from Offline Export" section links to a real new page (`/offline/sync`) where the organizer can upload their SQLite export file and trigger the cloud import. The "Coming soon" badge is removed.
- The new sync upload page has a file picker, a clear status/progress indicator, and a success confirmation. It requires login (ProtectedRoute).

## Out of scope
- The local server package download button (handled by Task #56).
- Actual server-side processing of the SQLite import (the upload page can show a clear "upload received — admin will process" message if a full automated import pipeline is not yet in place, but the UI must be functional with no "coming soon" states).
- Changes to the `/rfid/setup` route path itself.

## Steps
1. **Read auth context and inject dynamic values** — In `OfflineMode.tsx`, call `useAuth()` to get `user?.clubId` and use `window.location.origin` for the cloud domain. Replace all hardcoded `clubId=<id>`, `CLUB_ID=1`, and `https://your-app.replit.app` placeholders throughout every code block and URL snippet with the live values. Show a small "copy" button or inline badge next to each filled-in value.

2. **Neutralize timing hardware language** — Audit every occurrence of "RFID" on the page. Replace with neutral alternatives: "transponder timing" for the feature name, "transponder/tag assignment" for the checklist item, "timing hardware" for hardware references, "timing assignments" in the sync description. Update the Reader Setup link text to say "Timing Hardware Setup" (the href `/rfid/setup` stays the same).

3. **Build the Offline Sync upload page** — Create a new page at `artifacts/race-platform/src/pages/organizer/OfflineSync.tsx`. The page should have: a file input that accepts `.db` and `.zip` files, a clear description of what to upload (the `race_data.db` SQLite export), a submit button that POSTs the file to `/api/offline/sync-upload`, and states for idle / uploading / success / error. Wire it into `App.tsx` as a protected route at `/offline/sync`.

4. **Add the API endpoint for file receipt** — Add a `POST /offline/sync-upload` route to the API server that accepts a multipart file upload, saves it to a temp location, logs the receipt (club ID from session, filename, timestamp, file size), and returns `{ received: true, message: "..." }`. No automated processing is needed — the endpoint just safely accepts and acknowledges the file.

5. **Wire up the "Coming soon" link** — In `OfflineMode.tsx`, replace the "Admin → Sync from Offline Export" coming-soon display with a real `<Link>` (wouter) to `/offline/sync`. Remove the "Coming soon" badge. Update the surrounding copy to instruct the organizer to use the sync page after running the CLI script.

6. **OpenAPI spec + codegen** — Add the `POST /offline/sync-upload` endpoint to `lib/api-spec/openapi.yaml` and run codegen so the frontend can use the generated hook.

## Relevant files
- `artifacts/race-platform/src/pages/organizer/OfflineMode.tsx`
- `artifacts/race-platform/src/pages/organizer/ReaderSetup.tsx`
- `artifacts/race-platform/src/contexts/AuthContext.tsx`
- `artifacts/race-platform/src/App.tsx`
- `artifacts/api-server/src/routes/`
- `lib/api-spec/openapi.yaml`
