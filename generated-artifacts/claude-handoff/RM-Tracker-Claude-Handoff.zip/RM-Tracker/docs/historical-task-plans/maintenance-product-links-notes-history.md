# Maintenance: Product Links, Service Notes & History Log

## What & Why
Three connected improvements to the Rider App maintenance schedule screen:
1. **Shop links** — each maintenance item gets a "Shop" button that opens a relevant product search on rockymountainatvmc.com so riders can buy what they need in one tap.
2. **Service notes** — tapping "Log Service Today" opens a small bottom sheet where riders can optionally type notes (oil type, brand, observations) before the log is saved.
3. **Maintenance history log** — every time service is logged, a history record is written to a new DB table. A new "History" screen lets riders review the full log for a bike: item name, date serviced, and any notes.

## Done looks like
- Every maintenance card has a "Shop" link icon/button; tapping it opens the Rocky Mountain ATV/MC search results page for that item in the device browser.
- Tapping "Log Service Today" shows a modal/bottom sheet with an optional notes text input and a "Save" button; if the rider leaves notes blank and saves, it logs normally with no notes.
- Notes entered at log time are stored with the history record AND update the item's current notes field.
- A "History" button/link on the maintenance screen navigates to a new screen listing every logged service entry for that bike — sorted newest first — showing item name, date, and notes (if any).
- The history screen has a back button and the bike name in the header, matching the existing maintenance screen style.

## Out of scope
- Linking to specific product pages (only search URLs are used since item names are AI-generated and vary).
- Editing or deleting past history entries.
- History entries for services logged before this task (no backfill).
- Push notifications for overdue items.

## Steps

1. **New DB table: `rider_maintenance_history`** — Add a `rider_maintenance_history` table to `lib/db/src/schema/maintenance.ts` with fields: `id`, `riderId` (FK to riders), `itemKey`, `itemName`, `servicedAt` (date string), `notes` (nullable text), `createdAt`. Export the new table and run `pnpm --filter @workspace/db run push` to apply the migration.

2. **API: write history on every service log** — In the PUT `/rider/maintenance/:riderId/:itemKey` route, after the upsert succeeds, also insert a row into `rider_maintenance_history` with the service date and any notes from the request body. Also update the Rocky mechanic-chat handler (`/rider/mechanic-chat`) so AI-triggered logs similarly write a history row.

3. **API: history list endpoint** — Add `GET /rider/maintenance/:riderId/history` that returns all history rows for a rider, ordered by `servicedAt` descending. Add it to the OpenAPI spec and run codegen.

4. **Rider App: "Log Service" bottom sheet with notes** — Replace the direct `handleLogService` call with a bottom sheet (use a `Modal` with a slide-up style, consistent with the app's existing patterns). The sheet shows the item name, an optional multi-line text input for notes, and "Save" / "Cancel" buttons. On save, pass the notes through to the existing PUT endpoint body.

5. **Rider App: "Shop" link on each card** — Add a small "Shop" button/icon to each maintenance item card. On press, open `https://www.rockymountainatvmc.com/search#q=${encodeURIComponent(item.itemName)}` via `Linking.openURL`. Place it next to or below the "Log Service" button without cluttering the card layout.

6. **Rider App: maintenance history screen** — Create `artifacts/rider-app/app/maintenance/history/[riderId].tsx`. Fetch from the new history endpoint, render a list of entries sorted newest first. Each row shows: item name (bold), date formatted as "Month D, YYYY", and notes in muted italic below if present. Show a friendly empty state if no history yet. Add a "History" button to the maintenance screen header (e.g. a clock/history icon) that navigates to this new screen.

## Relevant files
- `lib/db/src/schema/maintenance.ts`
- `lib/db/src/schema/index.ts`
- `artifacts/api-server/src/routes/rider-portal.ts:1604-1801`
- `lib/api-spec/openapi.yaml`
- `artifacts/rider-app/app/maintenance/[riderId].tsx`
