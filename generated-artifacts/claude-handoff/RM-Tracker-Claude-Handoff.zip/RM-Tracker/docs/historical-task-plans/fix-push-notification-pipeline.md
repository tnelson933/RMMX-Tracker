# Fix Push Notification Pipeline End-to-End

## What & Why
Organizers see "No riders in this audience have the app installed — nobody will receive this" on the Notifications page, and the Send button is disabled. The root cause is a chain of silent failures: the rider app never stores a push token in the database, so audience counts are always 0, and race-day automatic notifications (next up / 3 races away) also silently do nothing.

## Done looks like
- A rider who logs into the app on a real device and grants notification permission has their Expo push token stored in the database
- The organizer Notifications page shows a non-zero audience count for riders who have the app
- When an organizer sends a broadcast, riders receive the push notification on their device
- Automatic moto notifications (next up / 3 races away) reach riders who are in the lineup
- Stale/invalid tokens (DeviceNotRegistered) are pruned from the database automatically after a send
- Server logs capture push delivery errors instead of swallowing them silently

## Out of scope
- Changing the existing Expo push infrastructure (still uses `exp.host`)
- Adding notification categories or rich media
- Building a per-rider notification debug UI

## Steps

1. **Fix `tryRegisterPushToken` in the rider app** — Remove the blanket `catch { /* ignore */ }` and replace it with proper error visibility: log failures to the console in development, show an `Alert` in production if the Expo token fetch itself throws (distinct from the permission-denied alert that already exists). Also ensure the POST to `/api/rider/push-token` is awaited and its failure is logged, not swallowed.

2. **Verify Bearer token → push-token registration path on the server** — Confirm `requireRiderAuth` correctly resolves `riderAccountId` from the mobile Bearer token before the push-token route reads it. Add a server-side log entry when a push token is registered or updated so it's visible in the API logs.

3. **Fix `sendPushNotifications` in `push.ts` to handle Expo API responses** — After each batch POST to `https://exp.host/--/api/v2/push/send`, parse the response JSON. For any receipt with `status: "error"` and `details.error === "DeviceNotRegistered"`, delete that token from `rider_push_tokens`. Log all delivery errors via the server logger instead of swallowing them in the catch block. This applies to both `artifacts/api-server/src/lib/push.ts` and `artifacts/local-server/src/lib/push.ts` (they are separate copies).

4. **Fix `canSend` guard in `Notifications.tsx`** — Currently the Send button is permanently disabled when `audienceCount === 0`. Change the guard so the button is enabled as long as the audience is selected and the form is filled — move the zero-count into a warning, not a blocker. The server already handles the 0-token case gracefully (returns `{ ok: true, sent: 0 }`). This unblocks organizers from sending even when the count hasn't loaded or is temporarily showing 0.

5. **Add a push-stats diagnostic endpoint and surface it in the organizer UI** — Extend `GET /api/admin/notifications/push-stats` to also return `{ total, byClub }` so the organizer can see how many of their specific riders have tokens (separate from the global total). Update the Notifications page header to show the club-scoped count rather than the global total.

## Relevant files
- `artifacts/rider-app/context/AuthContext.tsx`
- `artifacts/api-server/src/lib/push.ts`
- `artifacts/local-server/src/lib/push.ts`
- `artifacts/api-server/src/routes/rider-portal.ts:39-60,233-250`
- `artifacts/api-server/src/routes/notifications.ts`
- `artifacts/race-platform/src/pages/organizer/Notifications.tsx:114-163`
- `artifacts/api-server/src/routes/motos.ts:8-62`
