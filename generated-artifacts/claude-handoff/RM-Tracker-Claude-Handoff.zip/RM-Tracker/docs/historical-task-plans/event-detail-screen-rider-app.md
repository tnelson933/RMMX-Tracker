# Event Detail Screen — Rider App

## What & Why
Right now the events list in the Rider App is a read-only billboard — tapping a card does nothing. Riders need to be able to tap into an event to see what's relevant *right now*: live lineup and class schedule when an event is running today, or full event details with a registration prompt when an event is upcoming.

## Done looks like
- Every event card on the Events tab is tappable and navigates to a detail screen.
- **Live view** (event `status === 'race_day'` and date is today): shows the event name/date/location header, then motos grouped by class — each moto card lists the gate order (bib + rider name), current moto status, and moto number. A "Live Today" badge is prominent at the top.
- **Upcoming view** (event `status === 'registration_open'`): shows full event details (date, location, entry fee, race classes offered) and a "Register Now" call-to-action button. The CTA opens the existing registration flow or links to the club's external registration URL if one is set.
- A back button / swipe returns to the events list.
- Loading and error states are handled gracefully (skeleton on load, inline error message on failure).

## Out of scope
- In-app registration form itself (the CTA links out or to an existing route).
- Results/scoring display (covered by the My Races tab and public results pages).
- Events with status `draft` or `completed` (these are already filtered out of the events list).

## Steps
1. **Add navigation to event cards** — Wrap `EventCard` in a `Pressable` (or add `onPress`) that pushes to a new route `/event/[id]`. Register the route in the root stack layout (`app/_layout.tsx`).

2. **Create the event detail screen** (`app/event/[id].tsx`) — Fetch event data with `useGetEventsEventId`. Determine the display mode: if `status === 'race_day'` and the event date matches today's date → Live view; if `status === 'registration_open'` → Upcoming view. Show a loading skeleton while fetching and an error state on failure.

3. **Build the Live view** — Fetch motos with `useGetEventsEventIdMotos`. Group motos by race class and render each group as a section. Each moto card shows moto number, status badge, and a numbered gate-order list (bib number + rider name). Use the same visual language (colors, card style, badges) as the rest of the app.

4. **Build the Upcoming view** — Display a details card with date, location/state, entry fee, and the list of race classes. Add a prominent "Register Now" button. If the event has an external registration URL field use it; otherwise link to the in-app registration route if it exists.

5. **Polish and consistency** — Add a sticky header with back navigation, apply the existing brand colors and typography, and ensure the screen works correctly on both iOS and Android.

## Relevant files
- `artifacts/rider-app/app/(tabs)/index.tsx`
- `artifacts/rider-app/app/_layout.tsx`
- `artifacts/rider-app/app/(tabs)/_layout.tsx`
- `artifacts/rider-app/app/(tabs)/my-races.tsx`
- `lib/api-client-react/src/generated/`
