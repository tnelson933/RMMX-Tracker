# Fix iOS Build Number

## What & Why
Fix the Rider App’s Expo production release configuration so App Store publishes do not reuse an iOS build number. Expo’s failed submission log reports `EAS_UPLOAD_TO_ASC_VERSION_DUPLICATE`: build number 1 had already been uploaded for the same app version, while the current project has no automatic iOS build-number increment configured.

## Done looks like
- Every production EAS build receives a newer store build number automatically
- Rebuilding the same marketing version no longer produces an IPA with a duplicate build number
- The Expo production configuration remains valid for both building and submitting the Rider App

## Out of scope
- Changing the user-facing app version
- Reconfiguring Apple signing certificates or the App Store Connect app record
- Triggering or submitting a new App Store release

## Steps
1. **Enable production build-number increments** — Update the Rider App’s EAS production build profile to automatically increment store build versions, preserving the existing production environment and remote credential settings.
2. **Validate release configuration** — Confirm the updated Expo/EAS configuration resolves correctly and that the production iOS profile will generate a build number newer than prior uploads without altering the marketing version.

## Relevant files
- `artifacts/rider-app/eas.json`
- `artifacts/rider-app/app.json`
