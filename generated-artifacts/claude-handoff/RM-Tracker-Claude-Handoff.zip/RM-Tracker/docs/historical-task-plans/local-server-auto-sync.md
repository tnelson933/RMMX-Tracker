# Auto-sync local server when internet is available

## What & Why
When organizers run the offline local server at a venue with no internet, race data (check-ins, RFID assignments, walk-in registrations) accumulates in a local SQLite database. Currently they must manually run `npm run sync` from the terminal after the event to push that data to the cloud. Most organizers will forget, or find the CLI step intimidating.

Instead, the local server should detect internet connectivity automatically and sync in the background once all events are marked completed — no action required from the organizer. They pack up, drive home, and results are already live.

## Done looks like
- The local server polls for cloud connectivity every 2 minutes once started (using the cloud health endpoint)
- Sync fires automatically when: (a) the cloud is reachable AND (b) at least one event in the local SQLite DB has `status = 'completed'`
- Sync is idempotent — re-running it never duplicates data (the existing watermark system already handles this)
- A `GET /status` endpoint on the local server returns sync state: last attempt time, last success time, last error, and row counts synced
- The local server startup console log shows sync configuration (cloud URL, club ID) and whether credentials are present
- If cloud credentials are not configured (CLOUD_URL / CLOUD_EMAIL / CLOUD_PASSWORD env vars absent), auto-sync is disabled and a clear warning is printed at startup — the manual `sync.mjs` script still works as a fallback
- The OfflineMode guide page removes the "Coming soon" admin sync tool reference and replaces it with a plain description of auto-sync behavior

## Out of scope
- Any browser-based upload UI for sync (the auto-sync replaces this entirely)
- Syncing mid-event (only fires once at least one event is `completed`)
- Conflict resolution beyond what the existing watermark system already handles
- Push notifications or email confirmations when sync succeeds

## Steps

1. **Auto-sync module in local server** — Create `artifacts/local-server/src/auto-sync.ts` that encapsulates the sync loop: connectivity probe → event completion gate → authenticate → POST to `/api/clubs/:clubId/sync`. Extract the fetch/auth/POST logic from `sync.ts` into a shared helper so both the CLI script and auto-sync module use the same code path.

2. **Sync state tracking** — Store sync state (lastAttemptAt, lastSuccessAt, rowCounts, lastError) in a `_sync_state` table in SQLite (created on startup if absent). This persists across local server restarts so organizers can see sync history.

3. **Wire the loop into server startup** — In `artifacts/local-server/src/index.ts`, start the auto-sync loop after the HTTP server is listening. Validate env vars at startup and print a clear summary (sync enabled/disabled, cloud URL, club ID). Poll every 2 minutes using `setInterval`.

4. **Status endpoint** — Add `GET /status` route to the local server that returns JSON with server uptime, database path, event summary (count + statuses), and sync state from `_sync_state`. This lets organizers quickly verify sync happened without reading terminal logs.

5. **Update OfflineMode page** — Remove the "Coming soon" admin sync tool callout and replace it with a short plain-English note explaining that the local server auto-syncs once the event is completed, and that organizers can check sync status at `http://<laptop-ip>:8080/status`.

## Relevant files
- `artifacts/local-server/src/sync.ts`
- `artifacts/local-server/src/index.ts`
- `artifacts/local-server/src/app.ts`
- `artifacts/local-server/src/routes/index.ts`
- `artifacts/local-server/src/db.ts`
- `artifacts/local-server/src/db-init.ts`
- `artifacts/race-platform/src/pages/organizer/OfflineMode.tsx`
