# Fix Rebuild Now Button Flash on Sync

## What & Why
On the Offline Mode page, the "Rebuild Now" button flashes on every sync cycle. The `pkgInfo` query briefly returns `undefined` while refetching, making `!pkgInfo && !pkgError` true for a moment — causing the button to appear and disappear rapidly.

## Done looks like
- The "Rebuild Now" button only appears when package info has definitively never loaded (first visit with no data) or when a rebuild is explicitly needed
- The button does not flash in and out during normal sync cycles
- The "Download info unavailable" error message also does not flash during normal syncs

## Out of scope
- Changes to sync frequency or sync logic
- Any other offline mode UI changes

## Steps
1. **Guard the button with `isPending`** — Destructure `isPending` (or `isLoading`) from `useGetOfflinePackageInfo` alongside `pkgInfo` and `pkgError`. Change the render condition for the "Rebuild Now" button from `!pkgInfo && !pkgError` to `!pkgInfo && !pkgError && !isPending` so the button is suppressed while the query is in its loading/refetching state. Apply the same guard to the `pkgError` block so the error banner also doesn't flash on transient refetches — only show it when not loading.

## Relevant files
- `artifacts/race-platform/src/pages/organizer/OfflineMode.tsx:199,590-614`
