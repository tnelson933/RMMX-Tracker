# AMA-Consistent Division Naming for Split Classes

## What & Why
When a class has too many riders for one gate, the generator splits them into sub-groups. The current code labels these **"Group 1 / Group 2"**, but AMA convention at local and regional events is **"Div 1 / Div 2"** (short for Division). Riders and promoters universally expect this terminology — it also aligns with how the frontend already refers to them in tooltips and the points table selector.

## Done looks like
- Generated motos for a split class are named **"125cc Div 1 Moto 1"**, **"125cc Div 2 Moto 1"**, etc. (not "Group 1")
- Single-group classes are unchanged: **"125cc Moto 1"** (no division label)
- Supercross heats and Main Events are unchanged (they use "Heat" / "Main Event" — correct per AMA)
- Existing seed/demo motos that already carry "Group" in their name are updated to "Div" so the demo event looks correct out of the box

## Out of scope
- Changing scoring logic or how divisions are awarded points (each div already scores independently)
- Changing the scheduling run order (already correct — Div 1 and Div 2 run back-to-back within each round)
- Renaming the `type` field values in the DB schema (`heat`, `main`, `practice` stay as-is)

## Steps
1. **Rename in moto generator** — In `artifacts/api-server/src/routes/motos.ts`, change the `groupLabel` variable from `` `Group ${h + 1}` `` to `` `Div ${h + 1}` `` so all newly generated split-class motos use AMA division naming.
2. **Update seed data** — In the dev seed script, update any existing moto names that contain "Group N" to "Div N" so the demo event shows the correct labels.
3. **Verify frontend alignment** — Confirm that any frontend strings referencing "Group" in the context of split-class motos are updated to "Division" / "Div" to stay consistent with what's now generated.

## Relevant files
- `artifacts/api-server/src/routes/motos.ts:432-450`
