# Event Schedule / Race Order Builder

## What & Why
Add an **Event Schedule** tab between Check-In and Practice in the organizer event view. This gives organizers a single place to see and manage the full day's run order — all practice sessions and race motos in sequence — similar to the race order builder on Trackside Race Platform. Organizers can reorder motos by dragging, set scheduled start times, and see the complete day's timeline at a glance before heading to the Motos & Lineups tab to manage gate assignments and live timing.

## Done looks like
- A new "Schedule" tab appears in the event sub-nav between Check-In and Practice
- All motos (practice + race) for the event are shown as cards in run-order sequence
- Each card displays: class name, moto type (Practice / Heat 1 / Heat 2 / LCQ / Main), status badge, rider count, lap count, and scheduled time
- Organizers can drag cards to reorder the run order; the new order persists (updates `motoNumber` via API)
- Each moto has an inline editable scheduled start time (uses the existing `scheduledTime` field)
- An "Add Moto" button lets organizers create a new moto for any class/type directly from the schedule view
- An event start time input at the top lets organizers set the day's start; a "Auto-fill times" action estimates scheduled times based on start time + per-session lap count (assuming ~2 min/lap average)
- Motos are visually grouped by section (e.g. all Practice sessions first, then Heats, then LCQ/Mains) with a toggle to switch between run-order and grouped-by-class views
- Status badges (Scheduled / In Progress / Completed / Cancelled) are shown on each moto card and are not editable here (managed in Motos & Lineups)
- Clicking a moto card links directly to that moto in the Motos & Lineups tab

## Out of scope
- Live timing or gate assignment editing (that stays in Motos & Lineups)
- Generating lineups (that stays in Motos & Lineups)
- Practice session creation (that stays in the Practice tab)
- Printing the heat sheet as PDF (covered by existing Task #38)
- Public-facing schedule display

## Steps

1. **API — reorder endpoint**: Add `POST /events/{eventId}/motos/reorder` to the OpenAPI spec that accepts an ordered array of moto IDs and bulk-updates their `motoNumber` values. Add the route handler in `artifacts/api-server/src/routes/motos.ts`. Run codegen to generate the typed hook.

2. **API — scheduledTime patch**: Confirm `scheduledTime` is included in `MotoUpdate` in the OpenAPI spec (it already is). Ensure the route handler for `PATCH /motos/{motoId}` accepts and saves `scheduledTime`. No schema change needed.

3. **Frontend — EventSchedule page**: Create `artifacts/race-platform/src/pages/organizer/EventSchedule.tsx`. Load all motos via `useListMotos`. Render moto cards in `motoNumber` order. Use `@dnd-kit/core` (already a dependency) for drag-and-drop reordering. On drop, call the reorder endpoint with the new order. Each card shows class, type badge, status badge, rider count, lap count, and an inline time picker for `scheduledTime` that calls `useUpdateMoto` on blur.

4. **Frontend — Add Moto dialog**: Include a dialog on the schedule page for adding a new moto (class name, type, lap count, optional scheduled time). Calls `useCreateMoto`. Appends the new moto to the end of the run order.

5. **Frontend — Auto-fill times**: Add an event start time input at the top of the schedule. A "Auto-fill times" button calculates and sets `scheduledTime` for each moto sequentially, estimating duration as `lapCount × 2 minutes` (or 15 minutes for open practice) with a configurable gap between sessions.

6. **Frontend — View toggle**: Add a toggle between "Run Order" (flat chronological list) and "By Class" (motos grouped by raceClass, sorted by motoNumber within each group).

7. **Register route**: Add the `/events/:eventId/schedule` route and `EventSchedule` import to `EventLayout.tsx`, inserting the "Schedule" nav link between Check-In and Practice.

## Relevant files
- `artifacts/race-platform/src/pages/organizer/EventLayout.tsx`
- `artifacts/race-platform/src/pages/organizer/Motos.tsx:1-80`
- `artifacts/api-server/src/routes/motos.ts`
- `lib/api-spec/openapi.yaml`
- `lib/db/src/schema/motos.ts`
