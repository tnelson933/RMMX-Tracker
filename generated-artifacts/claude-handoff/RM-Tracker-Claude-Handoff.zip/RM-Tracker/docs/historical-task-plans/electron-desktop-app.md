# Electron Desktop App with Live Cloud Sync

## What & Why
Package the race platform as a native Electron desktop application so organizers can run it on a laptop at the track. The desktop app eliminates all USB/serial workarounds for RFID readers (Electron has direct Node.js hardware access), works fully when internet drops, and syncs every change instantly to the cloud when connected — so the hosted web app and desktop app stay in perfect lockstep.

## Done looks like
- Organizers can download and install a single `.dmg` (Mac) or `.exe` (Windows) file — no terminal, no Node setup required
- The app opens a native window running the full race platform UI, identical to the web version
- RFID readers connect via native serial/USB — no Python bridge workarounds, no browser permissions
- All writes go to local SQLite first, then push to the cloud API immediately when online
- When internet is unavailable, the app keeps working; a sync status indicator shows pending changes
- When connectivity returns, the queue flushes automatically and the cloud is updated
- Cloud-to-local sync pulls any changes made from the web portal (e.g. registrations added online) down to the desktop on reconnect

## Out of scope
- Mobile (iOS/Android) packaging
- Auto-update / over-the-air installer patching (can be added later via electron-updater)
- Multi-device conflict resolution beyond last-write-wins for non-critical fields
- Migrating existing hosted deployment — this is additive; the web app continues to work as-is

## Steps

1. **Create the Electron artifact** — Scaffold a new `artifacts/desktop` workspace package. Set up Electron with TypeScript, configure the main process entry point, and register it in the pnpm workspace. The main process will host both the local Express server and the native window.

2. **Bundle the local Express server inside Electron** — Wire the existing `artifacts/local-server` Express app to start inside the Electron main process on a fixed local port (e.g. 9090). The renderer window points at this local server. Reuse the existing Better-SQLite3 setup and Drizzle SQLite schema already in `artifacts/local-server`.

3. **Complete the SQLite schema to match cloud** — Audit the local-server SQLite schema against the full PostgreSQL schema in `lib/db/src/schema/index.ts`. Add any missing tables or columns so the local DB can hold a full copy of club data.

4. **Native serial/USB RFID integration** — Add a Node.js `serialport` listener in the Electron main process. When a tag read arrives, it writes directly to the local SQLite DB (same path as a normal timing POST) and queues it for cloud sync. Expose an IPC channel so the renderer can show connected reader status and configure the port.

5. **Real-time cloud sync engine** — Build the sync engine in the main process: on every local write, immediately POST the change to the cloud API (using the club's session credentials). If the POST fails or the device is offline, add the change to a persistent local queue. On reconnect, flush the queue in order. Pull cloud-to-local sync on app start and periodically (configurable interval, defaulting to every 30 seconds) for changes made from the web portal.

6. **Sync status UI** — Add a small sync indicator to the desktop app's title bar or header: green (live, synced), yellow (syncing / queue draining), red (offline, N changes pending). Expose queue depth and last-synced timestamp. Reuse or extend the existing sync status UI work from Task #69.

7. **Authentication flow for desktop** — On first launch, show a login screen that authenticates against the cloud API and stores the session token securely (Electron `safeStorage`). Subsequent launches auto-login from stored credentials. On logout, clear local credentials (but keep local data).

8. **Electron build pipeline** — Configure `electron-builder` to produce signed `.dmg` (Mac) and `.exe` NSIS installer (Windows). Bundle the React frontend as static assets served by the local Express server. Add a `pnpm --filter @workspace/desktop run dist` command. Document the build process in `replit.md`.

9. **Smoke-test the full flow** — Verify: app launches, organizer logs in, creates a moto, starts a race, RFID crossing arrives via serial, lap appears locally, cloud DB reflects the crossing within 1 second, disconnect network, add another crossing, reconnect, verify it syncs.

## Relevant files
- `artifacts/local-server/src/`
- `artifacts/local-server/src/auto-sync.ts`
- `artifacts/local-server/src/db.ts`
- `artifacts/api-server/src/app.ts`
- `artifacts/api-server/src/routes/timing.ts`
- `artifacts/api-server/src/routes/index.ts`
- `lib/db/src/schema/index.ts`
- `lib/db/drizzle.config.ts`
- `pnpm-workspace.yaml`
