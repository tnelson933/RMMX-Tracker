# Fix Expo Lockfile Compatibility

## What & Why
Align the Expo cloud build with the pnpm version used to generate the monorepo lockfile. The build currently receives the full 17-project workspace, but ignores the version-9 lockfile as incompatible and then fails because its frozen install has no usable lockfile.

## Done looks like
- The Rider App cloud build accepts the committed workspace lockfile without the incompatible-lockfile warning
- The frozen dependency install completes and the build proceeds beyond the install phase
- Local workspace installs remain deterministic and all existing workspace/catalog dependencies still resolve
- A retry is performed through Replit's Publish flow rather than a manual EAS CLI build

## Out of scope
- Rider App features, UI changes, or dependency upgrades unrelated to lockfile compatibility
- Changes to app bundle identifiers, store credentials, signing, or submission settings
- Converting the Rider App into a standalone package outside the existing monorepo

## Steps
1. **Pin the workspace package manager** — Declare the pnpm release compatible with the committed lockfile so the Expo builder does not fall back to an older preinstalled parser.
2. **Normalize the frozen-install inputs** — Refresh the workspace lockfile only as needed under the pinned toolchain, preserving the existing dependency versions, catalogs, workspace links, release-age policy, and all workspace importers.
3. **Verify install and Rider App checks** — Test a clean frozen workspace install, then run the Rider App type check and existing build validation to catch workspace-link or Metro regressions before publishing.
4. **Confirm the cloud build path** — Retry from Replit's Publish pane and verify the install stage recognizes the lockfile and advances to the native Expo build; retain any later-stage error separately if one appears.

## Relevant files
- `package.json`
- `pnpm-lock.yaml:1-12`
- `pnpm-lock.yaml:156-172`
- `pnpm-lock.yaml:806-859`
- `pnpm-workspace.yaml`
- `artifacts/rider-app/package.json`
- `artifacts/rider-app/.replit-artifact/artifact.toml`
