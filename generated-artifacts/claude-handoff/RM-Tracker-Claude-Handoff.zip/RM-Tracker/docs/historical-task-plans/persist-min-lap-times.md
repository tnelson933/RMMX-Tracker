# Persist minimum lap times reliably

## What & Why
On the Motos & Lineup page, organizers can enter a minimum lap time per race class. The inputs currently save on input blur, but navigation away before blurring silently discards the typed value. Additionally, navigating between events in the same SPA session can show stale local state instead of the newly loaded event's saved values. Organizers need confidence that whatever they type is saved and will be there when they return.

## Done looks like
- Typing a min lap time and immediately clicking any nav link still saves the value — verified by navigating away and back.
- Navigating from Event A's moto page to Event B's moto page shows Event B's saved values, not Event A's.
- The existing green check-mark feedback still appears after a successful save.
- No double-save race conditions (only one in-flight mutation at a time per class).

## Out of scope
- Changing the input format (m:ss stays as-is).
- Saving anything other than min lap times (lap count, lineup, etc. are unaffected).

## Steps
1. **Switch to debounced save-on-change** — replace the `onBlur`-only trigger with a `useEffect` that watches `minLapInputs` and debounces each class's save call by ~600 ms. Remove `handleMinLapBlur` or keep it only as an immediate flush on blur to complement the debounce.

2. **Reset local state when event changes** — add a `useEffect` that watches `eventId` and resets `minLapInputs` to `{}` whenever it changes, so the subsequent seed effect (which loads from `event.minLapTimes`) can repopulate cleanly without the stale-state guard blocking it.

3. **Fix the seed effect guard** — change the condition from `if (!(cls in prev))` to always write from saved data after a reset, ensuring the inputs reflect what's in the database on every fresh load.

## Relevant files
- `artifacts/race-platform/src/pages/organizer/Motos.tsx:722-785,1516-1555`
