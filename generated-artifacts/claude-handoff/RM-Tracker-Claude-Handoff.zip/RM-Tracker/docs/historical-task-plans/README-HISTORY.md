# Historical specifications, not an execution queue

Copied from the available local Markdown task plans. Some describe completed work; current platform statuses and full subsequent conversations are not available here. Inspect source and ask the owner before executing a plan.
