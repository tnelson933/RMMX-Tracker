# Pick Classes From Club Defaults When Creating an Event

## What & Why
Organizers already maintain a list of default classes in the Team admin page. But when creating (or editing) an event they have to re-type every class name from scratch. This task connects the two: show the club's default classes as one-click toggles, keep the manual-add escape hatch, and automatically save any brand-new class back to the club defaults so it's available next time.

## Done looks like
- Opening "Create Event" shows a **"Club Classes"** section above the manual entry area listing every default class as a pill/badge the organizer can click to toggle on or off.
- Classes that are toggled on appear in the standard class rows below (with the Max Riders field).
- The organizer can still click "Add Class" to type in a new class name that isn't in the defaults.
- When a manually typed class is added and the event is saved, that class name is silently appended to the club's `defaultClasses` settings (so it shows up as a pill next time).
- The same experience applies on the **Edit Event** panel in EventDetail — existing event classes are pre-selected as active pills; the organizer can toggle/add/remove.
- No change to how classes are submitted to the API — the end result is still an array of names + optional limits, identical to today.

## Out of scope
- Reordering default classes from within the event form (use the Team admin page for that).
- Adding a max-riders limit to a default class template (limits are still per-event only).
- Any changes to the public-facing event pages.

## Steps
1. **Fetch club defaults in the event creation form** — In `EventsList.tsx`, call `useGetClubSettings` (already used elsewhere) to load `defaultClasses` for the current organizer's club. Memoize the list so it doesn't re-fetch on every render.

2. **Render selectable class pills** — Above the existing class rows in the "Race Classes" section, render a row of pill/badge toggles — one per default class. Clicking a pill appends that class to the `raceClasses` field array (or removes it if it was already added). Show the pills in a visually distinct "Club Classes" sub-label so organizers understand these are pre-set options.

3. **Keep the manual Add Class button** — The existing `<Button>Add Class</Button>` that appends an empty row stays. This is the path for one-off classes not in the defaults.

4. **Auto-save new classes back to defaults** — Inside the `onSubmit` handler of the create form, compare the final class name list against the current `defaultClasses`. Any class names that don't appear in the defaults should be appended to the defaults list and saved via `usePutClubSettings` (fire-and-forget, no toast needed — this is a silent background save).

5. **Mirror the same changes in EventDetail** — Apply the same pill-based class picker and auto-save-back logic to the edit form in `EventDetail.tsx`. Pre-select pills that correspond to classes already on the event.

## Relevant files
- `artifacts/race-platform/src/pages/organizer/EventsList.tsx:878-945`
- `artifacts/race-platform/src/pages/organizer/EventDetail.tsx:719-780`
- `artifacts/race-platform/src/pages/organizer/TeamPage.tsx:130-217`
