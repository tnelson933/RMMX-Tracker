# RM Tracker — instructions for continuing development

Read `docs/claude-handoff/START_HERE.md`, then
`docs/claude-handoff/APP_CONTEXT.md` before making changes.
The remaining handoff documents cover setup, migration, verification, and unfinished work.

## Preserve the existing product

This is an existing race operations system, not a starter project.
It includes the organizer/public web app, cloud API, rider mobile app,
offline local server, Electron desktop app, and RM Connect timing bridge.
Do not replace these with a new scaffold, switch authentication providers,
change databases, or redesign unrelated screens without the owner's approval.

## Development rules

- Use pnpm 10.26.1. Preserve the workspace and package boundaries.
- Treat `lib/api-spec/openapi.yaml` as the generated client's contract.
  After contract changes, run `pnpm --filter @workspace/api-spec run codegen`.
  Do not fix generated files by hand.
- Cloud PostgreSQL and local SQLite must remain compatible at the API boundary.
  Review both servers when changing race-day operations or sync payloads.
- Preserve organizer club isolation, staff permissions, rider account/profile separation,
  payment ownership, signed-waiver records, and race history.
- Registration rows are class entries, not necessarily unique riders.
  Do not conflate entry counts, people, and distinct registration emails.
- Race event status and public result publication are separate concerns.
- The dashboard is an account overview. Check-in belongs to an individual event,
  not an account-wide summary card.
- Preserve timing serialization, SSE baseline handoff, active-transponder routing,
  timestamp normalization, and announcer monotonic sequencing. See the included
  `.agents/memory/` notes and `docs/claude-handoff/APP_CONTEXT.md`.
- Active timing customer-facing terminology is vendor-neutral.
- Update `artifacts/api-server/src/routes/anthropic/SYSTEM_PROMPT.md` when shipping
  organizer-facing capabilities that Rocky needs to understand.
- Keep secrets out of source, chat, exports, client build variables, and logs.
  The environment reference contains names only.
- Review data-changing scripts before running them. Do not run seeds, imports,
  `push-force`, synchronization, or production schema changes as setup shortcuts.
- Verify changes with appropriate typechecks, tests, builds, and API checks.
  A mocked browser test or successful bundle does not prove real-device or production behavior.
- Keep existing deployments, signing identities, Expo app identifiers, and provider
  accounts intact until an approved migration is tested. Do not trigger a release
  merely because these instructions mention one.

## Outside Replit

The export contains the source, not Replit's runtime, credentials, cloud database
contents, or storage bucket. Set up a same-origin `/api` reverse proxy for the
website; support WebSocket upgrades and unbuffered SSE. Adapt object storage
and AI credentials before calling those integrations portable.

Do not assume `replit.md` or historical plans are current. The code and current
owner instructions win. See the handoff's known discrepancies.
