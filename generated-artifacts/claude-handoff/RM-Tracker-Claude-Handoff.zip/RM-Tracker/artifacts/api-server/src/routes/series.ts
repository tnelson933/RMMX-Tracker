import { Router } from "express";
import { db } from "@workspace/db";
import { seriesTable, seriesPointsTable, raceResultsTable, ridersTable, eventsTable, motosTable, registrationsTable, pointsTablesTable, clubsTable, eventPublicationTable } from "@workspace/db";
import { eq, inArray, and } from "drizzle-orm";

const router = Router();

function getStaffClubId(res: any): number | null {
  const v = res.locals?.staffClubId;
  return typeof v === "number" ? v : null;
}

router.get("/series", async (req, res) => {
  const staffCId = getStaffClubId(res);
  const series = staffCId !== null
    ? await db.select().from(seriesTable).where(eq(seriesTable.clubId, staffCId)).orderBy(seriesTable.name)
    : await db.select().from(seriesTable).orderBy(seriesTable.name);
  return res.json(series.map(s => ({ ...s, createdAt: s.createdAt.toISOString() })));
});

router.post("/series", async (req, res) => {
  const staffCId = getStaffClubId(res);
  const { name, clubId: rawClubId, season, classes, pointsSystem, scoringTableId, eventIds } = req.body;
  const clubId = staffCId !== null ? staffCId : rawClubId;
  if (!name || !clubId || !season) return res.status(400).json({ error: "name, clubId, season required" });
  const [series] = await db.insert(seriesTable).values({
    name,
    clubId,
    season,
    classes: classes || [],
    pointsSystem: pointsSystem || "standard",
    scoringTableId: scoringTableId ?? null,
    eventIds: eventIds || [],
  }).returning();
  return res.status(201).json({ ...series, createdAt: series.createdAt.toISOString() });
});

router.patch("/series/:seriesId", async (req, res) => {
  const seriesId = Number(req.params.seriesId);

  const [existingSeries] = await db.select().from(seriesTable).where(eq(seriesTable.id, seriesId));
  if (!existingSeries) return res.status(404).json({ error: "Not found" });

  const staffCId = getStaffClubId(res);
  if (staffCId !== null && existingSeries.clubId !== staffCId) return res.status(403).json({ error: "Forbidden" });

  const { name, season, classes, scoringTableId, eventIds } = req.body;

  // Validate events match scoring format when eventIds is being updated
  if (eventIds !== undefined && eventIds.length > 0) {
    const tableId = scoringTableId !== undefined ? (scoringTableId ?? null) : existingSeries.scoringTableId;

    if (tableId) {
      const events = await db.select({ id: eventsTable.id, scoringTableId: eventsTable.scoringTableId })
        .from(eventsTable).where(inArray(eventsTable.id, eventIds));
      const mismatched = events.filter(e => e.scoringTableId !== tableId);
      if (mismatched.length > 0) {
        const mismatchedIds = mismatched.map(e => e.id).join(", ");
        return res.status(400).json({
          error: `Events ${mismatchedIds} use a different scoring format than this series. All events in a series must use the same scoring format.`,
        });
      }
    }
  }

  const updates: Record<string, unknown> = {};
  if (name !== undefined) updates.name = name;
  if (season !== undefined) updates.season = season;
  if (classes !== undefined) updates.classes = classes;
  if (scoringTableId !== undefined) updates.scoringTableId = scoringTableId ?? null;
  if (eventIds !== undefined) updates.eventIds = eventIds;

  const [updated] = await db.update(seriesTable).set(updates as any).where(eq(seriesTable.id, seriesId)).returning();
  if (!updated) return res.status(404).json({ error: "Not found" });
  return res.json({ ...updated, createdAt: updated.createdAt.toISOString() });
});

router.get("/series/:seriesId/leaderboard", async (req, res) => {
  const seriesId = Number(req.params.seriesId);
  const [series] = await db.select().from(seriesTable).where(eq(seriesTable.id, seriesId));
  if (!series) return res.status(404).json({ error: "Not found" });

  const staffCId = getStaffClubId(res);
  if (staffCId !== null && series.clubId !== staffCId) return res.status(403).json({ error: "Forbidden" });

  const eventIds = series.eventIds as number[];
  if (eventIds.length === 0) return res.json([]);

  const events = await db.select({ id: eventsTable.id, name: eventsTable.name })
    .from(eventsTable)
    .where(inArray(eventsTable.id, eventIds));
  const eventNameMap: Record<number, string> = {};
  events.forEach(e => { eventNameMap[e.id] = e.name; });

  const allMotos = await db.select()
    .from(motosTable)
    .where(and(inArray(motosTable.eventId, eventIds), eq(motosTable.status, "completed")));

  if (allMotos.length === 0) return res.json([]);

  const motoIds = allMotos.map(m => m.id);

  const allResults = await db.select({
    motoId: raceResultsTable.motoId,
    riderId: raceResultsTable.riderId,
    riderName: ridersTable.firstName,
    riderLastName: ridersTable.lastName,
    raceClass: raceResultsTable.raceClass,
    position: raceResultsTable.position,
    points: raceResultsTable.points,
    dnf: raceResultsTable.dnf,
    dns: raceResultsTable.dns,
  })
    .from(raceResultsTable)
    .leftJoin(ridersTable, eq(raceResultsTable.riderId, ridersTable.id))
    .where(inArray(raceResultsTable.motoId, motoIds));

  type MotoEntry = { moto: typeof allMotos[0]; results: typeof allResults };
  const classByEvent: Record<string, Record<number, MotoEntry[]>> = {};

  for (const moto of allMotos) {
    const cls = moto.raceClass ?? "";
    if (!classByEvent[cls]) classByEvent[cls] = {};
    if (!classByEvent[cls][moto.eventId]) classByEvent[cls][moto.eventId] = [];
    const motoResults = allResults.filter(r => r.motoId === moto.id);
    classByEvent[cls][moto.eventId].push({ moto, results: motoResults });
  }

  const standings: Array<{
    position: number;
    riderId: number;
    riderName: string;
    raceClass: string;
    totalScore: number;
    eventsEntered: number;
    events: Array<{ eventId: number; eventName: string; eventScore: number; attended: boolean; motos: number[] }>;
  }> = [];

  for (const [raceClass, eventMap] of Object.entries(classByEvent)) {
    const riderNames: Record<number, string> = {};
    for (const motoEntries of Object.values(eventMap)) {
      for (const { results } of motoEntries) {
        for (const r of results) {
          riderNames[r.riderId] = `${r.riderName ?? ""} ${r.riderLastName ?? ""}`.trim();
        }
      }
    }
    const allRiderIds = Object.keys(riderNames).map(Number);

    const classRows: typeof standings = [];

    for (const riderId of allRiderIds) {
      let totalScore = 0;
      let eventsEntered = 0;
      const eventBreakdowns: typeof standings[0]["events"] = [];

      for (const eventId of eventIds) {
        const motoEntries = eventMap[eventId];
        if (!motoEntries || motoEntries.length === 0) continue;

        const sortedMotos = [...motoEntries].sort((a, b) => (a.moto.motoNumber ?? 0) - (b.moto.motoNumber ?? 0));

        let eventScore = 0;
        const motoPositions: number[] = [];
        let attended = false;

        for (const { results } of sortedMotos) {
          const result = results.find(r => r.riderId === riderId);
          if (result) {
            attended = true;
            const pts = (result.dnf || result.dns) ? 0 : (result.points ?? 0);
            eventScore += pts;
            motoPositions.push(pts);
          } else {
            motoPositions.push(0);
          }
        }

        if (attended) eventsEntered++;
        totalScore += eventScore;
        eventBreakdowns.push({
          eventId,
          eventName: eventNameMap[eventId] ?? `Event ${eventId}`,
          eventScore,
          attended,
          motos: motoPositions,
        });
      }

      classRows.push({
        position: 0,
        riderId,
        riderName: riderNames[riderId],
        raceClass,
        totalScore,
        eventsEntered,
        events: eventBreakdowns,
      });
    }

    classRows.sort((a, b) => b.totalScore - a.totalScore);
    classRows.forEach((row, idx) => {
      if (idx > 0 && row.totalScore === classRows[idx - 1].totalScore) {
        row.position = classRows[idx - 1].position;
      } else {
        row.position = idx + 1;
      }
    });

    standings.push(...classRows);
  }

  return res.json(standings);
});

router.post("/series/:seriesId/recalculate", async (req, res) => {
  const seriesId = Number(req.params.seriesId);
  const staffCId = getStaffClubId(res);
  if (staffCId !== null) {
    const [series] = await db.select({ clubId: seriesTable.clubId }).from(seriesTable).where(eq(seriesTable.id, seriesId));
    if (!series || series.clubId !== staffCId) return res.status(403).json({ error: "Forbidden" });
  }
  return res.json({ ok: true });
});

// ── Public: states that have at least one series ──────────────────────────────
router.get("/public/series/states", async (_req, res) => {
  const rows = await db
    .selectDistinct({ state: clubsTable.state })
    .from(seriesTable)
    .innerJoin(clubsTable, eq(seriesTable.clubId, clubsTable.id))
    .orderBy(clubsTable.state);
  return res.json(rows.map(r => r.state));
});

// ── Public: all series across all clubs (optional ?state= filter) ─────────────
router.get("/public/series", async (req, res) => {
  const state = typeof req.query.state === "string" ? req.query.state : undefined;
  const query = db
    .select({
      id: seriesTable.id,
      name: seriesTable.name,
      season: seriesTable.season,
      clubId: seriesTable.clubId,
      clubName: clubsTable.name,
      state: clubsTable.state,
      classes: seriesTable.classes,
    })
    .from(seriesTable)
    .innerJoin(clubsTable, eq(seriesTable.clubId, clubsTable.id));
  const rows = state
    ? await query.where(eq(clubsTable.state, state)).orderBy(seriesTable.name)
    : await query.orderBy(seriesTable.name);
  return res.json(rows);
});

// ── Public: series info (for embeddable widget) ───────────────────────────────
router.get("/public/series/:seriesId", async (req, res) => {
  const seriesId = Number(req.params.seriesId);
  const [series] = await db.select().from(seriesTable).where(eq(seriesTable.id, seriesId));
  if (!series) return res.status(404).json({ error: "Not found" });

  const allEventIds = series.eventIds as number[];

  // Only expose events that have been published
  const publishedRows = allEventIds.length > 0
    ? await db.select({ eventId: eventPublicationTable.eventId })
        .from(eventPublicationTable)
        .where(and(
          inArray(eventPublicationTable.eventId, allEventIds),
          eq(eventPublicationTable.published, true),
        ))
    : [];
  const publishedIds = new Set(publishedRows.map(r => r.eventId));
  const eventIds = allEventIds.filter(id => publishedIds.has(id));

  const eventsData = eventIds.length > 0
    ? await db.select({
        id: eventsTable.id,
        name: eventsTable.name,
        date: eventsTable.date,
        status: eventsTable.status,
        location: eventsTable.location,
        state: eventsTable.state,
      }).from(eventsTable).where(inArray(eventsTable.id, eventIds))
    : [];

  const eventMap = new Map(eventsData.map(e => [e.id, e]));
  const sortedEvents = eventIds.map(id => eventMap.get(id)).filter(Boolean);

  return res.json({
    id: series.id,
    name: series.name,
    season: series.season,
    classes: series.classes,
    eventIds,
    events: sortedEvents,
  });
});

// ── Public: series standings with AMA# and bike brand ────────────────────────
router.get("/public/series/:seriesId/standings", async (req, res) => {
  const seriesId = Number(req.params.seriesId);
  const [series] = await db.select().from(seriesTable).where(eq(seriesTable.id, seriesId));
  if (!series) return res.status(404).json({ error: "Not found" });

  const allEventIds = series.eventIds as number[];
  if (allEventIds.length === 0) return res.json([]);

  // Only include events that have been published
  const publishedRows = await db.select({ eventId: eventPublicationTable.eventId })
    .from(eventPublicationTable)
    .where(and(
      inArray(eventPublicationTable.eventId, allEventIds),
      eq(eventPublicationTable.published, true),
    ));
  const publishedIds = new Set(publishedRows.map(r => r.eventId));
  const eventIds = allEventIds.filter(id => publishedIds.has(id));
  if (eventIds.length === 0) return res.json([]);

  const events = await db.select({ id: eventsTable.id, name: eventsTable.name })
    .from(eventsTable).where(inArray(eventsTable.id, eventIds));
  const eventNameMap: Record<number, string> = {};
  events.forEach(e => { eventNameMap[e.id] = e.name; });

  const allMotos = await db.select().from(motosTable)
    .where(and(inArray(motosTable.eventId, eventIds), eq(motosTable.status, "completed")));

  if (allMotos.length === 0) return res.json([]);

  const motoIds = allMotos.map(m => m.id);
  const allResults = await db.select({
    motoId: raceResultsTable.motoId,
    riderId: raceResultsTable.riderId,
    riderName: ridersTable.firstName,
    riderLastName: ridersTable.lastName,
    raceClass: raceResultsTable.raceClass,
    position: raceResultsTable.position,
    points: raceResultsTable.points,
    dnf: raceResultsTable.dnf,
    dns: raceResultsTable.dns,
  }).from(raceResultsTable)
    .leftJoin(ridersTable, eq(raceResultsTable.riderId, ridersTable.id))
    .where(inArray(raceResultsTable.motoId, motoIds));

  type MotoEntry = { moto: typeof allMotos[0]; results: typeof allResults };
  const classByEvent: Record<string, Record<number, MotoEntry[]>> = {};

  for (const moto of allMotos) {
    const cls = moto.raceClass ?? "";
    if (!classByEvent[cls]) classByEvent[cls] = {};
    if (!classByEvent[cls][moto.eventId]) classByEvent[cls][moto.eventId] = [];
    classByEvent[cls][moto.eventId].push({ moto, results: allResults.filter(r => r.motoId === moto.id) });
  }

  const standings: Array<{
    position: number; riderId: number; riderName: string; raceClass: string;
    totalScore: number; eventsEntered: number; amaNumber: string | null; bikeBrand: string | null;
    events: Array<{ eventId: number; eventName: string; eventScore: number; attended: boolean; motos: number[]; finishPositions: (number | null)[] }>;
  }> = [];

  for (const [raceClass, eventMap] of Object.entries(classByEvent)) {
    const riderNames: Record<number, string> = {};
    for (const motoEntries of Object.values(eventMap)) {
      for (const { results } of motoEntries) {
        for (const r of results) {
          riderNames[r.riderId] = `${r.riderName ?? ""} ${r.riderLastName ?? ""}`.trim();
        }
      }
    }
    const allRiderIds = Object.keys(riderNames).map(Number);
    const classRows: typeof standings = [];

    for (const riderId of allRiderIds) {
      let totalScore = 0; let eventsEntered = 0;
      const eventBreakdowns: typeof standings[0]["events"] = [];
      for (const eventId of eventIds) {
        const motoEntries = eventMap[eventId];
        if (!motoEntries?.length) continue;
        const sortedMotos = [...motoEntries].sort((a, b) => (a.moto.motoNumber ?? 0) - (b.moto.motoNumber ?? 0));
        let eventScore = 0; const motoPositions: number[] = []; const finishPositions: (number | null)[] = []; let attended = false;
        for (const { results } of sortedMotos) {
          const result = results.find(r => r.riderId === riderId);
          if (result) {
            attended = true;
            const pts = (result.dnf || result.dns) ? 0 : (result.points ?? 0);
            eventScore += pts;
            motoPositions.push(pts);
            finishPositions.push(result.dnf || result.dns ? null : (result.position ?? null));
          } else {
            motoPositions.push(0);
            finishPositions.push(null);
          }
        }
        if (attended) eventsEntered++;
        totalScore += eventScore;
        eventBreakdowns.push({ eventId, eventName: eventNameMap[eventId] ?? `Event ${eventId}`, eventScore, attended, motos: motoPositions, finishPositions });
      }
      classRows.push({ position: 0, riderId, riderName: riderNames[riderId], raceClass, totalScore, eventsEntered, amaNumber: null, bikeBrand: null, events: eventBreakdowns });
    }

    classRows.sort((a, b) => b.totalScore - a.totalScore);
    classRows.forEach((row, idx) => {
      row.position = (idx > 0 && row.totalScore === classRows[idx - 1].totalScore) ? classRows[idx - 1].position : idx + 1;
    });
    standings.push(...classRows);
  }

  const allRiderIds = [...new Set(standings.map(s => s.riderId))];
  if (allRiderIds.length > 0) {
    const regs = await db.select({
      riderId: registrationsTable.riderId,
      amaNumber: registrationsTable.amaNumber,
      bikeBrand: registrationsTable.bikeBrand,
    }).from(registrationsTable)
      .where(and(
        inArray(registrationsTable.riderId, allRiderIds),
        inArray(registrationsTable.eventId, eventIds),
      ));

    const riderInfo: Record<number, { amaNumber: string | null; bikeBrand: string | null }> = {};
    for (const reg of regs) {
      if (!riderInfo[reg.riderId]) riderInfo[reg.riderId] = { amaNumber: null, bikeBrand: null };
      if (!riderInfo[reg.riderId].amaNumber && reg.amaNumber) riderInfo[reg.riderId].amaNumber = reg.amaNumber;
      if (!riderInfo[reg.riderId].bikeBrand && reg.bikeBrand) riderInfo[reg.riderId].bikeBrand = reg.bikeBrand;
    }
    for (const row of standings) {
      row.amaNumber = riderInfo[row.riderId]?.amaNumber ?? null;
      row.bikeBrand = riderInfo[row.riderId]?.bikeBrand ?? null;
    }
  }

  return res.json(standings);
});

export default router;
