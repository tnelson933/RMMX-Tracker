import { useState, useEffect, useMemo } from "react";
import { StateSelect } from "@/components/ui/StateSelect";
import { useAuth } from "@/contexts/AuthContext";
import { useListEvents, useCreateEvent, useListClubs, useListSeries, useUpdateSeries, useListPointsTables, getListEventsQueryKey, useListDiscountCategories, useGetClubSettings, usePutClubSettings } from "@workspace/api-client-react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Calendar, MapPin, Plus, ChevronRight, Info, Flag, Trash2, Upload, ImageIcon, Loader2, Sparkles, X, RefreshCw, Check, ChevronsUpDown, Search, Pencil } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format, parseISO } from "date-fns";
import { Link, useLocation, useSearch } from "wouter";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@/lib/zodResolver";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";

const TIME_OPTIONS: string[] = [];
for (let h = 0; h < 24; h++) {
  for (let m = 0; m < 60; m += 15) {
    TIME_OPTIONS.push(`${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`);
  }
}

function formatHour(t: string) {
  const [h, m] = t.split(":").map(Number);
  const ampm = h < 12 ? "AM" : "PM";
  const hour = h % 12 === 0 ? 12 : h % 12;
  return `${hour}:${String(m).padStart(2, "0")} ${ampm}`;
}

function DateTimePicker({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const datePart = value ? value.split("T")[0] : "";
  const timePart = value ? (value.split("T")[1] ?? "").substring(0, 5) : "";
  const nearestTime = (() => {
    if (!timePart) return "";
    const [h, m] = timePart.split(":").map(Number);
    const rounded = Math.round((h * 60 + m) / 15) * 15;
    const rh = Math.floor(rounded / 60) % 24;
    const rm = rounded % 60;
    return `${String(rh).padStart(2, "0")}:${String(rm).padStart(2, "0")}`;
  })();

  const handleDate = (d: string) => {
    const t = nearestTime || "08:00";
    onChange(d ? `${d}T${t}` : "");
  };
  const handleTime = (t: string) => {
    onChange(datePart ? `${datePart}T${t}` : "");
  };

  return (
    <div className="flex gap-2">
      <input
        type="date"
        value={datePart}
        onChange={e => handleDate(e.target.value)}
        className="flex h-9 flex-1 rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
      />
      <select
        value={nearestTime || ""}
        onChange={e => handleTime(e.target.value)}
        disabled={!datePart}
        className="flex h-9 w-32 rounded-md border border-input bg-transparent px-2 py-1 text-sm shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:opacity-50"
      >
        <option value="">Time</option>
        {TIME_OPTIONS.map(t => (
          <option key={t} value={t}>{formatHour(t)}</option>
        ))}
      </select>
    </div>
  );
}

const createEventSchema = z.object({
  raceStyle: z.enum(["motocross", "enduro", "cross_country"]).default("motocross"),
  name: z.string().min(1, "Name is required"),
  date: z.string().min(1, "Date is required"),
  multiDay: z.boolean().default(false),
  endDate: z.string().optional(),
  state: z.string().min(1, "State is required"),
  location: z.string().optional(),
  trackName: z.string().optional(),
  timingTechnology: z.enum(["rfid", "active_transponder"]).default("rfid"),
  requireTransponder: z.boolean().default(false),
  raceClasses: z.array(z.object({
    name: z.string().min(1, "Class name is required"),
    maxRiders: z.coerce.number().int().min(1).optional().or(z.literal("")),
    seriesIds: z.array(z.number()).default([]),
    details: z.string().optional(),
  })),
  clubId: z.number({ invalid_type_error: "Club is required" }).min(1, "Club is required"),
  registrationOpen: z.string().optional(),
  registrationClose: z.string().optional(),
  paymentEnabled: z.boolean().default(false),
  requireAma: z.boolean().default(false),
  requireClubId: z.boolean().default(false),
  noDuplicateBibs: z.boolean().default(false),
  requireWaiver: z.boolean().default(false),
  requireLiabilityWaiver: z.boolean().default(false),
  quickCheckinEnabled: z.boolean().default(false),
  scoringTableId: z.number().optional(),
  entryFee: z.string().optional(),
  earlyBirdEnabled: z.boolean().default(false),
  earlyBirdFee: z.string().optional(),
  earlyBirdEndsAt: z.string().optional(),
  transponderRentalEnabled: z.boolean().default(false),
  transponderRentalFee: z.string().optional(),
  rfidStickerFee: z.string().optional(),
  purchaseOptions: z.array(z.object({
    name: z.string().min(1, "Name required"),
    amount: z.string().min(1, "Amount required"),
    categoryId: z.number().nullable().optional(),
  })).default([]),
  amaEventId: z.string().optional(),
}).refine(
  (data) => !data.multiDay || !data.endDate || data.endDate >= data.date,
  { message: "End date must be on or after start date", path: ["endDate"] },
);

export default function EventsList() {
  const { user } = useAuth();
  const isSuperAdmin = user?.role === "super_admin";
  const sessionClubId = user?.clubId ?? null;
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [filter, setFilter] = useState("upcoming");
  const [createSeriesIds, setCreateSeriesIds] = useState<number[]>([]);
  const [createContingencyBrands, setCreateContingencyBrands] = useState<string[]>([]);
  const [createNewBrandInput, setCreateNewBrandInput] = useState("");
  const [expandedCreateDetailRows, setExpandedCreateDetailRows] = useState<Set<number>>(new Set());
  const [pendingImageFile, setPendingImageFile] = useState<File | null>(null);
  const [imgValidationError, setImgValidationError] = useState<string | null>(null);
  const ALLOWED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/gif", "image/webp"];
  const MAX_IMAGE_BYTES = 10 * 1024 * 1024;
  const [createImgState, setCreateImgState] = useState<"idle" | "processing" | "uploading" | "done">("idle");
  const [removeBgOnCreate, setRemoveBgOnCreate] = useState(false);
  const [isSavingDraft, setIsSavingDraft] = useState(false);

  // Track library state
  const [trackLibrary, setTrackLibrary] = useState<{ id: number; name: string; address: string | null; city: string | null; state: string | null; zip: string | null }[]>([]);
  const [selectedLibraryTrackId, setSelectedLibraryTrackId] = useState<number | null>(null);
  const [manualTrackAddress, setManualTrackAddress] = useState("");
  const [manualTrackZip, setManualTrackZip] = useState("");

  // Super-admin sees all events; club_organizer and staff see only their own club's events
  const eventsQuery = isSuperAdmin
    ? useListEvents({}, { query: { refetchInterval: 30_000 } as any })
    : useListEvents({ clubId: sessionClubId ?? undefined }, { query: { enabled: !!sessionClubId, refetchInterval: 30_000 } as any });
  const { data: events, isLoading } = eventsQuery;

  // Clubs list for the super_admin club selector
  const { data: clubs } = useListClubs({ query: { enabled: isSuperAdmin } as any });

  const isDesktop = typeof (window as any).electronAPI !== "undefined";
  const [isSyncing, setIsSyncing] = useState(false);
  const [, setLocation] = useLocation();

  async function handleSyncFromCloud() {
    setIsSyncing(true);
    try {
      const api = (window as any).electronAPI;
      if (isDesktop && api?.sync?.flush) {
        // Desktop: trigger the real SyncEngine pull (cloud → local SQLite).
        // The broken /api/admin/sync/pull endpoint always returns 503 on desktop
        // because AUTO_SYNC_ENABLED=false (CLUB_ID is never passed to the local
        // server process — that would create two competing sync loops).
        const syncState = await api.sync.getState?.();
        if (syncState && !syncState.cloudUrl) {
          throw new Error("Cloud sync not configured. Open Cloud Sync Settings from the app menu.");
        }
        await api.sync.flush();
        // Invalidate everything — a full pull refreshes events, registrations, riders, motos, etc.
        queryClient.invalidateQueries();
        toast({ title: "Synced from cloud", description: "All data pulled from your cloud account." });
      } else {
        const res = await fetch("/api/admin/sync/pull", {
          method: "POST",
          credentials: "include",
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error ?? "Sync failed");
        queryClient.invalidateQueries({ queryKey: getListEventsQueryKey() });
        queryClient.invalidateQueries({ queryKey: ["stripe-connect-status"] });
        toast({ title: "Synced from cloud", description: "Events and data are up to date." });
      }
    } catch (err: any) {
      toast({ title: "Sync failed", description: err.message, variant: "destructive" });
    } finally {
      setIsSyncing(false);
    }
  }

  const search = useSearch();

  // Auto-open create dialog when navigated here with ?create=true.
  // Depends on `search` so it re-fires even when the component is already mounted
  // (e.g. clicking "New Event" from Dashboard while already on the Events page).
  useEffect(() => {
    if (new URLSearchParams(search).get("create") === "true") {
      setIsCreateOpen(true);
      window.history.replaceState({}, "", window.location.pathname);
    }
  }, [search]);

  // Check Stripe Connect status — works on both cloud and local server
  const { data: stripeStatus } = useQuery({
    queryKey: ["stripe-connect-status"],
    queryFn: async () => {
      const res = await fetch("/api/stripe/connect/status", { credentials: "include" });
      if (!res.ok) return { connected: false, onboardingComplete: false, accountId: null };
      return res.json() as Promise<{ connected: boolean; onboardingComplete: boolean; accountId: string | null }>;
    },
    enabled: !isSuperAdmin,
  });

  const stripeReady = !isSuperAdmin && (stripeStatus?.connected ?? false);

  const { data: seriesList } = useListSeries({ query: {} as any });
  const updateSeriesMutation = useUpdateSeries();
  const clubSeriesList = seriesList?.filter(s => s.clubId === (sessionClubId ?? 0)) ?? [];

  const createMutation = useCreateEvent();
  const { data: pointsTables } = useListPointsTables({ query: {} as any });
  const { data: discountCategories = [] } = useListDiscountCategories({ query: {} as any });

  const { data: clubSettingsData } = useGetClubSettings(sessionClubId ?? 0, { query: { enabled: !!sessionClubId && !isSuperAdmin } as any });
  const putClubSettings = usePutClubSettings();
  const defaultClasses = useMemo<{ id: string; name: string; details?: string | null }[]>(
    () => (clubSettingsData?.defaultClasses as { id: string; name: string; details?: string | null }[] | undefined) ?? [],
    [clubSettingsData]
  );
  const libraryContingencies = useMemo<string[]>(
    () => ((clubSettingsData as any)?.brandContingencies as string[] | undefined) ?? [],
    [clubSettingsData]
  );

  // Pre-fill trackName from club settings when dialog opens and settings load
  useEffect(() => {
    const savedTrackName = (clubSettingsData as any)?.trackName as string | null | undefined;
    if (savedTrackName && !form.getValues("trackName")) {
      form.setValue("trackName", savedTrackName);
    }
  }, [clubSettingsData, isCreateOpen]);

  // Load track library on mount
  useEffect(() => {
    fetch("/api/tracks", { credentials: "include" })
      .then(r => r.ok ? r.json() : [])
      .then(setTrackLibrary)
      .catch(() => {});
  }, []);

  // Reset track state when dialog closes
  useEffect(() => {
    if (!isCreateOpen) {
      setSelectedLibraryTrackId(null);
      setManualTrackAddress("");
      setManualTrackZip("");
    }
  }, [isCreateOpen]);

  const selectLibraryTrack = (t: typeof trackLibrary[0]) => {
    form.setValue("trackName", t.name);
    if (t.city) form.setValue("location", t.city);
    if (t.state) form.setValue("state", t.state);
    setSelectedLibraryTrackId(t.id);
    setManualTrackAddress(t.address ?? "");
    setManualTrackZip(t.zip ?? "");
  };


  const form = useForm<z.infer<typeof createEventSchema>>({
    resolver: zodResolver(createEventSchema),
    defaultValues: {
      raceStyle: "motocross" as const,
      name: "",
      date: format(new Date(), "yyyy-MM-dd"),
      multiDay: false,
      endDate: "",
      state: "",
      location: "",
      trackName: "",
      timingTechnology: "rfid",
      raceClasses: [],
      clubId: sessionClubId ?? undefined,
      registrationOpen: "",
      registrationClose: "",
      paymentEnabled: false,
      requireAma: false,
      requireClubId: false,
      noDuplicateBibs: false,
      requireWaiver: false,
      requireLiabilityWaiver: false,
      quickCheckinEnabled: false,
      scoringTableId: undefined,
      entryFee: "",
      earlyBirdEnabled: false,
      earlyBirdFee: "",
      earlyBirdEndsAt: "",
      transponderRentalEnabled: false,
      transponderRentalFee: "",
      rfidStickerFee: "",
      purchaseOptions: [],
      amaEventId: "",
    }
  });

  const watchMultiDay = form.watch("multiDay");

  const { fields, append, remove } = useFieldArray({ control: form.control, name: "raceClasses" });
  const { fields: purchaseOptionFields, append: appendPurchaseOption, remove: removePurchaseOption } = useFieldArray({ control: form.control, name: "purchaseOptions" });

  const watchPaymentEnabled = form.watch("paymentEnabled");
  const watchEarlyBirdEnabled = form.watch("earlyBirdEnabled");
  const watchTimingTechnology = form.watch("timingTechnology");
  const watchTransponderRentalEnabled = form.watch("transponderRentalEnabled");
  const watchRequireTransponder = form.watch("requireTransponder");
  const watchScoringTableId = form.watch("scoringTableId");
  const filteredSeriesList = clubSeriesList.filter(s =>
    !s.scoringTableId || !watchScoringTableId || s.scoringTableId === watchScoringTableId
  );

  const onSubmit = async (data: z.infer<typeof createEventSchema>) => {
    const classDetails: Record<string, string> = {};
    data.raceClasses.forEach(r => {
      const key = r.name.trim();
      if (key && r.details && r.details.trim()) classDetails[key] = r.details.trim();
    });

    let newEvent: Awaited<ReturnType<typeof createMutation.mutateAsync>>;
    try {
      newEvent = await createMutation.mutateAsync({
        data: {
          clubId: data.clubId,
          name: data.name,
          date: data.date,
          endDate: data.multiDay && data.endDate ? data.endDate : null,
          state: data.state,
          location: data.location,
          trackName: data.trackName || null,
          streetAddress: data.trackName?.trim() ? (manualTrackAddress.trim() || undefined) : undefined,
          zip: data.trackName?.trim() ? (manualTrackZip.trim() || undefined) : undefined,
          raceStyle: data.raceStyle,
          timingTechnology: data.timingTechnology,
          raceClasses: data.raceClasses.map(r => r.name.trim()).filter(Boolean),
          raceClassSeriesMap: Object.fromEntries(
            data.raceClasses
              .map(r => {
                const merged = Array.from(new Set([...(r.seriesIds ?? []), ...createSeriesIds]));
                return [r.name.trim(), merged] as [string, number[]];
              })
              .filter(([, ids]) => ids.length > 0)
          ),
          raceClassDetails: Object.keys(classDetails).length > 0 ? classDetails : undefined,
          registrationOpen: data.registrationOpen ? new Date(data.registrationOpen).toISOString() : undefined,
          registrationClose: data.registrationClose ? new Date(data.registrationClose).toISOString() : undefined,
          paymentEnabled: data.paymentEnabled,
          requireAma: data.requireAma,
          requireClubId: data.requireClubId,
          noDuplicateBibs: data.noDuplicateBibs,
          requireWaiver: data.requireWaiver,
          requireLiabilityWaiver: data.requireLiabilityWaiver,
          requireTransponder: data.timingTechnology === "active_transponder" ? data.requireTransponder : false,
          quickCheckinEnabled: data.quickCheckinEnabled,
          scoringTableId: data.scoringTableId ?? null,
          entryFee: data.paymentEnabled && data.entryFee ? Number(data.entryFee) : undefined,
          earlyBirdFee: data.paymentEnabled && data.earlyBirdEnabled && data.earlyBirdFee ? Number(data.earlyBirdFee) : undefined,
          earlyBirdEndsAt: data.paymentEnabled && data.earlyBirdEnabled && data.earlyBirdEndsAt ? data.earlyBirdEndsAt : undefined,
          transponderRentalEnabled: data.timingTechnology === "active_transponder" && data.paymentEnabled ? data.transponderRentalEnabled : false,
          transponderRentalFee: data.timingTechnology === "active_transponder" && data.paymentEnabled && data.transponderRentalEnabled && data.transponderRentalFee ? Number(data.transponderRentalFee) : undefined,
          rfidStickerFee: data.timingTechnology === "rfid" && data.paymentEnabled && data.rfidStickerFee ? Number(data.rfidStickerFee) : undefined,
          purchaseOptions: data.purchaseOptions.map(o => ({ id: crypto.randomUUID(), name: o.name.trim(), amount: Number(o.amount), categoryId: o.categoryId ?? null })),
          amaEventId: data.amaEventId || undefined,
          contingencyBrands: createContingencyBrands.length > 0 ? createContingencyBrands : undefined,
        },
      } as any);
    } catch (err: any) {
      toast({ title: "Failed to create event", description: err.message, variant: "destructive" });
      return;
    }

    // Silently sync class names and notes back to club defaults
    if (sessionClubId && !isSuperAdmin) {
      const existingDefaultNames = new Set(defaultClasses.map(c => c.name));
      const newClassNames = data.raceClasses.map(r => r.name.trim()).filter(n => n && !existingDefaultNames.has(n));
      const hasNoteUpdates = data.raceClasses.some(r => {
        const key = r.name.trim();
        const existing = defaultClasses.find(c => c.name === key);
        return existing && r.details && r.details.trim() && existing.details !== r.details.trim();
      });
      if (newClassNames.length > 0 || hasNoteUpdates) {
        const updated = defaultClasses.map(c => {
          const match = data.raceClasses.find(r => r.name.trim() === c.name);
          return match && match.details && match.details.trim() ? { ...c, details: match.details.trim() } : c;
        });
        newClassNames.forEach(n => {
          const match = data.raceClasses.find(r => r.name.trim() === n);
          updated.push({ id: crypto.randomUUID(), name: n, details: match?.details?.trim() || undefined });
        });
        putClubSettings.mutate({ clubId: sessionClubId, data: { defaultClasses: updated } });
      }
    }

    // Auto-save new track to library, or update address on an existing one
    if (data.trackName?.trim() && !selectedLibraryTrackId) {
      fetch("/api/tracks", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: data.trackName.trim(),
          address: manualTrackAddress.trim() || undefined,
          city: data.location?.trim() || undefined,
          state: data.state?.trim() || undefined,
          zip: manualTrackZip.trim() || undefined,
        }),
      }).then(r => r.ok ? r.json() : null).then(track => {
        if (track) setTrackLibrary(prev => [...prev, track].sort((a, b) => a.name.localeCompare(b.name)));
      }).catch(() => {});
    } else if (selectedLibraryTrackId) {
      fetch(`/api/tracks/${selectedLibraryTrackId}`, {
        method: "PATCH",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          address: manualTrackAddress.trim() || null,
          city: data.location?.trim() || null,
          state: data.state?.trim() || null,
          zip: manualTrackZip.trim() || null,
        }),
      }).then(r => r.ok ? r.json() : null).then(track => {
        if (track) setTrackLibrary(prev => prev.map(t => t.id === selectedLibraryTrackId ? track : t));
      }).catch(() => {});
    }

    // Link to series if selected
    for (const sid of createSeriesIds) {
      const targetSeries = seriesList?.find(s => s.id === sid);
      if (targetSeries) {
        const currentIds = (targetSeries.eventIds as number[]) ?? [];
        updateSeriesMutation.mutate({
          seriesId: targetSeries.id,
          data: { eventIds: [...currentIds, newEvent.id] },
        });
      }
    }

    // Upload image if one was selected
    if (pendingImageFile) {
      try {
        setCreateImgState("processing");
        let cleanBlob: Blob = pendingImageFile;
        if (removeBgOnCreate) {
          const { removeBackground } = await import("@imgly/background-removal");
          cleanBlob = await removeBackground(pendingImageFile);
        }
        setCreateImgState("uploading");
        // Direct binary upload — server saves to local disk and syncs to cloud storage
        const uploadRes = await fetch("/api/storage/uploads/file", {
          method: "POST",
          headers: {
            "Content-Type": "image/png",
            "x-file-name": `event-${newEvent.id}-image.png`,
            "x-content-type": "image/png",
          },
          credentials: "include",
          body: cleanBlob,
        });
        if (!uploadRes.ok) {
          const body = await uploadRes.json().catch(() => ({})) as { error?: string };
          throw new Error(body.error || "Upload failed");
        }
        const { objectPath } = await uploadRes.json() as { objectPath: string };
        await fetch(`/api/events/${newEvent.id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          credentials: "include",
          body: JSON.stringify({ imageUrl: `/api/storage${objectPath}` }),
        });
        setCreateImgState("done");
      } catch {
        toast({ title: "Event created, but image upload failed", variant: "destructive" });
      }
    }

    queryClient.invalidateQueries({ queryKey: getListEventsQueryKey() });
    setIsCreateOpen(false);
    setCreateSeriesIds([]);
    setCreateContingencyBrands([]);
    setCreateNewBrandInput("");
    setPendingImageFile(null);
    setCreateImgState("idle");
    setRemoveBgOnCreate(false);
    form.reset();
    toast({ title: "Event created successfully" });
    setLocation(`/events/${newEvent.id}`);
  };

  const onSaveAsDraft = async () => {
    const nameValid = await form.trigger("name");
    if (!nameValid) return;
    const { name: draftName, clubId: formClubId } = form.getValues();
    const effectiveClubId = isSuperAdmin ? formClubId : (sessionClubId ?? 0);
    if (!effectiveClubId) {
      toast({ title: "No club selected", variant: "destructive" });
      return;
    }
    setIsSavingDraft(true);
    try {
      const res = await fetch("/api/events", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ name: draftName, clubId: effectiveClubId, draft: true }),
      });
      if (!res.ok) throw new Error(((await res.json()) as any).error ?? "Failed to save draft");
      const newEvent = await res.json() as { id: number };
      queryClient.invalidateQueries({ queryKey: getListEventsQueryKey() });
      setIsCreateOpen(false);
      setCreateSeriesIds([]);
      setCreateContingencyBrands([]);
      setCreateNewBrandInput("");
      setPendingImageFile(null);
      setCreateImgState("idle");
      setRemoveBgOnCreate(false);
      form.reset();
      toast({ title: "Draft saved", description: `"${draftName}" saved as a draft. Finish it anytime.` });
      setLocation(`/events/${newEvent.id}`);
    } catch (err: any) {
      toast({ title: "Failed to save draft", description: err.message, variant: "destructive" });
    } finally {
      setIsSavingDraft(false);
    }
  };

  const todayStr = format(new Date(), "yyyy-MM-dd");

  // A race_day event whose effective end date has already passed is "past but
  // unpublished" — the race happened but the organizer hasn't finalized it yet.
  // We never change the DB status; this is a display-layer reclassification only.
  const isPastRaceDay = (e: { status: string; date: string; endDate?: string | null }) => {
    if (e.status !== "race_day") return false;
    const endStr = e.endDate ? String(e.endDate).substring(0, 10) : e.date.substring(0, 10);
    return endStr < todayStr;
  };

  const draftCount = (events ?? []).filter(e => e.status === "draft").length;

  const filteredEvents = (() => {
    const q = isSuperAdmin ? searchQuery.trim().toLowerCase() : "";
    let all = (events ?? []).filter(e => {
      if (!q) return true;
      return (
        e.name?.toLowerCase().includes(q) ||
        (e.location ?? "").toLowerCase().includes(q) ||
        (e.state ?? "").toLowerCase().includes(q) ||
        ((e as any).clubName ?? "").toLowerCase().includes(q)
      );
    });
    if (filter === "upcoming") {
      return [...all]
        .filter(e => e.status !== "completed" && !isPastRaceDay(e))
        .sort((a, b) => a.date.localeCompare(b.date))
        .slice(0, 10);
    }
    return all.filter(e => {
      if (filter === "all") return true;
      if (filter === "draft") return e.status === "draft";
      if (filter === "registration_open") return e.status === "registration_open";
      // Race Day tab: only events actively happening today, not stale past events
      if (filter === "race_day") return (e.status === "race_day" || e.date.substring(0, 10) === todayStr) && !isPastRaceDay(e);
      // Completed tab: actual completed events + past race_day events (shown as Unpublished)
      if (filter === "completed") return e.status === "completed" || isPastRaceDay(e);
      return true;
    });
  })();

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-4xl font-heading font-bold uppercase tracking-tight">Events</h1>
          <p className="text-muted-foreground mt-1">Manage your club's race events.</p>
        </div>
        
        <div className="flex items-center gap-2">
          {isDesktop && (
            <Button
              variant="outline"
              size="sm"
              onClick={handleSyncFromCloud}
              disabled={isSyncing}
              className="font-heading uppercase tracking-wider"
            >
              {isSyncing ? (
                <><Loader2 size={14} className="mr-1.5 animate-spin" /> Syncing...</>
              ) : (
                <><RefreshCw size={14} className="mr-1.5" /> Sync from Cloud</>
              )}
            </Button>
          )}
        <Dialog open={isCreateOpen} onOpenChange={(open) => { setIsCreateOpen(open); if (!open) { setCreateSeriesIds([]); setCreateContingencyBrands([]); } }}>
          <DialogTrigger asChild>
            <Button className="font-heading uppercase tracking-wider">
              <Plus size={16} className="mr-2" /> Create Event
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="font-heading uppercase text-xl">Create New Event</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">

                <FormField
                  control={form.control}
                  name="raceStyle"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Race Style</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select race style" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="motocross">Motocross / Supercross</SelectItem>
                          <SelectItem value="enduro">Enduro</SelectItem>
                          <SelectItem value="cross_country">Cross Country / Desert</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {isSuperAdmin && (
                  <FormField
                    control={form.control}
                    name="clubId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Club <span className="text-destructive">*</span></FormLabel>
                        <Select
                          onValueChange={(v) => field.onChange(Number(v))}
                          value={field.value ? String(field.value) : ""}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a club" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {clubs?.map(c => (
                              <SelectItem key={c.id} value={String(c.id)}>{c.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}

                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Event Name <span className="text-destructive">*</span></FormLabel>
                      <FormControl><Input placeholder="Spring Classic" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="date"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Race Date <span className="text-destructive">*</span></FormLabel>
                      <FormControl><Input type="date" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Multi-day toggle + end date */}
                <FormField
                  control={form.control}
                  name="multiDay"
                  render={({ field }) => (
                    <FormItem className="flex items-center gap-2 space-y-0">
                      <FormControl>
                        <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                      </FormControl>
                      <FormLabel className="cursor-pointer font-normal">Multi-day event</FormLabel>
                    </FormItem>
                  )}
                />
                {watchMultiDay && (
                  <FormField
                    control={form.control}
                    name="endDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>End Date</FormLabel>
                        <FormControl><Input type="date" {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}

                <FormField
                  control={form.control}
                  name="trackName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Track Name <span className="text-muted-foreground font-normal text-xs">(optional)</span></FormLabel>
                      {/* Library quick-selects */}
                      {trackLibrary.length > 0 && (
                        <div className="flex flex-wrap gap-1.5">
                          {trackLibrary.map(t => (
                            <button
                              key={t.id}
                              type="button"
                              onClick={() => selectLibraryTrack(t)}
                              className={`inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded-full border transition-all ${
                                selectedLibraryTrackId === t.id
                                  ? "border-primary bg-primary text-primary-foreground"
                                  : "border-input bg-muted/40 hover:border-primary/50 text-foreground"
                              }`}
                            >
                              {selectedLibraryTrackId === t.id ? <Check size={10} /> : <MapPin size={10} />}
                              {t.name}
                            </button>
                          ))}
                        </div>
                      )}
                      <FormControl>
                        <Input
                          placeholder="Thunder Valley MX"
                          {...field}
                          onChange={(e) => { field.onChange(e); setSelectedLibraryTrackId(null); setManualTrackAddress(""); setManualTrackZip(""); }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Street address — shown whenever a track name is entered */}
                {form.watch("trackName")?.trim() && (
                  <Input
                    placeholder="Street address"
                    value={manualTrackAddress}
                    onChange={e => setManualTrackAddress(e.target.value)}
                  />
                )}

                {/* City + State */}
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="location"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>City</FormLabel>
                        <FormControl><Input placeholder="Denver" {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="state"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>State <span className="text-destructive">*</span></FormLabel>
                        <FormControl>
                          <StateSelect value={field.value} onChange={field.onChange} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {/* ZIP — shown whenever a track name is entered */}
                {form.watch("trackName")?.trim() && (
                  <Input
                    placeholder="ZIP code"
                    value={manualTrackZip}
                    onChange={e => setManualTrackZip(e.target.value)}
                    className="w-36"
                  />
                )}

                {/* Timing Technology */}
                <FormField
                  control={form.control}
                  name="timingTechnology"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Timing Technology</FormLabel>
                      <FormControl>
                        <div className="grid grid-cols-2 gap-2">
                          {[
                            { value: "rfid", label: "RFID Stickers", desc: "Passive RFID tags" },
                            { value: "active_transponder", label: "Active Timing Reader", desc: "F2000 active transponders" },
                          ].map(opt => (
                            <button
                              key={opt.value}
                              type="button"
                              onClick={() => field.onChange(opt.value)}
                              className={`flex flex-col items-start px-4 py-3 rounded-md border text-left transition-all ${
                                field.value === opt.value
                                  ? "border-primary bg-primary/5 text-foreground"
                                  : "border-input bg-transparent text-muted-foreground hover:border-primary/50"
                              }`}
                            >
                              <span className={`text-sm font-semibold ${field.value === opt.value ? "text-primary" : ""}`}>{opt.label}</span>
                              <span className="text-xs mt-0.5">{opt.desc}</span>
                            </button>
                          ))}
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Require transponder — Active Timing Reader without Stripe */}
                {watchTimingTechnology === "active_transponder" && !watchPaymentEnabled && (
                  <FormField
                    control={form.control}
                    name="requireTransponder"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Require transponder number?</FormLabel>
                        <p className="text-xs text-muted-foreground -mt-1 mb-2">
                          Must riders provide their active transponder number to register?
                        </p>
                        <div className="grid grid-cols-2 gap-2">
                          {[
                            { value: true, label: "Yes – Required" },
                            { value: false, label: "No – Optional" },
                          ].map(opt => (
                            <button
                              key={String(opt.value)}
                              type="button"
                              onClick={() => field.onChange(opt.value)}
                              className={`flex flex-col items-start px-4 py-3 rounded-md border text-left transition-all ${
                                field.value === opt.value
                                  ? "border-primary bg-primary/5 text-foreground"
                                  : "border-input bg-transparent text-muted-foreground hover:border-primary/50"
                              }`}
                            >
                              <span className={`text-sm font-semibold ${field.value === opt.value ? "text-primary" : ""}`}>{opt.label}</span>
                            </button>
                          ))}
                        </div>
                        {field.value && (
                          <p className="text-xs font-medium text-amber-600 bg-amber-50 border border-amber-200 rounded-md px-3 py-2 mt-2">
                            Riders cannot register for event without transponder number.
                          </p>
                        )}
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}

                {/* Quick Check-In */}
                <FormField
                  control={form.control}
                  name="quickCheckinEnabled"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center gap-1.5">
                        <MapPin size={14} /> Quick Check-In
                      </FormLabel>
                      <p className="text-xs text-muted-foreground -mt-1 mb-2">
                        Let riders self-check-in from the rider app when they arrive within 1 mile of the track on race day.
                        Requires their RFID or active transponder to be assigned and any required waivers signed.
                      </p>
                      <div className="grid grid-cols-2 gap-2">
                        {[
                          { value: true, label: "Enabled", desc: "Riders nearby get a check-in prompt" },
                          { value: false, label: "Disabled", desc: "Staff checks in riders at the gate" },
                        ].map(opt => (
                          <button
                            key={String(opt.value)}
                            type="button"
                            onClick={() => field.onChange(opt.value)}
                            className={`flex flex-col items-start px-4 py-3 rounded-md border text-left transition-all ${
                              field.value === opt.value
                                ? "border-primary bg-primary/5 text-foreground"
                                : "border-input bg-transparent text-muted-foreground hover:border-primary/50"
                            }`}
                          >
                            <span className={`text-sm font-semibold ${field.value === opt.value ? "text-primary" : ""}`}>{opt.label}</span>
                            <span className="text-xs mt-0.5">{opt.desc}</span>
                          </button>
                        ))}
                      </div>
                      {field.value && (
                        <p className="text-xs text-blue-700 bg-blue-50 border border-blue-200 rounded-md px-3 py-2 mt-2">
                          The track location will be auto-geocoded when you save. Riders get a notification when they arrive within 1 mile on race day.
                        </p>
                      )}
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Registration window + Collect Payments */}
                <div className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <FormField
                      control={form.control}
                      name="registrationOpen"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Registration Opens</FormLabel>
                          <FormControl>
                            <DateTimePicker value={field.value ?? ""} onChange={field.onChange} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="registrationClose"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Registration Closes</FormLabel>
                          <FormControl>
                            <DateTimePicker value={field.value ?? ""} onChange={field.onChange} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  {/* Collect Payments checkbox */}
                  {!isSuperAdmin && (
                    <div className="flex items-center gap-2 pt-1">
                      {stripeReady ? (
                        <FormField
                          control={form.control}
                          name="paymentEnabled"
                          render={({ field }) => (
                            <FormItem className="flex items-center gap-2 space-y-0">
                              <FormControl>
                                <Checkbox
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <FormLabel className="cursor-pointer font-normal">Collect Payments</FormLabel>
                            </FormItem>
                          )}
                        />
                      ) : (
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <div className="flex items-center gap-2 cursor-default">
                              <Checkbox disabled checked={false} />
                              <span className="text-sm text-muted-foreground">Collect Payments</span>
                              <Info size={14} className="text-muted-foreground" />
                            </div>
                          </TooltipTrigger>
                          <TooltipContent side="right" className="max-w-64">
                            {isDesktop
                              ? "Connect Stripe in the cloud portal, then sync your data to enable payments here."
                              : <>Set up Stripe Connect under <strong>Payments</strong> in the sidebar to collect entry fees.</>}
                          </TooltipContent>
                        </Tooltip>
                      )}
                    </div>
                  )}

                  {/* Registration requirement checkboxes */}
                  <div className="space-y-2 pt-1">
                    <FormField
                      control={form.control}
                      name="requireAma"
                      render={({ field }) => (
                        <FormItem className="flex items-center gap-2 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <FormLabel className="cursor-pointer font-normal">Require AMA #</FormLabel>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="requireClubId"
                      render={({ field }) => (
                        <FormItem className="flex items-center gap-2 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <FormLabel className="cursor-pointer font-normal">Require Club ID #</FormLabel>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="noDuplicateBibs"
                      render={({ field }) => (
                        <FormItem className="flex items-center gap-2 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <FormLabel className="cursor-pointer font-normal">Do not allow duplicate race numbers</FormLabel>
                        </FormItem>
                      )}
                    />
                    {!isSuperAdmin && (() => {
                      const hasWaiverText = !!(clubSettingsData?.riderAcknowledgement?.trim());
                      return hasWaiverText ? (
                        <FormField
                          control={form.control}
                          name="requireWaiver"
                          render={({ field }) => (
                            <FormItem className="flex items-center gap-2 space-y-0">
                              <FormControl>
                                <Checkbox
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <FormLabel className="cursor-pointer font-normal">Require rider acknowledgement form</FormLabel>
                            </FormItem>
                          )}
                        />
                      ) : (
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <div className="flex items-center gap-2 cursor-default">
                              <Checkbox disabled checked={false} />
                              <span className="text-sm text-muted-foreground">Require rider acknowledgement form</span>
                              <Info size={14} className="text-muted-foreground" />
                            </div>
                          </TooltipTrigger>
                          <TooltipContent side="right" className="max-w-64">
                            Set rider acknowledgement form text in Admin settings first.
                          </TooltipContent>
                        </Tooltip>
                      );
                    })()}

                    {!isSuperAdmin && (() => {
                      const hasLiabilityWaiverText = !!((clubSettingsData as any)?.liabilityWaiverText?.trim());
                      return hasLiabilityWaiverText ? (
                        <FormField
                          control={form.control}
                          name="requireLiabilityWaiver"
                          render={({ field }) => (
                            <FormItem className="flex items-center gap-2 space-y-0">
                              <FormControl>
                                <Checkbox
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <FormLabel className="cursor-pointer font-normal">Require liability waiver e-signature</FormLabel>
                            </FormItem>
                          )}
                        />
                      ) : (
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <div className="flex items-center gap-2 cursor-default">
                              <Checkbox disabled checked={false} />
                              <span className="text-sm text-muted-foreground">Require liability waiver e-signature</span>
                              <Info size={14} className="text-muted-foreground" />
                            </div>
                          </TooltipTrigger>
                          <TooltipContent side="right" className="max-w-64">
                            Set liability waiver text in Admin settings first.
                          </TooltipContent>
                        </Tooltip>
                      );
                    })()}
                  </div>

                  {/* Scoring Format dropdown */}
                  <FormField
                    control={form.control}
                    name="scoringTableId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Scoring Format</FormLabel>
                        <Select
                          value={field.value != null ? String(field.value) : "none"}
                          onValueChange={(v) => field.onChange(v === "none" ? undefined : Number(v))}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select scoring format (optional)" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="none">None</SelectItem>
                            {(pointsTables ?? []).map(t => (
                              <SelectItem key={t.id} value={String(t.id)}>
                                {t.name}{t.isSystemDefault ? " ★" : ""}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <p className="text-xs text-muted-foreground">
                          Supercross formats generate Heats + Main Event. AMA/Olympic generate Motos.
                        </p>
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="amaEventId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>AMA Event ID</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g. 12345" {...field} />
                        </FormControl>
                        <p className="text-xs text-muted-foreground">Optional — used for AMA report export.</p>
                        <FormMessage />
                      </FormItem>
                    )}
                  />


                  {/* Entry fee input (only when payment enabled) */}
                  {stripeReady && watchPaymentEnabled && (
                    <FormField
                      control={form.control}
                      name="entryFee"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Entry Fee ($)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              min="0"
                              step="0.01"
                              placeholder="0.00"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}

                  {/* Early sign-up incentive period */}
                  {stripeReady && watchPaymentEnabled && (
                    <div className="space-y-3 pl-0.5">
                      <FormField
                        control={form.control}
                        name="earlyBirdEnabled"
                        render={({ field }) => (
                          <FormItem className="flex items-center gap-2 space-y-0">
                            <FormControl>
                              <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                            </FormControl>
                            <FormLabel className="cursor-pointer font-normal">Add early sign-up incentive period</FormLabel>
                          </FormItem>
                        )}
                      />
                      {watchEarlyBirdEnabled && (
                        <div className="ml-6 grid grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="earlyBirdFee"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Early Bird Fee ($)</FormLabel>
                                <FormControl>
                                  <Input type="number" min="0" step="0.01" placeholder="0.00" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="earlyBirdEndsAt"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Incentive Period Ends</FormLabel>
                                <FormControl>
                                  <Input type="date" {...field} />
                                </FormControl>
                                <p className="text-xs text-muted-foreground">Last day early fee applies (inclusive).</p>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      )}
                    </div>
                  )}

                  {/* RFID sticker fee (RFID + payment only) */}
                  {stripeReady && watchPaymentEnabled && watchTimingTechnology === "rfid" && (
                    <div className="space-y-2 pl-0.5">
                      <FormField
                        control={form.control}
                        name="rfidStickerFee"
                        render={({ field }) => (
                          <FormItem className="ml-0">
                            <FormLabel>RFID Sticker Fee ($) <span className="text-muted-foreground font-normal">(optional)</span></FormLabel>
                            <FormControl>
                              <Input type="number" min="0" step="0.01" placeholder="Leave blank if free" {...field} />
                            </FormControl>
                            <p className="text-xs text-muted-foreground">Charge riders for an RFID sticker at registration or at the gate.</p>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  )}

                  {/* Transponder rental (Active Timing Reader + payment only) */}
                  {stripeReady && watchPaymentEnabled && watchTimingTechnology === "active_transponder" && (
                    <div className="space-y-2 pl-0.5">
                      <FormField
                        control={form.control}
                        name="transponderRentalEnabled"
                        render={({ field }) => (
                          <FormItem className="flex items-center gap-2 space-y-0">
                            <FormControl>
                              <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                            </FormControl>
                            <FormLabel className="cursor-pointer font-normal">Offer transponder rentals to riders</FormLabel>
                          </FormItem>
                        )}
                      />
                      {watchTransponderRentalEnabled && (
                        <FormField
                          control={form.control}
                          name="transponderRentalFee"
                          render={({ field }) => (
                            <FormItem className="ml-6">
                              <FormLabel>Rental Fee per Transponder ($)</FormLabel>
                              <FormControl>
                                <Input type="number" min="0" step="0.01" placeholder="15.00" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      )}
                    </div>
                  )}

                  {/* Purchase Options */}
                  <div className="space-y-2 pt-1">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium text-foreground">Purchase Options</p>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => appendPurchaseOption({ name: "", amount: "" })}
                      >
                        <Plus size={13} className="mr-1" /> Add Purchase Option
                      </Button>
                    </div>
                    {purchaseOptionFields.length === 0 ? (
                      <p className="text-xs text-muted-foreground">
                        Add optional items riders can purchase at registration — gate fees, pit passes, etc.
                      </p>
                    ) : (
                      <div className="space-y-2">
                        {purchaseOptionFields.map((optField, idx) => (
                          <div key={optField.id} className="flex gap-2 items-start">
                            <FormField
                              control={form.control}
                              name={`purchaseOptions.${idx}.name`}
                              render={({ field }) => (
                                <FormItem className="flex-1">
                                  <FormControl>
                                    <Input placeholder="Gate fee, pit pass…" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={form.control}
                              name={`purchaseOptions.${idx}.amount`}
                              render={({ field }) => (
                                <FormItem className="w-28">
                                  <FormControl>
                                    <div className="relative">
                                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">$</span>
                                      <Input type="number" min="0" step="0.01" placeholder="0.00" className="pl-6" {...field} />
                                    </div>
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={form.control}
                              name={`purchaseOptions.${idx}.categoryId`}
                              render={({ field }) => (
                                <FormItem className="w-36">
                                  <Select
                                    value={field.value != null ? String(field.value) : "none"}
                                    onValueChange={(v) => field.onChange(v === "none" ? null : Number(v))}
                                  >
                                    <FormControl>
                                      <SelectTrigger>
                                        <SelectValue placeholder="Category" />
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      <SelectItem value="none">No category</SelectItem>
                                      {discountCategories.map((cat) => (
                                        <SelectItem key={cat.id} value={String(cat.id)}>{cat.name}</SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <Button
                              type="button"
                              variant="ghost"
                              size="icon"
                              className="mt-0.5 shrink-0 text-muted-foreground hover:text-destructive"
                              onClick={() => removePurchaseOption(idx)}
                            >
                              <X size={14} />
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Race Classes */}
                <div className="border-t pt-4">
                  <div className="flex items-center justify-between mb-3">
                    <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground flex items-center gap-1.5">
                      <Flag size={12} /> Race Classes
                    </p>
                  </div>
                  <div className="space-y-2">
                    {defaultClasses.length > 0 && (
                      <div className="mb-3">
                        <div className="flex items-center justify-between mb-2">
                          <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Club Classes</p>
                          {defaultClasses.some(cls => !fields.some(f => f.name === cls.name)) && (
                            <button
                              type="button"
                              onClick={() => {
                                const unselected = defaultClasses.filter(cls => !fields.some(f => f.name === cls.name));
                                unselected.forEach(cls => append({ name: cls.name, maxRiders: "", seriesIds: [], details: cls.details ?? "" }));
                              }}
                              className="text-xs text-primary hover:text-primary/80 font-semibold transition-colors"
                            >
                              Select All
                            </button>
                          )}
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {defaultClasses.map(cls => {
                            const isActive = fields.some(f => f.name === cls.name);
                            return (
                              <button
                                key={cls.id}
                                type="button"
                                onClick={() => {
                                  if (isActive) {
                                    const idx = fields.findIndex(f => f.name === cls.name);
                                    if (idx !== -1) { remove(idx); setExpandedCreateDetailRows(prev => { const next = new Set<number>(); prev.forEach(i => { if (i < idx) next.add(i); else if (i > idx) next.add(i - 1); }); return next; }); }
                                  } else {
                                    append({ name: cls.name, maxRiders: "", seriesIds: [], details: cls.details ?? "" });
                                  }
                                }}
                                className={
                                  isActive
                                    ? "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border cursor-pointer transition-colors bg-primary text-primary-foreground border-primary"
                                    : "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border cursor-pointer transition-colors bg-muted text-muted-foreground border-border hover:border-primary/50 hover:text-foreground"
                                }
                              >
                                {cls.name}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}
                    {fields.length > 0 && (
                      <div className="grid grid-cols-[1fr_1fr_140px_32px_32px] gap-2 mb-1">
                        <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground px-1">Class Name</span>
                        <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground px-1">Series</span>
                        <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground px-1">Max Riders</span>
                        <span />
                        <span />
                      </div>
                    )}
                    {fields.map((field, index) => (
                      <div key={field.id} className="space-y-1">
                      <div className="grid grid-cols-[1fr_1fr_140px_32px_32px] gap-2 items-start">
                        <FormField
                          control={form.control}
                          name={`raceClasses.${index}.name`}
                          render={({ field }) => (
                            <FormItem>
                              <FormControl>
                                <Input placeholder="e.g. 450 Pro" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name={`raceClasses.${index}.seriesIds`}
                          render={({ field: seriesField }) => {
                            const selected: number[] = seriesField.value ?? [];
                            const seriesOptions = clubSeriesList ?? [];
                            const label = selected.length === 0
                              ? "None"
                              : selected.length === 1
                                ? (seriesOptions.find(s => s.id === selected[0])?.name ?? "1 series")
                                : `${selected.length} series`;
                            return (
                              <FormItem>
                                <Popover>
                                  <PopoverTrigger asChild>
                                    <Button
                                      variant="outline"
                                      role="combobox"
                                      className="w-full justify-between h-9 font-normal"
                                      type="button"
                                    >
                                      <span className="truncate text-sm">{label}</span>
                                      <ChevronsUpDown size={14} className="ml-1 shrink-0 opacity-50" />
                                    </Button>
                                  </PopoverTrigger>
                                  <PopoverContent className="w-60 p-2" align="start">
                                    {seriesOptions.length === 0 ? (
                                      <p className="text-xs text-muted-foreground p-1">No series found for this club.</p>
                                    ) : (
                                      seriesOptions.map(s => {
                                        const checked = selected.includes(s.id);
                                        return (
                                          <div
                                            key={s.id}
                                            className="flex items-center gap-2 px-2 py-1.5 rounded hover:bg-muted cursor-pointer"
                                            onClick={() => {
                                              if (checked) {
                                                seriesField.onChange(selected.filter(id => id !== s.id));
                                              } else {
                                                seriesField.onChange([...selected, s.id]);
                                              }
                                            }}
                                          >
                                            <div className={`h-4 w-4 rounded border flex items-center justify-center shrink-0 ${checked ? "bg-primary border-primary" : "border-input"}`}>
                                              {checked && <Check size={10} className="text-primary-foreground" />}
                                            </div>
                                            <span className="text-sm">{s.name}</span>
                                          </div>
                                        );
                                      })
                                    )}
                                  </PopoverContent>
                                </Popover>
                                <FormMessage />
                              </FormItem>
                            );
                          }}
                        />
                        <FormField
                          control={form.control}
                          name={`raceClasses.${index}.maxRiders`}
                          render={({ field }) => (
                            <FormItem>
                              <FormControl>
                                <Input
                                  type="number"
                                  min="1"
                                  placeholder="Unlimited"
                                  {...field}
                                  value={field.value ?? ""}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          title={expandedCreateDetailRows.has(index) ? "Hide details" : "Add class rules / details"}
                          className={`h-9 w-8 mt-0 ${expandedCreateDetailRows.has(index) ? "text-primary bg-primary/10" : "text-muted-foreground hover:text-primary hover:bg-primary/10"}`}
                          onClick={() => setExpandedCreateDetailRows(prev => {
                            const next = new Set(prev);
                            if (next.has(index)) next.delete(index); else next.add(index);
                            return next;
                          })}
                        >
                          <Info size={14} />
                        </Button>
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="h-9 w-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10 mt-0"
                          onClick={() => {
                            remove(index);
                            setExpandedCreateDetailRows(prev => {
                              const next = new Set<number>();
                              prev.forEach(i => { if (i < index) next.add(i); else if (i > index) next.add(i - 1); });
                              return next;
                            });
                          }}
                        >
                          <Trash2 size={14} />
                        </Button>
                        </div>
                        {expandedCreateDetailRows.has(index) && (
                          <FormField
                            control={form.control}
                            name={`raceClasses.${index}.details`}
                            render={({ field }) => (
                              <FormItem>
                                <FormControl>
                                  <textarea
                                    {...field}
                                    rows={3}
                                    placeholder="Class rules, eligibility requirements, bike specs, or any other details riders should know…"
                                    className="w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring resize-none"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        )}
                      </div>
                    ))}
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="w-full gap-2 border-dashed font-heading uppercase tracking-wider text-muted-foreground hover:text-foreground mt-1"
                      onClick={() => append({ name: "", maxRiders: "", seriesIds: [], details: "" })}
                    >
                      <Plus size={14} /> Add Class
                    </Button>
                  </div>
                </div>

                {/* Brand Contingencies */}
                {!isSuperAdmin && (() => {
                  const allKnown = [...new Set([...libraryContingencies, ...createContingencyBrands])];
                  const handleAddBrand = () => {
                    const trimmed = createNewBrandInput.trim();
                    if (!trimmed || allKnown.includes(trimmed)) { setCreateNewBrandInput(""); return; }
                    const updatedLibrary = [...libraryContingencies, trimmed];
                    setCreateContingencyBrands(prev => [...prev, trimmed]);
                    setCreateNewBrandInput("");
                    if (sessionClubId) {
                      putClubSettings.mutate({ clubId: sessionClubId, data: { brandContingencies: updatedLibrary } as any });
                    }
                  };
                  return (
                    <div className="space-y-2">
                      <div className="flex items-center gap-1.5">
                        <Flag size={13} className="text-muted-foreground" />
                        <label className="text-sm font-medium">Brand Contingencies</label>
                      </div>
                      <div className="border rounded-lg p-3 space-y-2.5 bg-muted/20">
                        {allKnown.length === 0 && (
                          <p className="text-xs text-muted-foreground">No contingency brands yet — add one below.</p>
                        )}
                        {allKnown.length > 0 && (
                          <div className="flex flex-wrap gap-1.5">
                            {allKnown.map(brand => {
                              const selected = createContingencyBrands.includes(brand);
                              return (
                                <button
                                  key={brand}
                                  type="button"
                                  onClick={() => setCreateContingencyBrands(selected
                                    ? createContingencyBrands.filter(b => b !== brand)
                                    : [...createContingencyBrands, brand]
                                  )}
                                  className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium border transition-colors ${
                                    selected
                                      ? "bg-primary text-primary-foreground border-primary"
                                      : "bg-background text-foreground border-input hover:bg-muted"
                                  }`}
                                >
                                  {selected && <Check size={9} />}
                                  {brand}
                                </button>
                              );
                            })}
                          </div>
                        )}
                        <div className="flex gap-2">
                          <Input
                            placeholder="Add new brand…"
                            value={createNewBrandInput}
                            onChange={e => setCreateNewBrandInput(e.target.value)}
                            onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); handleAddBrand(); } }}
                            className="h-8 text-sm"
                          />
                          <Button type="button" variant="outline" size="sm" className="h-8 px-3 shrink-0" onClick={handleAddBrand}>
                            <Plus size={14} />
                          </Button>
                        </div>
                      </div>
                    </div>
                  );
                })()}

                {filteredSeriesList.length > 0 && (
                  <div className="space-y-1.5">
                    <label className="text-sm font-medium">Apply Series to All Classes</label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          role="combobox"
                          className="w-full justify-between font-normal"
                          type="button"
                        >
                          <span className="truncate text-sm">
                            {createSeriesIds.length === 0
                              ? "None"
                              : createSeriesIds.length === 1
                                ? (filteredSeriesList.find(s => s.id === createSeriesIds[0])?.name ?? "1 series")
                                : `${createSeriesIds.length} series`}
                          </span>
                          <ChevronsUpDown size={14} className="ml-1 shrink-0 opacity-50" />
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-72 p-2" align="start">
                        {filteredSeriesList.map(s => {
                          const checked = createSeriesIds.includes(s.id);
                          return (
                            <div
                              key={s.id}
                              className="flex items-center gap-2 px-2 py-1.5 rounded hover:bg-muted cursor-pointer"
                              onClick={() => setCreateSeriesIds(checked
                                ? createSeriesIds.filter(id => id !== s.id)
                                : [...createSeriesIds, s.id]
                              )}
                            >
                              <div className={`h-4 w-4 rounded border flex items-center justify-center shrink-0 ${checked ? "bg-primary border-primary" : "border-input"}`}>
                                {checked && <Check size={10} className="text-primary-foreground" />}
                              </div>
                              <span className="text-sm">{s.name} <span className="text-muted-foreground">({s.season})</span></span>
                            </div>
                          );
                        })}
                      </PopoverContent>
                    </Popover>
                    <p className="text-xs text-muted-foreground">Selected series are applied to every class above. Use the per-class dropdown for individual overrides.</p>
                    {clubSeriesList.length > filteredSeriesList.length && (
                      <p className="text-xs text-muted-foreground">Only series with a matching scoring format are shown.</p>
                    )}
                  </div>
                )}

                {/* Event Image */}
                <div className="space-y-1.5 pt-2">
                  <label className="text-sm font-medium flex items-center gap-1.5">
                    <ImageIcon size={14} className="text-primary" /> Event Image <span className="text-muted-foreground font-normal">(optional)</span>
                  </label>
                  <input
                    id="create-event-img"
                    type="file"
                    accept="image/jpeg,image/png,image/gif,image/webp"
                    className="hidden"
                    onChange={e => {
                      const f = e.target.files?.[0];
                      if (!f) return;
                      e.target.value = "";
                      if (!ALLOWED_IMAGE_TYPES.includes(f.type)) {
                        setImgValidationError("Unsupported file type. Please upload a JPEG, PNG, GIF, or WebP image.");
                        return;
                      }
                      if (f.size > MAX_IMAGE_BYTES) {
                        setImgValidationError("Image is too large. Maximum size is 10 MB — try compressing it first.");
                        return;
                      }
                      setImgValidationError(null);
                      setPendingImageFile(f);
                    }}
                  />
                  {pendingImageFile ? (
                    <div className="flex flex-wrap items-center gap-3 p-3 rounded-md border bg-muted/40">
                      <ImageIcon size={16} className="text-primary shrink-0" />
                      <span className="text-sm flex-1 truncate min-w-0">{pendingImageFile.name}</span>
                      <label className="flex items-center gap-1.5 cursor-pointer select-none text-xs text-muted-foreground shrink-0">
                        <Checkbox checked={removeBgOnCreate} onCheckedChange={v => setRemoveBgOnCreate(!!v)} />
                        Remove background
                      </label>
                      <button type="button" onClick={() => { setPendingImageFile(null); setImgValidationError(null); }} className="text-muted-foreground hover:text-destructive shrink-0">
                        <X size={14} />
                      </button>
                    </div>
                  ) : (
                    <label htmlFor="create-event-img" className="flex items-center justify-center gap-2 p-3 rounded-md border border-dashed text-sm text-muted-foreground hover:text-foreground hover:border-primary cursor-pointer transition-colors">
                      <Upload size={14} /> Choose image
                    </label>
                  )}
                  {imgValidationError && (
                    <p className="text-sm text-destructive font-medium flex items-center gap-1.5 mt-1">
                      {imgValidationError}
                    </p>
                  )}
                  {!imgValidationError && (
                    <p className="text-xs text-muted-foreground mt-1">JPEG, PNG, GIF, or WebP · Max 10 MB</p>
                  )}
                </div>

                <div className="sticky bottom-0 bg-background border-t pt-4 pb-1 -mx-6 px-6 mt-2 flex justify-between items-center">
                  <Button
                    type="button"
                    variant="outline"
                    disabled={isSavingDraft}
                    onClick={onSaveAsDraft}
                    className="font-heading uppercase tracking-wider text-muted-foreground"
                  >
                    {isSavingDraft ? <><Loader2 size={14} className="mr-2 animate-spin" /> Saving…</> : <><Pencil size={14} className="mr-2" /> Save as Draft</>}
                  </Button>
                  <Button type="submit" disabled={createMutation.isPending || createImgState === "processing" || createImgState === "uploading"} className="font-heading uppercase tracking-wider">
                    {createMutation.isPending ? "Creating..." : createImgState === "processing" ? <><Loader2 size={14} className="mr-2 animate-spin" /> Removing background…</> : createImgState === "uploading" ? <><Loader2 size={14} className="mr-2 animate-spin" /> Uploading image…</> : "Create Event"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
        </div>
      </div>

      <Tabs value={filter} onValueChange={setFilter} className="w-full">
        <TabsList className="bg-muted">
          <TabsTrigger value="upcoming" className="font-heading uppercase">Upcoming</TabsTrigger>
          <TabsTrigger value="all" className="font-heading uppercase">All</TabsTrigger>
          <TabsTrigger value="draft" className="font-heading uppercase">
            Draft{draftCount > 0 && <span className="ml-1.5 inline-flex items-center justify-center bg-amber-500/20 text-amber-700 dark:text-amber-400 text-[10px] font-bold px-1.5 py-0.5 rounded-full leading-none">{draftCount}</span>}
          </TabsTrigger>
          <TabsTrigger value="registration_open" className="font-heading uppercase">Reg Open</TabsTrigger>
          <TabsTrigger value="race_day" className="font-heading uppercase">Race Day</TabsTrigger>
          <TabsTrigger value="completed" className="font-heading uppercase">Completed</TabsTrigger>
        </TabsList>
        
        {isSuperAdmin && (
          <div className="relative mt-4">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
            <Input
              placeholder="Search by event name, location, or track…"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="pl-9 pr-8"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery("")}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                <X size={14} />
              </button>
            )}
          </div>
        )}

        <TabsContent value={filter} className="mt-6 space-y-4">
          {isLoading ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => <Card key={i} className="h-24 animate-pulse"></Card>)}
            </div>
          ) : filteredEvents.length > 0 ? (
            filteredEvents.map(event => (
              <Link key={event.id} href={`/events/${event.id}`}>
                <Card className="hover-elevate cursor-pointer hover:border-primary transition-all">
                  <CardContent className="p-0 flex items-center">
                    <div className="bg-sidebar p-4 flex flex-col justify-center items-center text-sidebar-foreground w-24 shrink-0 rounded-l-md border-r">
                      <span className="text-xs font-bold uppercase tracking-widest mb-1">{format(parseISO(event.date.substring(0, 10)), 'MMM')}</span>
                      {(event as any).endDate && String((event as any).endDate).substring(0, 10) !== event.date.substring(0, 10) ? (
                        <span className="text-2xl font-heading font-bold leading-none">
                          {format(parseISO(event.date.substring(0, 10)), 'd')}–{format(parseISO(String((event as any).endDate).substring(0, 10)), 'd')}
                        </span>
                      ) : (
                        <span className="text-3xl font-heading font-bold leading-none">{format(parseISO(event.date.substring(0, 10)), 'dd')}</span>
                      )}
                    </div>
                    <div className="p-4 flex-1 flex items-center justify-between">
                      <div>
                        <h3 className="text-xl font-heading font-bold uppercase">{event.name}</h3>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
                          <span className="flex items-center gap-1"><MapPin size={14} /> {event.location || "TBA"}, {event.state}</span>
                          {isSuperAdmin && event.clubName && (
                            <span className="text-xs bg-muted px-2 py-0.5 rounded">{event.clubName}</span>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {(event as any).timingTechnology && (
                          <span className="bg-muted text-muted-foreground border border-border px-2 py-1 rounded text-xs font-bold uppercase tracking-wider">
                            {(event as any).timingTechnology === "active_transponder" ? "Active Timing Reader" : "RFID"}
                          </span>
                        )}
                        {(() => {
                          if (isPastRaceDay(event)) {
                            return (
                              <span className="px-2 py-1 rounded text-xs font-bold uppercase tracking-wider bg-amber-500/15 text-amber-600 border border-amber-500/30">
                                Unpublished
                              </span>
                            );
                          }
                          const isToday = event.date.substring(0, 10) === todayStr;
                          const showRaceDay = isToday && event.status !== "completed" && event.status !== "draft";
                          if (event.status === "draft") {
                            return (
                              <span className="flex items-center gap-1 px-2 py-1 rounded text-xs font-bold uppercase tracking-wider bg-amber-500/15 text-amber-700 dark:text-amber-400 border border-amber-500/30">
                                <Pencil size={11} /> Draft
                              </span>
                            );
                          }
                          return (
                            <span className={`px-2 py-1 rounded text-xs font-bold uppercase tracking-wider ${
                              showRaceDay
                                ? "bg-red-600 text-white border border-red-500"
                                : "bg-primary/10 text-primary border border-primary/20"
                            }`}>
                              {showRaceDay ? "Race Day" : event.status.replace(/_/g, ' ')}
                            </span>
                          );
                        })()}
                        <ChevronRight className="text-muted-foreground ml-4" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))
          ) : (
            <div className="text-center p-12 bg-muted/50 rounded-lg">
              <p className="text-muted-foreground font-medium">No events found matching this status.</p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
