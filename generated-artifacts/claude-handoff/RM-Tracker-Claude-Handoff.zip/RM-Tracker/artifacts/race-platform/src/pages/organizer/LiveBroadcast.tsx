import { useState, useRef, useEffect } from "react";
import { Video, VideoOff, Mic, MicOff, Radio, AlertCircle, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useBroadcast } from "@/contexts/BroadcastContext";
import { usePublicOrigin } from "@/lib/publicOrigin";

interface LiveBroadcastProps {
  eventId: number;
}

export function LiveBroadcast({ eventId }: LiveBroadcastProps) {
  const {
    broadcastState,
    errorMsg,
    micEnabled,
    camEnabled,
    duration,
    startBroadcast,
    stopBroadcast,
    toggleMic,
    toggleCam,
    getLiveStream,
  } = useBroadcast();

  // Device enumeration — local to this UI
  const [videoDevices, setVideoDevices] = useState<MediaDeviceInfo[]>([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState<string>("");
  const [permissionState, setPermissionState] = useState<"requesting" | "granted" | "denied">("requesting");
  // Reactive public origin is used to detect whether cloud sync is configured
  // when this screen is running inside the desktop app.
  const publicOrigin = usePublicOrigin();

  // Detect whether we're running in the desktop app without cloud sync configured.
  // In that case the WebSocket relay is unavailable — warn the organizer instead of
  // letting them hit a cryptic "connection lost" error.
  const isLocalHost = typeof window !== "undefined" &&
    (window.location.hostname === "localhost" || window.location.hostname === "127.0.0.1");
  const cloudUnconfigured = isLocalHost &&
    (publicOrigin === window.location.origin || publicOrigin.startsWith("http://localhost") || publicOrigin.startsWith("http://127.0.0.1"));

  const previewRef = useRef<HTMLVideoElement>(null);
  const previewStreamRef = useRef<MediaStream | null>(null);

  const isLive = broadcastState === "live";
  const isReconnecting = broadcastState === "reconnecting";
  // Treat reconnecting like live for layout/controls — the recorder is still
  // running and we don't want the organizer to interact with camera/device selects.
  const isActiveStream = isLive || isReconnecting;

  // On mount: request permission + enumerate devices + start preview
  useEffect(() => {
    let cancelled = false;

    async function init() {
      try {
        const initial = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
        if (cancelled) { initial.getTracks().forEach(t => t.stop()); return; }

        const all = await navigator.mediaDevices.enumerateDevices();
        if (cancelled) { initial.getTracks().forEach(t => t.stop()); return; }

        const videos = all.filter(d => d.kind === "videoinput");
        setVideoDevices(videos);
        setPermissionState("granted");

        const initialTrack = initial.getVideoTracks()[0];
        const defaultId = initialTrack?.getSettings().deviceId ?? videos[0]?.deviceId ?? "";
        setSelectedDeviceId(defaultId);
        initial.getTracks().forEach(t => t.stop());

        await startPreview(defaultId);
      } catch (err: any) {
        if (cancelled) return;
        const msg = err?.name === "NotAllowedError"
          ? "Camera access was denied. Please allow camera access in your browser settings and reload."
          : "Could not access camera. Make sure a camera is connected.";
        setPermissionState("denied");
        void msg;
      }
    }

    init();
    return () => { cancelled = true; stopPreview(); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // If already live when this page mounts, attach live stream to preview
  useEffect(() => {
    if (isActiveStream && previewRef.current) {
      const stream = getLiveStream();
      if (stream) {
        previewRef.current.srcObject = stream;
        previewRef.current.muted = true;
        previewRef.current.play().catch(() => {});
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isActiveStream]);

  // Restart preview when camera selection changes (only when not live)
  useEffect(() => {
    if (permissionState !== "granted" || !selectedDeviceId || isActiveStream) return;
    startPreview(selectedDeviceId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedDeviceId]);

  async function startPreview(deviceId: string) {
    stopPreview();
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { deviceId: { exact: deviceId }, width: { ideal: 1280, max: 1920 } },
        audio: false,
      });
      previewStreamRef.current = stream;
      if (previewRef.current) {
        previewRef.current.srcObject = stream;
        previewRef.current.muted = true;
        previewRef.current.play().catch(() => {});
      }
    } catch {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
        previewStreamRef.current = stream;
        if (previewRef.current) {
          previewRef.current.srcObject = stream;
          previewRef.current.muted = true;
          previewRef.current.play().catch(() => {});
        }
      } catch { /* camera unavailable */ }
    }
  }

  function stopPreview() {
    previewStreamRef.current?.getTracks().forEach(t => t.stop());
    previewStreamRef.current = null;
    if (previewRef.current) previewRef.current.srcObject = null;
  }

  const handleGoLive = async () => {
    stopPreview();
    await startBroadcast(eventId, selectedDeviceId);
    const liveStream = getLiveStream();
    if (liveStream && previewRef.current) {
      previewRef.current.srcObject = liveStream;
      previewRef.current.muted = true;
      previewRef.current.play().catch(() => {});
    }
  };

  const handleStop = () => {
    stopBroadcast();
    // Restart local preview after a short delay
    setTimeout(() => {
      if (selectedDeviceId) startPreview(selectedDeviceId);
    }, 300);
  };

  const formatDuration = (s: number) => {
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
    return `${m}:${String(sec).padStart(2, "0")}`;
  };

  return (
    <div className="space-y-4">
      {/* Camera preview */}
      <div className="relative bg-black rounded-xl overflow-hidden aspect-video w-full max-w-xl">
        <video
          ref={previewRef}
          className="w-full h-full object-cover"
          playsInline
          muted
        />

        {permissionState === "requesting" && (
          <div className="absolute inset-0 flex flex-col items-center justify-center text-white/60 gap-2 bg-black/80">
            <Video size={32} className="animate-pulse" />
            <span className="text-sm font-heading uppercase tracking-wider">Requesting camera access…</span>
          </div>
        )}
        {permissionState === "denied" && (
          <div className="absolute inset-0 flex flex-col items-center justify-center text-white/60 gap-2 bg-black/90 px-6 text-center">
            <VideoOff size={32} />
            <span className="text-sm font-heading uppercase tracking-wider">Camera access denied</span>
          </div>
        )}
        {!camEnabled && isActiveStream && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/70">
            <VideoOff size={32} className="text-white/40" />
          </div>
        )}

        {isReconnecting && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/50">
            <div className="flex flex-col items-center gap-2 text-white">
              <Loader2 size={28} className="animate-spin" />
              <span className="text-xs font-heading uppercase tracking-wider">Reconnecting…</span>
            </div>
          </div>
        )}

        {isLive && (
          <div className="absolute top-3 left-3">
            <span className="flex items-center gap-1.5 bg-red-600 text-white text-xs font-bold px-2.5 py-1 rounded-full shadow">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-white" />
              </span>
              LIVE · {formatDuration(duration)}
            </span>
          </div>
        )}
        {isReconnecting && (
          <div className="absolute top-3 left-3">
            <span className="flex items-center gap-1.5 bg-amber-500 text-white text-xs font-bold px-2.5 py-1 rounded-full shadow">
              <Loader2 size={10} className="animate-spin" />
              RECONNECTING · {formatDuration(duration)}
            </span>
          </div>
        )}
        {!isActiveStream && permissionState === "granted" && (
          <div className="absolute top-3 left-3">
            <span className="bg-black/60 text-white/70 text-xs font-bold px-2.5 py-1 rounded-full font-heading uppercase tracking-wider">
              Preview
            </span>
          </div>
        )}
      </div>

      {/* Camera selector */}
      {permissionState === "granted" && !isActiveStream && videoDevices.length > 0 && (
        <div className="flex items-center gap-3 max-w-xl">
          <label className="text-sm font-medium text-muted-foreground whitespace-nowrap flex items-center gap-1.5">
            <Video size={14} /> Camera
          </label>
          <Select value={selectedDeviceId} onValueChange={setSelectedDeviceId}>
            <SelectTrigger className="flex-1">
              <SelectValue placeholder="Select camera…" />
            </SelectTrigger>
            <SelectContent>
              {videoDevices.map((d, i) => (
                <SelectItem key={d.deviceId} value={d.deviceId}>
                  {d.label || `Camera ${i + 1}`}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      {errorMsg && (
        <div className="flex items-start gap-2 text-destructive text-sm bg-destructive/10 rounded-lg px-3 py-2.5 max-w-xl">
          <AlertCircle size={15} className="mt-0.5 flex-shrink-0" />
          {errorMsg}
        </div>
      )}

      {/* Action controls */}
      <div className="flex flex-col gap-2 max-w-xl">
        {!isActiveStream ? (
          <>
            <div className="flex items-center gap-2 flex-wrap">
              <Button
                onClick={handleGoLive}
                disabled={permissionState !== "granted" || cloudUnconfigured}
                className="font-heading uppercase tracking-wider gap-2 bg-red-600 hover:bg-red-700 text-white disabled:opacity-50"
              >
                <Radio size={16} /> Go Live
              </Button>
            </div>
            {cloudUnconfigured && (
              <p className="text-sm text-muted-foreground flex items-start gap-1.5">
                <AlertCircle size={14} className="mt-0.5 flex-shrink-0 text-amber-500" />
                Live streaming requires cloud sync to be configured. Go to Settings → Cloud Sync to set it up.
              </p>
            )}
          </>
        ) : (
          <>
            <div className="flex items-center gap-2 flex-wrap">
              <Button
                variant="ghost" size="sm"
                onClick={toggleMic}
                disabled={isReconnecting}
                className={micEnabled ? "text-foreground" : "text-destructive"}
                title={micEnabled ? "Mute mic" : "Unmute mic"}
              >
                {micEnabled ? <Mic size={16} /> : <MicOff size={16} />}
                <span className="ml-1.5 text-xs">{micEnabled ? "Mic on" : "Muted"}</span>
              </Button>
              <Button
                variant="ghost" size="sm"
                onClick={toggleCam}
                disabled={isReconnecting}
                className={camEnabled ? "text-foreground" : "text-destructive"}
                title={camEnabled ? "Hide camera" : "Show camera"}
              >
                {camEnabled ? <Video size={16} /> : <VideoOff size={16} />}
                <span className="ml-1.5 text-xs">{camEnabled ? "Cam on" : "Cam off"}</span>
              </Button>
              <Button
                variant="outline" size="sm"
                onClick={handleStop}
                className="font-heading uppercase text-xs text-destructive border-destructive/40 hover:bg-destructive/10 ml-2"
              >
                End Stream
              </Button>
            </div>
          </>
        )}
      </div>

    </div>
  );
}
