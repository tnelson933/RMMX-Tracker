import { useState } from "react";
import { StateSelect } from "@/components/ui/StateSelect";
import { useRoute, Link } from "wouter";
import { useGetRider, useUpdateRider, useAssignRfid, useListDiscountCodes, getGetRiderQueryKey } from "@workspace/api-client-react";
import type { DiscountCode as DiscountCodeType } from "@workspace/api-client-react";
import { useQueryClient, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { useForm } from "react-hook-form";
import { zodResolver } from "@/lib/zodResolver";
import { z } from "zod";
import { loadPdfJs, PDF_JS_WORKER_URL } from "@/lib/pdfJs";
import { useToast } from "@/hooks/use-toast";
import { User, Tag, History, ChevronLeft, Save, Activity, Bike, Star, MapPin, Ticket, Copy, Check, Trash2, Plus, Loader2, FileText, ShieldCheck, ChevronDown, Download, ExternalLink, Radio } from "lucide-react";
import { format } from "date-fns";
import { useGetMe } from "@workspace/api-client-react";
import { PdfSignedViewer } from "@/components/PdfSignedViewer";

// ── Types ────────────────────────────────────────────────────────────────────

interface WaiverAck {
  id: number;
  eventId: number;
  eventName: string;
  eventDate: string;
  waiverAcknowledgedAt: string;
  waiverSnapshot: string | null;
}

interface WaiverField {
  id: string;
  type: "name" | "email" | "date" | "signature";
  page: number;
  x: number;
  y: number;
  width: number;
  height: number;
}

interface PdfWaiverSignature {
  id: number;
  eventId: number;
  eventName: string;
  eventDate: string;
  signerName: string;
  signerEmail: string;
  signedAt: string;
  waiverSnapshot: string;
  fieldLayout: WaiverField[] | null;
  signerType: "self" | "guardian";
  minorRiderName: string | null;
  waiverContentHash: string;
}

// ── Download helper ───────────────────────────────────────────────────────────

async function downloadSignedPdf(sig: PdfWaiverSignature): Promise<void> {
  const pdfjs = await loadPdfJs();
  if (!pdfjs.GlobalWorkerOptions.workerSrc) {
    pdfjs.GlobalWorkerOptions.workerSrc =
      PDF_JS_WORKER_URL;
  }

  const loadingTask = pdfjs.getDocument(sig.waiverSnapshot);
  const pdfDoc = await loadingTask.promise;

  const { jsPDF } = await import("jspdf");

  const signerName = sig.signerName;
  const signerEmail = sig.signerEmail;
  const signedDate = format(new Date(sig.signedAt), "MM/dd/yyyy");
  const fields = sig.fieldLayout ?? [];

  let pdf: InstanceType<typeof jsPDF> | null = null;

  for (let pageNum = 1; pageNum <= pdfDoc.numPages; pageNum++) {
    const page = await pdfDoc.getPage(pageNum);
    const viewport = page.getViewport({ scale: 2 });

    const canvas = document.createElement("canvas");
    canvas.width = viewport.width;
    canvas.height = viewport.height;
    const ctx = canvas.getContext("2d")!;

    await page.render({ canvasContext: ctx, viewport }).promise;

    // Draw field values on this page's canvas
    const pageFields = fields.filter(f => f.page === pageNum);
    for (const field of pageFields) {
      const x = field.x * viewport.width;
      const y = field.y * viewport.height;
      const w = field.width * viewport.width;
      const h = field.height * viewport.height;

      // Highlight background
      ctx.fillStyle = "rgba(219, 234, 254, 0.55)";
      ctx.fillRect(x, y, w, h);

      // Text value
      const fontSize = Math.max(10, Math.min(h * 0.55, 24));
      ctx.font = field.type === "signature"
        ? `italic ${fontSize}px Georgia, serif`
        : `${fontSize}px Arial, sans-serif`;
      ctx.fillStyle = field.type === "signature" ? "#1d4ed8" : "#1e293b";
      ctx.textBaseline = "middle";

      const signatureValue =
        (sig.signerType === "guardian" && sig.minorRiderName)
          ? `${signerName} — parent/guardian of ${sig.minorRiderName}`
          : signerName;
      const value =
        field.type === "name" ? signerName
        : field.type === "email" ? signerEmail
        : field.type === "date" ? signedDate
        : signatureValue; // signature

      // Clip to field bounds
      ctx.save();
      ctx.beginPath();
      ctx.rect(x + 4, y, w - 8, h);
      ctx.clip();
      ctx.fillText(value, x + 6, y + h / 2);
      ctx.restore();
    }

    const imgData = canvas.toDataURL("image/png");
    const pdfW = viewport.width / 2;
    const pdfH = viewport.height / 2;

    if (!pdf) {
      pdf = new jsPDF({
        orientation: pdfW > pdfH ? "landscape" : "portrait",
        unit: "pt",
        format: [pdfW, pdfH],
      });
    } else {
      pdf.addPage([pdfW, pdfH], pdfW > pdfH ? "landscape" : "portrait");
    }

    pdf.addImage(imgData, "PNG", 0, 0, pdfW, pdfH);
  }

  if (pdf) {
    const filename = `waiver-${sig.signerName.replace(/\s+/g, "-").toLowerCase()}-${sig.eventName.replace(/\s+/g, "-").toLowerCase()}.pdf`;
    pdf.save(filename);
  }
}

// ── WaiverAcknowledgmentsCard ─────────────────────────────────────────────────

function WaiverAcknowledgmentsCard({ riderId, clubId }: { riderId: number; clubId: number }) {
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [viewingSig, setViewingSig] = useState<PdfWaiverSignature | null>(null);
  const [downloading, setDownloading] = useState<number | null>(null);

  const { data: acks, isLoading: acksLoading } = useQuery<WaiverAck[]>({
    queryKey: ["waiver-acknowledgments", clubId, riderId],
    queryFn: async () => {
      const res = await fetch(`/api/clubs/${clubId}/riders/${riderId}/waiver-acknowledgments`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch waiver acknowledgments");
      return res.json();
    },
  });

  const { data: pdfSigs, isLoading: sigsLoading } = useQuery<PdfWaiverSignature[]>({
    queryKey: ["liability-waiver-signatures", clubId, riderId],
    queryFn: async () => {
      const res = await fetch(`/api/clubs/${clubId}/riders/${riderId}/liability-waiver-signatures`, { credentials: "include" });
      if (!res.ok) return [];
      return res.json();
    },
  });

  const isLoading = acksLoading || sigsLoading;
  const hasPdfSigs = pdfSigs && pdfSigs.length > 0;
  const hasTextAcks = acks && acks.some(a => a.waiverSnapshot && !a.waiverSnapshot.startsWith("http"));
  const isEmpty = !hasPdfSigs && !hasTextAcks && !isLoading;

  return (
    <>
      <Card>
        <CardHeader className="border-b pb-4">
          <CardTitle className="font-heading uppercase text-xl flex items-center gap-2">
            <ShieldCheck className="text-primary" size={20} />
            Waiver History
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex items-center justify-center py-6">
              <Loader2 size={18} className="animate-spin text-muted-foreground" />
            </div>
          ) : isEmpty ? (
            <div className="p-6 text-center text-muted-foreground text-sm">No waiver acknowledgments on record.</div>
          ) : (
            <div className="divide-y">

              {/* PDF signed waivers */}
              {pdfSigs?.map(sig => (
                <div key={`pdf-${sig.id}`} className="p-4">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="text-sm font-semibold truncate">{sig.eventName}</p>
                        <Badge variant="outline" className="text-xs py-0 h-5 border-green-400 text-green-700 bg-green-50">
                          PDF Signed
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        <ShieldCheck size={11} className="inline text-green-600 mr-1" />
                        Signed by <strong>{sig.signerName}</strong>
                        {sig.signerType === "guardian" && sig.minorRiderName && (
                          <span className="ml-1 text-amber-700 dark:text-amber-400">(parent/guardian of {sig.minorRiderName})</span>
                        )}
                        {" · "}{format(new Date(sig.signedAt), "MMM d, yyyy 'at' h:mm a")}
                      </p>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-7 px-2 text-xs"
                        onClick={() => setViewingSig(sig)}
                      >
                        <ExternalLink size={11} className="mr-1" />
                        View
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-7 px-2 text-xs text-muted-foreground"
                        disabled={downloading === sig.id}
                        onClick={async () => {
                          setDownloading(sig.id);
                          try { await downloadSignedPdf(sig); } finally { setDownloading(null); }
                        }}
                      >
                        {downloading === sig.id
                          ? <Loader2 size={11} className="animate-spin" />
                          : <Download size={11} />
                        }
                      </Button>
                    </div>
                  </div>
                </div>
              ))}

              {/* Text waiver acknowledgments (non-PDF) */}
              {acks?.filter(a => a.waiverSnapshot && !a.waiverSnapshot.startsWith("http")).map(ack => (
                <div key={`txt-${ack.id}`} className="p-4">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold truncate">{ack.eventName}</p>
                      <p className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1">
                        <ShieldCheck size={11} className="text-green-600 shrink-0" />
                        Accepted {format(new Date(ack.waiverAcknowledgedAt), "MMM d, yyyy 'at' h:mm a")}
                      </p>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 px-2 text-xs text-muted-foreground"
                      onClick={() => setExpandedId(expandedId === ack.id ? null : ack.id)}
                    >
                      <FileText size={12} className="mr-1" />
                      {expandedId === ack.id ? "Hide" : "View"}
                      <ChevronDown size={12} className={`ml-1 transition-transform ${expandedId === ack.id ? "rotate-180" : ""}`} />
                    </Button>
                  </div>
                  {expandedId === ack.id && ack.waiverSnapshot && (
                    <div className="mt-3 rounded-md bg-muted/50 border px-3 py-3 max-h-48 overflow-y-auto">
                      <pre className="whitespace-pre-wrap font-sans text-xs text-muted-foreground leading-relaxed">
                        {ack.waiverSnapshot}
                      </pre>
                    </div>
                  )}
                </div>
              ))}

            </div>
          )}
        </CardContent>
      </Card>

      {/* PDF viewer dialog */}
      <Dialog open={!!viewingSig} onOpenChange={(open) => { if (!open) setViewingSig(null); }}>
        <DialogContent className="max-w-[92vw] w-[92vw] h-[90vh] flex flex-col p-0 gap-0 overflow-hidden">
          <DialogHeader className="px-5 py-3 border-b flex-row items-center justify-between space-y-0">
            <div>
              <DialogTitle className="font-heading uppercase tracking-wider text-base">
                Signed Waiver — {viewingSig?.eventName}
              </DialogTitle>
              <DialogDescription className="text-xs mt-0.5">
                Signed by <strong>{viewingSig?.signerName}</strong>
                {viewingSig?.signerType === "guardian" && viewingSig?.minorRiderName && (
                  <span className="ml-1 text-amber-700 dark:text-amber-400">(parent/guardian of {viewingSig.minorRiderName})</span>
                )}
                {" "}({viewingSig?.signerEmail}) on{" "}
                {viewingSig ? format(new Date(viewingSig.signedAt), "MMMM d, yyyy 'at' h:mm a") : ""}
              </DialogDescription>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="shrink-0 ml-4"
              disabled={!viewingSig || downloading === viewingSig.id}
              onClick={async () => {
                if (!viewingSig) return;
                setDownloading(viewingSig.id);
                try { await downloadSignedPdf(viewingSig); } finally { setDownloading(null); }
              }}
            >
              {downloading === viewingSig?.id
                ? <Loader2 size={14} className="animate-spin mr-1.5" />
                : <Download size={14} className="mr-1.5" />
              }
              Download PDF
            </Button>
          </DialogHeader>
          <div className="flex-1 overflow-hidden">
            {viewingSig && (
              <PdfSignedViewer
                url={viewingSig.waiverSnapshot}
                fields={viewingSig.fieldLayout ?? []}
                signerName={viewingSig.signerName}
                signerEmail={viewingSig.signerEmail}
                signedAt={format(new Date(viewingSig.signedAt), "MM/dd/yyyy")}
                signerType={viewingSig.signerType}
                minorRiderName={viewingSig.minorRiderName ?? undefined}
              />
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

const updateRiderSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  email: z.string().email().optional().or(z.literal("")),
  phone: z.string().optional(),
  bibNumber: z.string().optional(),
  dateOfBirth: z.string().optional(),
  emergencyContact: z.string().optional(),
  emergencyPhone: z.string().optional(),
  streetAddress: z.string().optional(),
  city: z.string().optional(),
  homeState: z.string().optional(),
  zip: z.string().optional(),
  bikeManufacturer: z.string().optional(),
  bikeModel: z.string().optional(),
  bikeYear: z.string().optional(),
  sponsors: z.string().optional(),
  amaNumber: z.string().optional(),
  mylapsTransponderId: z.string().optional(),
});

function InfoRow({ label, value }: { label: string; value?: string | null }) {
  return (
    <div>
      <div className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-1">{label}</div>
      <div className="font-medium">{value || <span className="text-muted-foreground/50">—</span>}</div>
    </div>
  );
}

interface DiscountCodeLegacy {
  id: number;
  code: string;
  amount: number;
  maxUses: number;
  usesCount: number;
  riderId: number;
  riderName?: string;
  createdAt: string;
}

function DiscountCodeCard({ riderId, clubId }: { riderId: number; clubId: number }) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [code, setCode] = useState<DiscountCodeLegacy | null | undefined>(undefined);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showGenerateDialog, setShowGenerateDialog] = useState(false);
  const [generateAmount, setGenerateAmount] = useState("");
  const [generating, setGenerating] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const fetchCode = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/clubs/${clubId}/riders/${riderId}/discount-code`, { credentials: "include" });
      if (res.ok) {
        const data = await res.json();
        setCode(data);
      }
    } finally {
      setLoading(false);
    }
  };

  if (code === undefined && !loading) {
    fetchCode();
  }

  const handleGenerate = async () => {
    const amount = parseFloat(generateAmount);
    if (!amount || amount <= 0) return;
    setGenerating(true);
    try {
      const res = await fetch(`/api/clubs/${clubId}/riders/${riderId}/discount-code`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ amount }),
      });
      if (res.ok) {
        const data = await res.json();
        setCode(data);
        setShowGenerateDialog(false);
        setGenerateAmount("");
        toast({ title: "Discount code generated", description: `Code: ${data.code}` });
      } else {
        const err = await res.json();
        toast({ title: "Failed to generate code", description: err.error, variant: "destructive" });
      }
    } finally {
      setGenerating(false);
    }
  };

  const handleDelete = async () => {
    setDeleting(true);
    try {
      const res = await fetch(`/api/clubs/${clubId}/riders/${riderId}/discount-code`, {
        method: "DELETE",
        credentials: "include",
      });
      if (res.ok) {
        setCode(null);
        toast({ title: "Discount code removed" });
      } else {
        const err = await res.json();
        toast({ title: "Failed to delete code", description: err.error, variant: "destructive" });
      }
    } finally {
      setDeleting(false);
    }
  };

  const handleCopy = () => {
    if (!code) return;
    navigator.clipboard.writeText(code.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast({ title: "Code copied to clipboard" });
  };

  const isUsed = code ? code.usesCount >= code.maxUses : false;

  return (
    <>
      <Card className={code && !isUsed ? "border-primary/30" : ""}>
        <CardHeader className="border-b pb-4">
          <CardTitle className="font-heading uppercase text-xl flex items-center gap-2">
            <Ticket className="text-primary" size={20} />
            Discount Code
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          {loading || code === undefined ? (
            <div className="flex items-center justify-center py-4">
              <Loader2 size={20} className="animate-spin text-muted-foreground" />
            </div>
          ) : code && !isUsed ? (
            <div className="space-y-4">
              <div className="flex items-center justify-center p-5 bg-primary/5 rounded-lg border border-primary/20">
                <div className="text-center">
                  <div className="text-xs font-bold text-primary uppercase tracking-widest mb-2">Active Code</div>
                  <div className="font-mono text-2xl font-bold tracking-widest text-primary">{code.code}</div>
                  <div className="text-sm text-muted-foreground mt-1">${code.amount.toFixed(2)} discount</div>
                </div>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="flex-1 font-heading uppercase" onClick={handleCopy}>
                  {copied ? <><Check size={14} className="mr-2" /> Copied</> : <><Copy size={14} className="mr-2" /> Copy Code</>}
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="text-destructive hover:text-destructive hover:bg-destructive/10"
                  onClick={handleDelete}
                  disabled={deleting}
                  title="Revoke code"
                >
                  {deleting ? <Loader2 size={14} className="animate-spin" /> : <Trash2 size={14} />}
                </Button>
              </div>
              <p className="text-xs text-muted-foreground text-center">
                Rider enters this code at event registration for ${code.amount.toFixed(2)} off.
              </p>
            </div>
          ) : code && isUsed ? (
            <div className="space-y-4">
              <div className="flex items-center justify-center p-5 bg-muted rounded-lg border">
                <div className="text-center">
                  <div className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-2">Code Used</div>
                  <div className="font-mono text-xl font-bold text-muted-foreground line-through tracking-widest">{code.code}</div>
                  <div className="text-sm text-muted-foreground mt-1">${code.amount.toFixed(2)} — already redeemed</div>
                </div>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="w-full font-heading uppercase"
                onClick={handleDelete}
                disabled={deleting}
              >
                {deleting ? <Loader2 size={14} className="mr-2 animate-spin" /> : <Trash2 size={14} className="mr-2" />}
                Clear Used Code
              </Button>
              <Button
                size="sm"
                className="w-full font-heading uppercase"
                onClick={() => setShowGenerateDialog(true)}
              >
                <Plus size={14} className="mr-2" /> Generate New Code
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center justify-center p-5 bg-muted/50 rounded-lg border border-dashed">
                <div className="text-center">
                  <div className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-1">No Code Assigned</div>
                  <div className="text-sm text-muted-foreground">Generate a personalized discount code for this rider</div>
                </div>
              </div>
              <Button
                size="sm"
                className="w-full font-heading uppercase"
                onClick={() => setShowGenerateDialog(true)}
              >
                <Plus size={14} className="mr-2" /> Generate Code
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={showGenerateDialog} onOpenChange={setShowGenerateDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="font-heading uppercase">Generate Discount Code</DialogTitle>
            <DialogDescription>
              This code will be locked to this rider. They'll need to enter their exact name and email when using it at registration.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <label className="text-sm font-bold uppercase tracking-wider block mb-2">Discount Amount ($)</label>
            <Input
              type="number"
              min="0.01"
              step="0.01"
              placeholder="45.00"
              value={generateAmount}
              onChange={e => setGenerateAmount(e.target.value)}
              autoFocus
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowGenerateDialog(false)}>Cancel</Button>
            <Button
              onClick={handleGenerate}
              disabled={generating || !generateAmount || parseFloat(generateAmount) <= 0}
              className="font-heading uppercase"
            >
              {generating ? <><Loader2 size={14} className="mr-2 animate-spin" /> Generating...</> : "Generate Code"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

function formatDate(iso: string | null | undefined): string {
  if (!iso) return "No expiry";
  return new Date(iso).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
}

function isExpired(code: DiscountCodeType): boolean {
  return !!code.expiresAt && new Date() > new Date(code.expiresAt);
}

function RiderAssignedCodesSection({ riderId }: { riderId: number }) {
  const { toast } = useToast();
  const { data: codes = [], isLoading } = useListDiscountCodes(
    { riderId },
    { query: {} as any }
  );
  const [copiedId, setCopiedId] = useState<number | null>(null);

  const handleCopy = (code: DiscountCodeType) => {
    navigator.clipboard.writeText(code.code);
    setCopiedId(code.id);
    setTimeout(() => setCopiedId(null), 2000);
    toast({ title: "Code copied!" });
  };

  const getStatusBadge = (code: DiscountCodeType) => {
    if (!code.isActive) return <Badge variant="destructive" className="text-xs">Inactive</Badge>;
    if (isExpired(code)) return <Badge variant="destructive" className="text-xs">Expired</Badge>;
    if (code.usesCount >= code.maxUses) return <Badge variant="secondary" className="text-xs">Used</Badge>;
    return <Badge variant="default" className="text-xs bg-green-600">Active</Badge>;
  };

  return (
    <Card>
      <CardHeader className="border-b pb-4">
        <CardTitle className="font-heading uppercase text-xl flex items-center gap-2">
          <Tag className="text-primary" size={20} />
          Discount Codes
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        {isLoading ? (
          <div className="flex items-center justify-center py-6">
            <Loader2 size={18} className="animate-spin text-muted-foreground" />
          </div>
        ) : (codes as DiscountCodeType[]).length === 0 ? (
          <div className="p-6 text-center text-muted-foreground">
            <Tag size={24} className="mx-auto mb-2 opacity-30" />
            <p className="text-sm">No discount codes assigned.</p>
          </div>
        ) : (
          <div className="divide-y">
            {(codes as DiscountCodeType[]).map(code => (
              <div key={code.id} className="px-4 py-3 flex items-center gap-3">
                <div className="flex-1 min-w-0 space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold tracking-wider text-sm">{code.code}</span>
                    <button
                      className="text-muted-foreground hover:text-foreground transition-colors"
                      onClick={() => handleCopy(code)}
                      title="Copy code"
                    >
                      {copiedId === code.id ? <Check size={12} className="text-green-600" /> : <Copy size={12} />}
                    </button>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground flex-wrap">
                    <span className="font-medium text-foreground">
                      {code.discountType === "percentage"
                        ? `${Number(code.amount).toFixed(0)}% off`
                        : `$${Number(code.amount).toFixed(2)} off`}
                    </span>
                    <span>·</span>
                    <span>Expires: {formatDate(code.expiresAt)}</span>
                    <span>·</span>
                    <span>{code.usesCount}/{code.maxUses >= 999999 ? "∞" : code.maxUses} uses</span>
                  </div>
                </div>
                <div className="shrink-0">{getStatusBadge(code)}</div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function RiderDetail() {
  const [match, params] = useRoute("/riders/:riderId");
  const riderId = parseInt(params?.riderId || "0");
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: rider, isLoading } = useGetRider(riderId, { query: { enabled: !!riderId } as any });
  const { data: me } = useGetMe({ query: {} as any });

  const updateMutation = useUpdateRider();
  const assignRfidMutation = useAssignRfid();

  const [isEditing, setIsEditing] = useState(false);
  const [emailExpanded, setEmailExpanded] = useState(false);
  const [rfidInput, setRfidInput] = useState("");
  const [activeTransponderInput, setActiveTransponderInput] = useState("");

  const r = rider as any;
  const clubId = (me as any)?.clubId;
  const isDesktop = typeof (window as any).electronAPI !== "undefined";

  const form = useForm<z.infer<typeof updateRiderSchema>>({
    resolver: zodResolver(updateRiderSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      bibNumber: "",
      dateOfBirth: "",
      emergencyContact: "",
      emergencyPhone: "",
      streetAddress: "",
      city: "",
      homeState: "",
      zip: "",
      bikeManufacturer: "",
      bikeModel: "",
      bikeYear: "",
      sponsors: "",
      amaNumber: "",
      mylapsTransponderId: "",
    },
  });

  if (rider && !isEditing && form.getValues("firstName") === "") {
    form.reset({
      firstName: rider.firstName,
      lastName: rider.lastName,
      email: rider.email || "",
      phone: rider.phone || "",
      bibNumber: rider.bibNumber || "",
      dateOfBirth: rider.dateOfBirth || "",
      emergencyContact: rider.emergencyContact || "",
      emergencyPhone: rider.emergencyPhone || "",
      streetAddress: r.streetAddress || "",
      city: r.city || "",
      homeState: r.homeState || "",
      zip: r.zip || "",
      bikeManufacturer: r.bikeManufacturer || "",
      bikeModel: (r as any).bikeModel || "",
      bikeYear: (r as any).bikeYear || "",
      sponsors: r.sponsors || "",
      amaNumber: r.amaNumber || "",
      mylapsTransponderId: r.mylapsTransponderId || "",
    });
  }

  const onSubmit = (data: z.infer<typeof updateRiderSchema>) => {
    updateMutation.mutate(
      { riderId, data },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetRiderQueryKey(riderId) });
          setIsEditing(false);
          toast({ title: "Rider profile updated" });
        },
        onError: (err) => {
          toast({ title: "Update failed", description: err.message, variant: "destructive" });
        },
      }
    );
  };

  const handleAssignRfid = () => {
    if (!rfidInput) return;
    assignRfidMutation.mutate(
      { data: { riderId, rfidNumber: rfidInput } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetRiderQueryKey(riderId) });
          setRfidInput("");
          toast({ title: "RFID assigned successfully" });
        },
        onError: (err) => {
          toast({ title: "Assignment failed", description: err.message, variant: "destructive" });
        },
      }
    );
  };

  const handleAssignActiveTransponder = () => {
    const value = activeTransponderInput.trim();
    if (!value) return;
    updateMutation.mutate(
      { riderId, data: { mylapsTransponderId: value } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetRiderQueryKey(riderId) });
          setActiveTransponderInput("");
          toast({ title: "Active transponder assigned successfully" });
        },
        onError: (err) => {
          toast({ title: "Assignment failed", description: err.message, variant: "destructive" });
        },
      }
    );
  };

  if (isLoading) return <div className="p-8">Loading rider...</div>;
  if (!rider) return <div className="p-8">Rider not found</div>;

  return (
    <div className="p-8 max-w-5xl mx-auto space-y-6">
      <Link href="/riders" className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground font-medium uppercase tracking-wider mb-2">
        <ChevronLeft size={16} className="mr-1" /> Back to Database
      </Link>

      <div className="flex items-center gap-4 mb-8">
        <div className="w-16 h-16 bg-sidebar rounded-lg flex items-center justify-center text-sidebar-foreground">
          <User size={32} />
        </div>
        <div>
          <h1 className="text-4xl font-heading font-bold uppercase tracking-tight">
            {rider.firstName} {rider.lastName}
          </h1>
          <div className="flex items-center gap-3 text-muted-foreground mt-1 flex-wrap">
            {rider.bibNumber && (
              <span className="font-mono bg-muted px-2 py-0.5 rounded text-sm font-bold border">Bib: {rider.bibNumber}</span>
            )}
            {(r.city || r.homeState) && (
              <span className="flex items-center gap-1 text-sm"><MapPin size={13} /> {[r.city, r.homeState].filter(Boolean).join(", ")}</span>
            )}
            {r.bikeManufacturer && (
              <span className="flex items-center gap-1 text-sm"><Bike size={13} /> {r.bikeManufacturer}</span>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">

          {/* Personal Information */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2 border-b">
              <CardTitle className="font-heading uppercase text-xl flex items-center gap-2">
                <User className="text-primary" size={20} /> Personal Information
              </CardTitle>
              {!isEditing && (
                <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}>Edit Profile</Button>
              )}
            </CardHeader>
            <CardContent className="p-6">
              {isEditing ? (
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
                    {/* Name */}
                    <div className="grid grid-cols-2 gap-4">
                      <FormField control={form.control} name="firstName" render={({ field }) => (
                        <FormItem><FormLabel>First Name</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                      )} />
                      <FormField control={form.control} name="lastName" render={({ field }) => (
                        <FormItem><FormLabel>Last Name</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                      )} />
                    </div>

                    {/* Contact */}
                    <div className="grid grid-cols-2 gap-4">
                      <FormField control={form.control} name="email" render={({ field }) => (
                        <FormItem><FormLabel>Email</FormLabel><FormControl><Input type="email" {...field} /></FormControl><FormMessage /></FormItem>
                      )} />
                      <FormField control={form.control} name="phone" render={({ field }) => (
                        <FormItem><FormLabel>Phone</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                      )} />
                    </div>

                    {/* Address */}
                    <FormField control={form.control} name="streetAddress" render={({ field }) => (
                      <FormItem><FormLabel>Street Address</FormLabel><FormControl><Input placeholder="123 Dirt Track Rd" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <div className="grid grid-cols-3 gap-4">
                      <FormField control={form.control} name="city" render={({ field }) => (
                        <FormItem><FormLabel>City</FormLabel><FormControl><Input placeholder="Tucson" {...field} /></FormControl><FormMessage /></FormItem>
                      )} />
                      <FormField control={form.control} name="homeState" render={({ field }) => (
                        <FormItem><FormLabel>State</FormLabel><FormControl><StateSelect value={field.value} onChange={field.onChange} /></FormControl><FormMessage /></FormItem>
                      )} />
                      <FormField control={form.control} name="zip" render={({ field }) => (
                        <FormItem><FormLabel>ZIP</FormLabel><FormControl><Input placeholder="85701" maxLength={10} {...field} /></FormControl><FormMessage /></FormItem>
                      )} />
                    </div>

                    {/* Basics */}
                    <FormField control={form.control} name="dateOfBirth" render={({ field }) => (
                      <FormItem><FormLabel>Date of Birth</FormLabel><FormControl><Input type="date" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />

                    {/* Racing info */}
                    <div className="border-t pt-4 mt-2">
                      <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-4">Racing Info</p>
                      <div className="grid grid-cols-2 gap-4">
                        <FormField control={form.control} name="bikeManufacturer" render={({ field }) => (
                          <FormItem><FormLabel>Bike Manufacturer</FormLabel><FormControl><Input placeholder="Honda, KTM, Yamaha…" {...field} /></FormControl><FormMessage /></FormItem>
                        )} />
                        <FormField control={form.control} name="bibNumber" render={({ field }) => (
                          <FormItem><FormLabel>Default Bib #</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                        )} />
                      </div>
                      <div className="grid grid-cols-2 gap-4 mt-4">
                        <FormField control={form.control} name="bikeModel" render={({ field }) => (
                          <FormItem><FormLabel>Bike Model</FormLabel><FormControl><Input placeholder="450 SX-F, CRF450R…" {...field} /></FormControl><FormMessage /></FormItem>
                        )} />
                        <FormField control={form.control} name="bikeYear" render={({ field }) => (
                          <FormItem><FormLabel>Bike Year</FormLabel><FormControl><Input placeholder="2024" maxLength={4} {...field} /></FormControl><FormMessage /></FormItem>
                        )} />
                      </div>
                      <div className="grid grid-cols-2 gap-4 mt-4">
                        <FormField control={form.control} name="amaNumber" render={({ field }) => (
                          <FormItem><FormLabel>AMA #</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                        )} />
                        <FormField control={form.control} name="mylapsTransponderId" render={({ field }) => (
                          <FormItem><FormLabel>Active Timing Transponder #</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                        )} />
                      </div>
                      <div className="mt-4">
                        <FormField control={form.control} name="sponsors" render={({ field }) => (
                          <FormItem><FormLabel>Sponsors</FormLabel><FormControl><Input placeholder="Fox Racing, Alpinestars, FMF…" {...field} /></FormControl><FormMessage /></FormItem>
                        )} />
                      </div>
                    </div>

                    {/* Emergency */}
                    <div className="border-t pt-4 mt-2">
                      <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-4">Emergency Contact</p>
                      <div className="grid grid-cols-2 gap-4">
                        <FormField control={form.control} name="emergencyContact" render={({ field }) => (
                          <FormItem><FormLabel>Name</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                        )} />
                        <FormField control={form.control} name="emergencyPhone" render={({ field }) => (
                          <FormItem><FormLabel>Phone</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                        )} />
                      </div>
                    </div>

                    <div className="pt-4 flex justify-end gap-2">
                      <Button variant="ghost" type="button" onClick={() => setIsEditing(false)}>Cancel</Button>
                      <Button type="submit" disabled={updateMutation.isPending} className="font-heading uppercase">
                        <Save size={16} className="mr-2" /> Save Profile
                      </Button>
                    </div>
                  </form>
                </Form>
              ) : (
                <div className="space-y-6">
                  {/* Contact */}
                  <div className="grid grid-cols-2 gap-y-5">
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-1 flex items-center gap-1">
                        EMAIL
                        {rider.email && (
                          <button
                            onClick={() => setEmailExpanded(e => !e)}
                            className="inline-flex items-center justify-center w-4 h-4 rounded-full border border-muted-foreground/40 text-muted-foreground/60 hover:text-foreground hover:border-foreground transition-colors text-[10px] leading-none"
                            title={emailExpanded ? "Collapse" : "Show full email"}
                          >
                            {emailExpanded ? "−" : "+"}
                          </button>
                        )}
                      </div>
                      {rider.email ? (
                        emailExpanded ? (
                          <div className="font-medium break-all">{rider.email}</div>
                        ) : (
                          <div className="font-medium truncate pr-2">{rider.email}</div>
                        )
                      ) : (
                        <div className="font-medium"><span className="text-muted-foreground/50">—</span></div>
                      )}
                    </div>
                    <InfoRow label="Phone" value={rider.phone} />
                    <InfoRow label="Date of Birth" value={rider.dateOfBirth} />
                  </div>
                  <div className="border-t pt-5">
                    <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-4">Address</p>
                    <div className="grid grid-cols-2 gap-y-5">
                      <InfoRow label="Street Address" value={r.streetAddress} />
                      <InfoRow label="ZIP" value={r.zip} />
                      <InfoRow label="City" value={r.city} />
                      <InfoRow label="State" value={r.homeState} />
                    </div>
                  </div>

                  {/* Racing */}
                  <div className="border-t pt-5">
                    <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-4">Racing Info</p>
                    <div className="grid grid-cols-2 gap-y-5">
                      <InfoRow label="Bike Manufacturer" value={r.bikeManufacturer} />
                      <InfoRow label="Bike Model" value={(r as any).bikeModel} />
                      <InfoRow label="Bike Year" value={(r as any).bikeYear} />
                      <InfoRow label="Default Bib #" value={rider.bibNumber} />
                      <InfoRow label="AMA #" value={r.amaNumber} />
                      <InfoRow label="Active Timing Transponder #" value={r.mylapsTransponderId} />
                      <InfoRow label="Club ID #" value={(rider as any).clubIdNumber} />
                    </div>
                    {r.sponsors && (
                      <div className="mt-5">
                        <InfoRow label="Sponsors" value={r.sponsors} />
                      </div>
                    )}
                  </div>

                  {/* Emergency */}
                  <div className="border-t pt-5">
                    <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-4">Emergency Contact</p>
                    <div className="grid grid-cols-2 gap-y-5">
                      <InfoRow label="Name" value={rider.emergencyContact} />
                      <InfoRow label="Phone" value={rider.emergencyPhone} />
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Assigned Discount Codes — cloud-only feature */}
          {!isDesktop && <RiderAssignedCodesSection riderId={riderId} />}

          {/* Sponsors callout (read view) */}
          {!isEditing && r.sponsors && (
            <Card className="border-primary/20 bg-primary/5">
              <CardContent className="p-5 flex items-start gap-3">
                <Star size={18} className="text-primary mt-0.5 shrink-0" />
                <div>
                  <div className="text-xs font-bold text-primary uppercase tracking-widest mb-1">Sponsors</div>
                  <div className="font-medium">{r.sponsors}</div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Recent Results */}
          <Card>
            <CardHeader className="border-b">
              <CardTitle className="font-heading uppercase text-xl flex items-center gap-2">
                <History className="text-primary" size={20} /> Recent Results
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {rider.recentResults && rider.recentResults.length > 0 ? (
                <div className="divide-y">
                  {rider.recentResults.map((result, i) => (
                    <div key={i} className="p-4 flex items-center justify-between hover:bg-muted/30 transition-colors">
                      <div>
                        <div className="font-heading font-bold text-lg">{result.raceClass}</div>
                        <div className="text-sm text-muted-foreground flex items-center gap-2">
                          <Activity size={14} /> Moto {result.motoId}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-heading font-bold text-primary">
                          {result.position === 1 ? "1st" : result.position === 2 ? "2nd" : result.position === 3 ? "3rd" : `${result.position}th`}
                        </div>
                        {result.points !== null && (
                          <div className="text-xs font-bold text-muted-foreground uppercase tracking-wider">{result.points} PTS</div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-8 text-center text-muted-foreground">No recent race results on record.</div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* RFID */}
          <Card className={rider.rfidNumber ? "border-secondary" : "border-destructive/30"}>
            <CardHeader className={`${rider.rfidNumber ? "bg-secondary/5" : "bg-destructive/5"} border-b pb-4`}>
              <CardTitle className="font-heading uppercase text-xl flex items-center gap-2">
                <Tag className={rider.rfidNumber ? "text-secondary" : "text-destructive"} size={20} />
                RFID Status
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              {rider.rfidNumber ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-center p-6 bg-secondary/10 rounded-lg border border-secondary/20">
                    <div className="text-center">
                      <div className="text-xs font-bold text-secondary uppercase tracking-widest mb-2">RFID Sticker Number</div>
                      <div className="font-mono text-xl font-bold text-secondary break-all">{rider.rfidNumber}</div>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground text-center">Used for automatic RFID check-in at events.</p>
                </div>
              ) : (
                <div className="flex items-center justify-center p-6 bg-destructive/10 rounded-lg border border-destructive/20">
                  <div className="text-center">
                    <div className="text-xs font-bold text-destructive uppercase tracking-widest mb-2">No RFID Sticker Assigned</div>
                    <div className="text-sm text-destructive/80 font-medium">Manual check-in required</div>
                  </div>
                </div>
              )}
              <div className="mt-6 pt-6 border-t space-y-3">
                <label className="text-sm font-bold uppercase tracking-wider block">Assign RFID Sticker</label>
                <div className="flex gap-2">
                  <Input
                    placeholder="Scan or enter RFID sticker number..."
                    value={rfidInput}
                    onChange={(e) => setRfidInput(e.target.value)}
                    className="font-mono"
                  />
                  <Button onClick={handleAssignRfid} disabled={!rfidInput || assignRfidMutation.isPending} className="font-heading uppercase">
                    Assign
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Active timing transponder */}
          <Card className={r.mylapsTransponderId ? "border-primary" : "border-muted"}>
            <CardHeader className={`${r.mylapsTransponderId ? "bg-primary/5" : "bg-muted/30"} border-b pb-4`}>
              <CardTitle className="font-heading uppercase text-xl flex items-center gap-2">
                <Radio className={r.mylapsTransponderId ? "text-primary" : "text-muted-foreground"} size={20} />
                Active Timing Transponder
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="flex items-center justify-center p-6 bg-muted/40 rounded-lg border">
                <div className="text-center">
                  <div className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-2">
                    Active Transponder Number
                  </div>
                  <div className="font-mono text-xl font-bold break-all">
                    {r.mylapsTransponderId || <span className="text-muted-foreground/60 text-sm font-sans">None assigned</span>}
                  </div>
                </div>
              </div>
              <div className="mt-6 pt-6 border-t space-y-3">
                <label className="text-sm font-bold uppercase tracking-wider block">
                  {r.mylapsTransponderId ? "Replace Active Transponder" : "Assign Active Transponder"}
                </label>
                <div className="flex gap-2">
                  <Input
                    placeholder="Enter transponder number..."
                    value={activeTransponderInput}
                    onChange={(e) => setActiveTransponderInput(e.target.value)}
                    className="font-mono"
                    onKeyDown={(e) => { if (e.key === "Enter") handleAssignActiveTransponder(); }}
                  />
                  <Button
                    onClick={handleAssignActiveTransponder}
                    disabled={!activeTransponderInput.trim() || updateMutation.isPending}
                    className="font-heading uppercase"
                  >
                    {updateMutation.isPending ? <Loader2 size={16} className="animate-spin" /> : "Assign"}
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  Used by the Active Timing Reader. This is separate from the rider&apos;s RFID sticker number.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Discount Code — cloud-only feature */}
          {!isDesktop && clubId && (
            <DiscountCodeCard riderId={riderId} clubId={clubId} />
          )}

          {/* Waiver acknowledgment history */}
          {clubId && (
            <WaiverAcknowledgmentsCard riderId={riderId} clubId={clubId} />
          )}

          {/* Active transponder quick view */}
          {r.mylapsTransponderId && (
            <Card>
              <CardContent className="p-5 space-y-1">
                <div className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Active Timing Transponder</div>
                <div className="font-mono text-lg font-bold">{r.mylapsTransponderId}</div>
              </CardContent>
            </Card>
          )}

          {/* AMA quick view */}
          {r.amaNumber && (
            <Card>
              <CardContent className="p-5 space-y-1">
                <div className="text-xs font-bold text-muted-foreground uppercase tracking-widest">AMA Membership #</div>
                <div className="font-mono text-lg font-bold">{r.amaNumber}</div>
              </CardContent>
            </Card>
          )}

          {/* Club ID quick view */}
          {(rider as any).clubIdNumber && (
            <Card>
              <CardContent className="p-5 space-y-1">
                <div className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Club ID #</div>
                <div className="font-mono text-lg font-bold">{(rider as any).clubIdNumber}</div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
