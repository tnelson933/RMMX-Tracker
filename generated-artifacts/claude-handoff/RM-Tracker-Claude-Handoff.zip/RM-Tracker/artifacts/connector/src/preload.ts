import { contextBridge, ipcRenderer } from "electron";

contextBridge.exposeInMainWorld("connector", {
  getStatus: () => ipcRenderer.invoke("status:get"),
  getSettings: () => ipcRenderer.invoke("settings:get"),
  login: (input: { cloudUrl: string; email: string; password: string }) =>
    ipcRenderer.invoke("auth:login", input),
  listReaders: () => ipcRenderer.invoke("readers:list"),
  connect: (input: { readerId: number; hardware: "impinj" | "zebra" | "generic" | "active_transponder"; hardwareAddress: string }) =>
    ipcRenderer.invoke("connect", input),
  disconnect: () => ipcRenderer.invoke("disconnect"),
  toggleTest: (enabled: boolean) => ipcRenderer.invoke("test:toggle", enabled),
  configureHardware: (input: { channel: number; power: number; loop1Enabled: boolean; loop2Enabled: boolean; syncClock?: boolean }) =>
    ipcRenderer.invoke("hardware:configure", input),
  logout: () => ipcRenderer.invoke("logout"),
  openExternal: (url: string) => ipcRenderer.invoke("open-external", url),
  onStatus: (cb: (status: unknown) => void) => {
    ipcRenderer.on("status:update", (_e, status) => cb(status));
  },
});
